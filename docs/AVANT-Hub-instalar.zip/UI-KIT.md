# UI kit do AVANT Hub

Referência para manter o hub e o AVANTools no mesmo padrão. Toda mudança de tela deve seguir isto.

## Cores (sempre por token, nunca cor solta)
| Token | Uso |
|---|---|
| `--pri` / `--pri-d` | cor principal / hover da principal |
| `--sec` | acento laranja. Só a ação principal da tela |
| `--pri-l` | fundo suave de item selecionado |
| `--panel`, `--panel2`, `--bg` | superfícies |
| `--line`, `--line2` | bordas |
| `--tx`, `--tx2`, `--tx3`, `--tx-h` | texto |
| `--danger` | apagar e erros (um vermelho só) |

## Fonte
- Roboto. Consolas só para código.
- Escala alvo: 12, 14, 16, 20, 28, 36. Pesos: 400, 600, 700.
- Situação: ainda há 20 tamanhos no CSS. Migrar por etapas.

## Botões (7.16.8)
- **Forma:** quadrado (raio 0). Pílula só em contador e etiqueta.
- **Alturas:** 28 (pequeno), 36 (padrão), 44 (destaque).
- **Níveis:** principal `.btn` (azul) · acento `.btn-acc` (laranja) · secundário `.ghost` (branco com borda) · discreto `.linkbtn` · perigo `.ghost.danger`.
- **Ícone:** `.icon-btn` e `.mk-q` com 36×36; em cartões, 28×28.
- **Hover:** o fundo escurece. A borda não muda de cor.
- **Desativado:** opacidade 45%.
- **Foco:** contorno laranja de 3px (`:focus-visible`).

## Listas laterais (aplicado na 7.16.7)
- Cartão simples: fundo `--panel`, borda `--line`, raio 12, nome em 14/700, contador em pílula.
- Selecionado: fundo `--pri-l`. Pastas mostram a cor numa faixa de 4px à esquerda.
- Sem quadrado colorido de ícone.

## Notas de atualização
- Sempre dizer onde: `Hub › tela › botão` ou `AVANTools › menu › ferramenta`.

## Aplicado na 7.17.0
- Tudo quadrado (raio 0). Redondo só: círculos (foto, ponto) e contadores.
- Fonte: 12, 14, 16, 20, 28, 36. Pesos 400, 600, 700.
- Ícones SVG no lugar de emoji. Sem quadrado atrás de ícone.
- Cartões: borda `--line`, hover com borda azul e sombra. Abas: 14/600, ativa com faixa laranja.
- Tokens: `--white`, `--danger`, `--on-warn` no lugar de cores soltas.
- Foco: contorno laranja de 3px em botões e campos.
- Apagar: “clique de novo”, botão vermelho. Aviso: janela do hub (`say()`), sem `alert()`.
- Erro: cartão com faixa vermelha. Vazio e carregando: classes `.empty` e `.loading`.
- Nav do topo: botão ocupa a altura toda da barra.
- Menu do AVANTools: topo em cartões.

## Reportar (7.19.0)
Botão `#openFeedback` na nav (célula cheia, ícone `feedback`). Janela `#fb`: três botões de tipo (segmentado quadrado, ativo laranja), caixa de texto, contexto automático. Envio para a coleção `feedback` do Firestore.

## Ainda aberto
1. Telas do AVANTools que vieram da Delphi (ferramentas antigas) ainda têm tamanhos de letra e raios próprios.
2. Rótulos de acessibilidade em mais botões (só 28 têm `title` ou `aria-label`).
3. Conferir contraste de cada tema do hub (laranja com texto escuro, branco sobre azul).
