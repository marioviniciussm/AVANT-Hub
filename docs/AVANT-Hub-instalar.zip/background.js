// RefHub - extensão: abre o app e cria o menu do botão direito
const APP = chrome.runtime.getURL("app.html");

async function openApp() {
  const tabs = await chrome.tabs.query({ url: APP });
  if (tabs[0]) { await chrome.tabs.update(tabs[0].id, { active: true }); await chrome.windows.update(tabs[0].windowId, { focused: true }); }
  else await chrome.tabs.create({ url: APP });
}
chrome.action.onClicked.addListener(openApp);

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "img", title: "Salvar imagem no AVANT Hub", contexts: ["image"] });
    chrome.contextMenus.create({ id: "page", title: "Salvar esta página no AVANT Hub", contexts: ["page"] });
    chrome.contextMenus.create({ id: "link", title: "Salvar este link no AVANT Hub", contexts: ["link"] });
    chrome.contextMenus.create({ id: "open", title: "Abrir o AVANT Hub", contexts: ["action"] });
  });
});

// Salva na coleção "Caixa de entrada" (a miniatura é copiada quando o RefHub abrir a coleção)
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "open") return openApp();
  const { colecoes } = await chrome.storage.local.get("colecoes");
  const data = colecoes && colecoes.boards ? colecoes : { boards: [] };
  let box = data.boards.find(b => b.inbox);
  if (!box) {
    box = { id: "inbox", inbox: true, name: "Caixa de entrada", color: "#a2a8b4", emoji: "📥", desc: "Salvo pelo botão direito do navegador", cover: "", items: [], createdAt: Date.now() };
    data.boards.unshift(box);
  }
  const host = (() => { try { return new URL(info.pageUrl).hostname.replace(/^www\./, ""); } catch { return "web"; } })();
  let item;
  if (info.menuItemId === "img") {
    item = { id: "web:" + info.srcUrl, kind: "image", title: tab?.title || host, thumb: info.srcUrl, full: info.srcUrl, page: info.pageUrl, sourceName: host };
  } else if (info.menuItemId === "link") {
    const lh = (() => { try { return new URL(info.linkUrl).hostname.replace(/^www\./, ""); } catch { return host; } })();
    item = { id: "page:" + info.linkUrl, kind: "page", title: (info.selectionText || "").trim().slice(0, 120) || lh, thumb: "", page: info.linkUrl, sourceName: lh };
  } else {
    let shot = "";
    try { shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 70 }); } catch {}
    item = { id: "page:" + info.pageUrl, kind: "page", title: tab?.title || host, thumb: shot, page: info.pageUrl, sourceName: host };
  }
  if (box.items.some(x => x.id === item.id)) return;
  box.items.unshift({ ...item, license: { code: "rights", label: "Salvo da web (verifique a licença)", commercial: false, modify: false, attribution: true },
    uid: "i" + Date.now().toString(36), note: "", tags: [], savedAt: Date.now() });
  await chrome.storage.local.set({ colecoes: data });
  chrome.action.setBadgeText({ text: "✓" }); setTimeout(() => chrome.action.setBadgeText({ text: "" }), 1500);
});

// Login dentro do hub: o site aberto dentro do AVANT Hub fica num quadro "de terceiros", e o navegador
// não manda para ele os cookies de login marcados como SameSite=Lax. Sem eles o Pinterest acha que você
// saiu, mostra "Entre para continuar" e para de carregar imagens. Aqui os cookies destes sites passam a
// valer também dentro do hub. Só os sites de referência entram nesta lista (nada de bancos, e-mail ou redes pessoais).
const EMBED_LOGIN = ["pinterest.com", "pinterest.com.br", "behance.net", "dribbble.com", "freepik.com", "freepik.com.br", "freepik.es", "magnific.com", "flaticon.com", "canva.com"];
const isEmbedDomain = d => { d = d.replace(/^\./, ""); return EMBED_LOGIN.some(x => d === x || d.endsWith("." + x)); };
async function relaxCookie(c) {
  if (c.sameSite === "no_restriction" || c.partitionKey || !isEmbedDomain(c.domain)) return;
  const host = c.domain.replace(/^\./, "");
  try {
    await chrome.cookies.set({ url: `https://${host}${c.path || "/"}`, ...(c.hostOnly ? {} : { domain: c.domain }), name: c.name, value: c.value, path: c.path,
      secure: true, httpOnly: c.httpOnly, sameSite: "no_restriction", ...(c.session ? {} : { expirationDate: c.expirationDate }), storeId: c.storeId });
  } catch {}
}
async function relaxAll() {
  for (const d of EMBED_LOGIN) for (const c of await chrome.cookies.getAll({ domain: d }).catch(() => [])) await relaxCookie(c);
  // o Pinterest precisa de um csrftoken; sem ele cada pedido de "mais imagens" volta com erro
  const csrf = await chrome.cookies.get({ url: "https://www.pinterest.com/", name: "csrftoken" }).catch(() => null);
  if (!csrf) {
    const v = Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, "0")).join("");
    await chrome.cookies.set({ url: "https://www.pinterest.com/", domain: ".pinterest.com", name: "csrftoken", value: v, path: "/", secure: true, sameSite: "no_restriction", expirationDate: Date.now() / 1000 + 365 * 86400 }).catch(() => {});
  }
}
chrome.cookies.onChanged.addListener(ch => { if (!ch.removed) relaxCookie(ch.cookie); });
chrome.runtime.onStartup.addListener(relaxAll);
chrome.runtime.onInstalled.addListener(relaxAll);
relaxAll();


// Login da empresa: a página de login (GitHub Pages) manda o e-mail e a chave de acesso para cá.
const LOGIN_ORIGIN = "https://marioviniciussm.github.io";
chrome.runtime.onMessageExternal.addListener((msg, sender, reply) => {
  try {
    if (!sender.origin || sender.origin !== LOGIN_ORIGIN) return reply({ ok: false });
    if (msg && msg.type === "avt-auth" && msg.refreshToken && msg.email) {
      chrome.storage.local.set({ avtAuth: { email: String(msg.email), refreshToken: String(msg.refreshToken), at: Date.now() } }, () => reply({ ok: true }));
      return true;
    }
    if (msg && msg.type === "avt-ping") return reply({ ok: true });
  } catch { reply({ ok: false }); }
});

// depois de "Atualizar": o hub reinicia a extensão e esta parte abre o hub de novo
chrome.storage.local.get("avtReopen", r => {
  if (r && r.avtReopen && Date.now() - r.avtReopen < 120000) { chrome.storage.local.remove("avtReopen"); setTimeout(openApp, 400); }
});
