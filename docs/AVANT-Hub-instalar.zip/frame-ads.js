// Roda só quando o site está aberto DENTRO do AVANT Hub. Os bloqueadores de anúncio instalados no navegador
// não atuam dentro de páginas de extensão, então os anúncios (inclusive os de conteúdo NSFW) passavam.
// Aqui esconde os pins/cards patrocinados e os blocos de anúncio mais comuns.
(() => {
  try {
    const anc = location.ancestorOrigins;
    if (!anc || !anc.length || !String(anc[anc.length - 1]).startsWith("chrome-extension://")) return;
    const AD_WORD = /^\s*(promoted by|promoted|promovido por|promovido|patrocinado( por)?|anúncio|anuncio|sponsored|ad)\s*$/i;
    const CARD = '[data-test-id="pin"],[data-test-id="pinWrapper"],[data-grid-item],[role="listitem"],[data-test-id="pinrep"],[data-test-id="search-pin"],li';
    const GENERIC = 'ins.adsbygoogle,iframe[id^="google_ads"],iframe[src*="doubleclick.net"],iframe[src*="googlesyndication"],[id^="div-gpt-ad"],[data-ad-slot],[data-test-id="pin-ad"],[data-test-id="ad-pin"],[data-test-id*="promoted"],[aria-label="Promoted"],[aria-label="Promovido"],[aria-label="Patrocinado"],[aria-label="Anúncio"]';
    const css = document.createElement("style");
    css.textContent = GENERIC + "{display:none!important}[data-avt-ad]{display:none!important}";
    (document.head || document.documentElement).appendChild(css);
    const mark = el => { if (el && el.setAttribute) el.setAttribute("data-avt-ad", "1"); };
    const scan = root => {
      if (!root || !root.querySelectorAll) return;
      // um card é anúncio quando tem um rótulo curto de "Promovido / Patrocinado / Anúncio" dentro
      const labels = root.querySelectorAll("span,div,a,p");
      for (const l of labels) {
        if (l.childElementCount > 1 || l.__avt) continue;
        const t = l.textContent;
        if (!t || t.length > 24 || !AD_WORD.test(t)) continue;
        l.__avt = 1;
        const card = l.closest(CARD);
        if (card) mark(card);
      }
      for (const a of root.querySelectorAll('a[href*="ads.pinterest.com"],a[href*="/ads/"],a[href*="doubleclick.net"],a[href*="googleadservices.com"]')) mark(a.closest(CARD) || a);
    };
    let t = 0;
    const later = () => { if (t) return; t = setTimeout(() => { t = 0; scan(document); }, 250); };
    new MutationObserver(later).observe(document.documentElement, { childList: true, subtree: true });
    document.addEventListener("DOMContentLoaded", later);
    window.addEventListener("scroll", later, { passive: true });
  } catch {}
})();
