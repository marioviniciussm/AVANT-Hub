// Roda DENTRO da página embutida e lista as mídias visíveis (fotos, vídeos, capas).
// Usado pela extensão (chrome.scripting) e pelo app (webview.executeJavaScript).
function avantHubCollectMedia() {
  const out = [], seen = new Set();
  let blobVideos = 0;
  const abs = u => { try { return new URL(u, location.href).href; } catch { return ""; } };
  const add = (type, url, w, h, alt) => {
    url = abs(url);
    if (!/^https?:/.test(url) || seen.has(url)) return;
    seen.add(url); out.push({ type, url, w: w || 0, h: h || 0, alt: (alt || "").slice(0, 140) });
  };
  const best = img => {
    let u = img.currentSrc || img.src, top = 0;
    (img.srcset || "").split(",").forEach(p => { const [uu, d] = p.trim().split(/\s+/); const n = parseFloat(d) || 0; if (uu && n > top) { top = n; u = uu; } });
    return u;
  };
  for (const m of document.querySelectorAll('meta[property="og:image"],meta[name="twitter:image"]')) add("image", m.content, 0, 0, "imagem de capa da página");
  for (const m of document.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"]')) {
    // só quando aponta para um arquivo de vídeo de verdade (alguns sites põem o próprio endereço da página aqui)
    if (/\.(mp4|webm|mov|m4v)(\?|$)/i.test(m.content || "")) add("video", m.content, 0, 0, "vídeo da página");
  }
  for (const img of document.images) {
    const w = img.naturalWidth, h = img.naturalHeight;
    if (w >= 150 && h >= 150) add("image", best(img), w, h, img.alt);
  }
  for (const v of document.querySelectorAll("video")) {
    const u = v.currentSrc || v.src || (v.querySelector("source") || {}).src || "";
    if (u && !u.startsWith("blob:")) add("video", u, v.videoWidth, v.videoHeight, "");
    else if (u) blobVideos++;
    if (v.poster) add("image", v.poster, v.videoWidth, v.videoHeight, "capa do vídeo");
  }
  // dados internos (Instagram e parecidos): fotos e vídeos dos posts em tamanho grande, inclusive vídeos que na tela são "blob:"
  const dec = u => u.replace(/\\u0026/g, "&").replace(/\\\//g, "/");
  for (const sc of document.querySelectorAll("script")) {
    const t = sc.textContent || "";
    if (t.length < 80 || !/video_versions|video_url|display_url|image_versions2/.test(t)) continue;
    for (const m of t.matchAll(/"video_versions":\s*\[\s*\{[^\]]*?"url":\s*"(https:[^"]+)"/g)) add("video", dec(m[1]), 0, 0, "vídeo do post");
    for (const m of t.matchAll(/"video_url":\s*"(https:[^"]+)"/g)) add("video", dec(m[1]), 0, 0, "vídeo do post");
    for (const m of t.matchAll(/"image_versions2":\s*\{\s*"candidates":\s*\[\s*\{[^\]]*?"url":\s*"(https:[^"]+)"/g)) add("image", dec(m[1]), 0, 0, "foto do post");
    for (const m of t.matchAll(/"display_url":\s*"(https:[^"]+)"/g)) add("image", dec(m[1]), 0, 0, "foto do post");
    if (out.length > 400) break;
  }
  // imagens de fundo grandes (banners de sites)
  for (const el of document.querySelectorAll("section,div,a,figure")) {
    if (out.length > 400) break;
    const bg = getComputedStyle(el).backgroundImage;
    if (!bg || bg === "none") continue;
    const r = el.getBoundingClientRect();
    if (r.width < 200 || r.height < 150) continue;
    const m = /url\(["']?(.+?)["']?\)/.exec(bg); if (m) add("image", m[1], Math.round(r.width), Math.round(r.height), "imagem de fundo");
  }
  return { name: window.name, href: location.href, title: document.title, items: out.slice(0, 400), blobVideos };
}

// Roda num quadro do instagram.com. Tenta: 1) API com o login do navegador, 2) consulta pública (GraphQL), 3) página de incorporação.
async function avantHubIgLookup(code) {
  const out = { items: [], caption: "", author: "", via: "", logged: /ds_user_id=/.test(document.cookie) };
  const seen = new Set();
  const add = (type, url) => { if (url && !seen.has(url)) { seen.add(url); out.items.push({ type, url }); } };
  const best = arr => (arr || []).slice().sort((a, b) => (b.width || 0) - (a.width || 0))[0];
  const APP = "936619743392459";
  // shortcode -> id numérico
  const AL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  let id = 0n; for (const ch of code.slice(0, 11)) id = id * 64n + BigInt(AL.indexOf(ch));
  const fromItem = it => {
    if (!it) return;
    out.author = out.author || it.user?.username || "";
    out.caption = out.caption || it.caption?.text || "";
    const list = it.carousel_media && it.carousel_media.length ? it.carousel_media : [it];
    for (const m of list) {
      if (m.video_versions && m.video_versions.length) add("video", best(m.video_versions).url);
      else if (m.image_versions2) add("image", best(m.image_versions2.candidates).url);
    }
  };
  // 1) com login
  try {
    const r = await fetch(`/api/v1/media/${id}/info/`, { credentials: "include", headers: { "x-ig-app-id": APP, "x-requested-with": "XMLHttpRequest" } });
    if (r.ok) { const j = await r.json(); fromItem(j.items && j.items[0]); if (out.items.length) out.via = "login"; }
  } catch {}
  // 2) consulta pública
  if (!out.items.length) {
    try {
      const home = await (await fetch("/", { credentials: "include" })).text();
      const lsd = (/"LSD",\[\],\{"token":"([^"]+)"/.exec(home) || /"lsd":"([^"]+)"/.exec(home) || [])[1] || "";
      const csrf = (/csrftoken=([^;]+)/.exec(document.cookie) || [])[1] || "";
      const body = new URLSearchParams({ variables: JSON.stringify({ shortcode: code, fetch_tagged_user_count: null, hoisted_comment_id: null, hoisted_reply_id: null }), doc_id: "8845758582119845", lsd });
      const r = await fetch("/api/graphql", { method: "POST", credentials: "include", body,
        headers: { "content-type": "application/x-www-form-urlencoded", "x-ig-app-id": APP, "x-fb-lsd": lsd, "x-asbd-id": "129477", ...(csrf ? { "x-csrftoken": csrf } : {}) } });
      const j = await r.json();
      if (j && j.errors && /rate limit/i.test(JSON.stringify(j.errors))) out.limited = true;
      const m = j && j.data && (j.data.xdt_shortcode_media || j.data.shortcode_media);
      if (m) {
        out.author = m.owner?.username || ""; out.caption = m.edge_media_to_caption?.edges?.[0]?.node?.text || "";
        const kids = m.edge_sidecar_to_children?.edges?.map(e => e.node) || [m];
        for (const k of kids) k.is_video && k.video_url ? add("video", k.video_url) : add("image", k.display_url);
        out.via = "publico";
      }
    } catch {}
  }
  // 3) incorporação (só fotos, hoje em dia)
  if (!out.items.length) {
    try {
      const h = await (await fetch(`/p/${code}/embed/captioned/`)).text();
      const dec = u => u.replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
      for (const x of h.matchAll(/"display_url":\s*"(https:[^"]+)"/g)) add("image", dec(x[1]));
      if (!out.items.length) { const og = /class="EmbeddedMediaImage"[^>]*src="([^"]+)"/.exec(h); if (og) add("image", dec(og[1])); }
      out.via = "embed";
    } catch {}
  }
  return out;
}
