(function() {
	const e = {
		compress: !0,
		"compress-images": !0,
		"compress-fonts": !0,
		objstms: !0,
		"compression-effort": 100,
		garbage: "deduplicate"
	};
	function t(e, t, n) {
		const o = Math.max(e, t);
		if (!n || o <= n) return null;
		const s = n / o;
		return {
			w: Math.max(1, Math.round(e * s)),
			h: Math.max(1, Math.round(t * s))
		};
	}
	let n = null;
	self.onmessage = (o) => {
		(async function(o) {
			try {
				const { PDFDocument: a } = await (n ??= (s = "./mupdf/mupdf.js", import(new URL(s, document.baseURI).href)), n), i = new a(new Uint8Array(o.bytes));
				let r = null;
				try {
					const n = o.options.recompressImages ? function(e, n, o) {
						const s = e.countObjects();
						let a = 0;
						for (let i = 1; i < s; i++) {
							const s = e.newIndirect(i);
							if (!s.isStream()) continue;
							const r = s.get("Subtype");
							if (!r.isName() || "Image" !== r.asName()) continue;
							const u = s.get("ImageMask");
							if (u.isBoolean() && u.asBoolean()) continue;
							if (!s.get("SMask").isNull()) continue;
							let c = null, m = null, g = null;
							try {
								c = e.loadImage(s), m = c.toPixmap();
								const i = t(m.getWidth(), m.getHeight(), o), r = i ? g = m.warp([
									[0, 0],
									[m.getWidth(), 0],
									[m.getWidth(), m.getHeight()],
									[0, m.getHeight()]
								], i.w, i.h) : m, u = 4 === r.getNumberOfComponents(), l = r.asJPEG(n, u), d = s.readRawStream(), f = d.getLength();
								if (d.destroy(), l.length >= f) continue;
								s.writeRawStream(l), s.put("Filter", e.newName("DCTDecode")), s.put("Width", r.getWidth()), s.put("Height", r.getHeight()), s.put("BitsPerComponent", 8), s.put("ColorSpace", e.newName(u ? "DeviceCMYK" : 1 === r.getNumberOfComponents() ? "DeviceGray" : "DeviceRGB")), s.delete("DecodeParms"), a++;
							} catch {} finally {
								g?.destroy(), m?.destroy(), c?.destroy();
							}
						}
						return a;
					}(i, Math.min(100, Math.max(1, Math.round(o.options.quality))), Math.max(0, Math.round(o.options.maxEdge))) : 0;
					i.subsetFonts(), r = i.saveToBuffer(e);
					const s = new Uint8Array(r.asUint8Array());
					self.postMessage({
						id: o.id,
						ok: !0,
						bytes: s.buffer,
						pageCount: i.countPages(),
						imagesTouched: n
					}, [s.buffer]);
				} finally {
					r?.destroy(), i.destroy();
				}
			} catch (a) {
				self.postMessage({
					id: o.id,
					ok: !1,
					error: String(a)
				});
			}
			var s;
		})(o.data);
	};
})();
