(function() {
	const [t, i, h] = [
		0,
		1,
		2
	], e = [
		136,
		136,
		136
	];
	function n(t, i, h) {
		return Math.round(t * h / i);
	}
	function a({ width: t, height: i }, h) {
		return {
			x: (h.width - t) / 2,
			y: (h.height - i) / 2,
			width: t,
			height: i
		};
	}
	function o([t, i, h]) {
		return `rgb(${t}, ${i}, ${h})`;
	}
	function d(t) {
		const i = Math.min(1, 64 / Math.max(t.width, t.height)), h = Math.max(1, Math.round(t.width * i)), n = Math.max(1, Math.round(t.height * i)), a = new OffscreenCanvas(h, n).getContext("2d");
		if (!a) return e;
		a.imageSmoothingQuality = "high", a.drawImage(t, 0, 0, h, n);
		const o = a.getImageData(0, 0, h, n).data, d = [
			0,
			0,
			0
		];
		for (let e = 0; e < o.length; e += 4) d[0] += o[e], d[1] += o[e + 1], d[2] += o[e + 2];
		const r = o.length / 4;
		return [
			Math.round(d[0] / r),
			Math.round(d[1] / r),
			Math.round(d[2] / r)
		];
	}
	const r = self;
	let g;
	r.onmessage = (t) => {
		(async function(t) {
			if ("load" === t.kind) {
				const i = await createImageBitmap(t.file, { imageOrientation: "from-image" });
				return g?.close(), g = i, {
					kind: "loaded",
					id: t.id,
					width: i.width,
					height: i.height,
					dominant: d(i)
				};
			}
			const { spec: e } = t;
			if (!g) throw new Error("no source");
			const r = new OffscreenCanvas(e.width, n(e.width, e.ratioW, e.ratioH)), s = r.getContext("2d", { alpha: !1 });
			if (!s) throw new Error("no context");
			(function(t, e, d) {
				const r = {
					width: d.width,
					height: n(d.width, d.ratioW, d.ratioH)
				}, g = {
					width: e.width,
					height: e.height
				};
				if (d.style === i) t.fillStyle = o(d.colour), t.fillRect(0, 0, r.width, r.height);
				else if (d.style === h) {
					const { x0: i, y0: h, x1: e, y1: n } = function({ width: t, height: i }, h) {
						const e = h * Math.PI / 180, n = Math.sin(e), a = -Math.cos(e), o = (Math.abs(t * n) + Math.abs(i * a)) / 2, [d, r] = [t / 2, i / 2];
						return {
							x0: d - n * o,
							y0: r - a * o,
							x1: d + n * o,
							y1: r + a * o
						};
					}(r, d.angle), a = t.createLinearGradient(i, h, e, n), g = Math.max(d.stops.length - 1, 1);
					d.stops.forEach((t, i) => a.addColorStop(i / g, o(t))), t.fillStyle = a, t.fillRect(0, 0, r.width, r.height);
				} else {
					const i = function(t, i) {
						if (t.width <= 0 || t.height <= 0) return {
							x: 0,
							y: 0,
							width: 0,
							height: 0
						};
						const h = 1.2 * Math.max(i.width / t.width, i.height / t.height);
						return a({
							width: t.width * h,
							height: t.height * h
						}, i);
					}(g, r);
					t.filter = "blur(50px)", t.drawImage(e, i.x, i.y, i.width, i.height), t.filter = "none";
				}
				t.imageSmoothingQuality = "high";
				const s = function(t, i, h) {
					if (t.width <= 0 || t.height <= 0) return {
						x: 0,
						y: 0,
						width: 0,
						height: 0
					};
					const e = Math.max(0, Math.min((i.width - 2 * h) / t.width, (i.height - 2 * h) / t.height));
					return a({
						width: t.width * e,
						height: t.height * e
					}, i);
				}(g, r, d.padding);
				t.drawImage(e, s.x, s.y, s.width, s.height);
			})(s, g, e);
			const w = await r.convertToBlob({ type: "image/png" });
			return {
				kind: "rendered",
				id: t.id,
				blob: w
			};
		})(t.data).then(r.postMessage.bind(r), () => r.postMessage({
			kind: "failed",
			id: t.data.id
		}));
	};
})();
