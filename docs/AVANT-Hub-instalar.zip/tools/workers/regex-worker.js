// AVANT: worker do Regex Tester como arquivo (a extensão bloqueia workers criados por Blob)
function run(pattern, flags, text, limit) {
  limit = limit || 1000;
  if (!pattern) return { kind: 'empty' };
  try { new RegExp(pattern, flags); } catch (error) {
    return { kind: 'invalid', message: error instanceof Error ? error.message : 'Invalid regex' };
  }
  var regex = new RegExp(pattern, flags + 'd');
  var groups = new RegExp('(?:' + pattern + ')|', flags.replace('g', '')).exec('').length - 1;
  var matches = [], truncated = false, global = flags.includes('g');
  for (var match = regex.exec(text); match !== null; match = global ? regex.exec(text) : null) {
    if (matches.length >= limit) { truncated = true; break; }
    var indices = match.indices || [], found = [];
    for (var i = 1; i < indices.length; i++) { var r = indices[i]; found.push(r ? [r[0], r[1]] : null); }
    matches.push({ start: match.index, end: match.index + match[0].length, groups: found });
    if (match[0].length === 0) regex.lastIndex++;
  }
  return { kind: 'matched', matches: matches, truncated: truncated, groups: groups };
}
self.onmessage = function (event) {
  var d = event.data;
  self.postMessage({ seq: d.seq, outcome: run(d.pattern, d.flags, d.text) });
};
