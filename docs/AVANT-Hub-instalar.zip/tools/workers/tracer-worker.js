// AVANT: worker do Image Tracer como arquivo (a extensão bloqueia workers criados por Blob)
importScripts('../lib/imagetracer_v1.2.6.js');
self.onmessage = function (e) {
  try {
    var imgd = new ImageData(new Uint8ClampedArray(e.data.buffer), e.data.width, e.data.height);
    self.postMessage({ id: e.data.id, svg: self.ImageTracer.imagedataToSVG(imgd, e.data.opts) });
  } catch (error) {
    self.postMessage({ id: e.data.id, error: String(error) });
  }
};
