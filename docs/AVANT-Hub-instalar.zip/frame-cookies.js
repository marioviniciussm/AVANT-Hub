// Roda só quando o site está aberto DENTRO do AVANT Hub. Dentro do hub o navegador trata o site como
// "terceiro" e joga fora os cookies gravados pelo próprio site (SameSite=Lax). O Behance, por exemplo,
// grava um cookie de verificação e recarrega a página: sem o cookie, fica recarregando para sempre.
// Aqui os cookies gravados pela página passam a valer dentro do hub (SameSite=None; Secure).
(() => {
  try {
    const anc = location.ancestorOrigins;
    if (!anc || !anc.length || !String(anc[anc.length - 1]).startsWith("chrome-extension://")) return;
    const d = Object.getOwnPropertyDescriptor(Document.prototype, "cookie");
    if (!d || !d.set) return;
    Object.defineProperty(document, "cookie", {
      configurable: true,
      get() { return d.get.call(document); },
      set(v) {
        v = String(v);
        if (/;\s*samesite=/i.test(v)) v = v.replace(/;\s*samesite=(lax|strict)/i, "; SameSite=None");
        else v += "; SameSite=None";
        if (!/;\s*secure/i.test(v)) v += "; Secure";
        d.set.call(document, v);
      },
    });
  } catch {}
})();
