// RefHub - extensão: implementa a mesma "ponte" que o app Electron usa (window.refhub),
// só que com o motor rodando aqui na página e as APIs do Chrome.
(() => {
  const E = window.RefHubEngine;
  let keys = {};
  const canon = v => JSON.stringify(v, (k, x) => x && typeof x === 'object' && !Array.isArray(x) ? Object.fromEntries(Object.keys(x).sort().map(q => [q, x[q]])) : x);
  const mySaves = new Set(), hsh = t => { let h = 5381; for (let i = 0; i < t.length; i += 7) h = (h * 33 ^ t.charCodeAt(i)) | 0; return t.length + ':' + h; }; let lastColJSON = "";
  const ready = (async () => {
    keys = (await chrome.storage.local.get("keys")).keys || {};
    // libera o embed dos sites (remove X-Frame-Options/CSP) só dentro desta aba do RefHub
    // regra geral: qualquer iframe aberto a partir das páginas do RefHub (funciona também no Opera)
    const headers = [
      { header: "x-frame-options", operation: "remove" },
      { header: "content-security-policy", operation: "remove" },
      { header: "content-security-policy-report-only", operation: "remove" }];
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1],
      // alguns sites (Facebook, Origo, Watt Mais) recusam quando sabem que estão num iframe: dizemos que é uma página normal
      addRules: [{ id: 1, priority: 2, action: { type: "modifyHeaders", responseHeaders: headers,
        requestHeaders: [{ header: "sec-fetch-dest", operation: "set", value: "document" }, { header: "sec-fetch-site", operation: "set", value: "none" }] },
        condition: { initiatorDomains: [chrome.runtime.id], resourceTypes: ["sub_frame"] } }],
    }).catch(() => {});
    const tab = await chrome.tabs.getCurrent();
    if (tab) {
      await chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: [tab.id, tab.id + 1000000],
        addRules: [{
          id: tab.id, priority: 1,
          action: { type: "modifyHeaders", responseHeaders: [
            { header: "x-frame-options", operation: "remove" },
            { header: "content-security-policy", operation: "remove" },
            { header: "content-security-policy-report-only", operation: "remove" }] },
          condition: { tabIds: [tab.id], resourceTypes: ["sub_frame"] },
        }, {
          // o Yandex carrega dezenas de rastreadores e anúncios e só termina depois deles: dentro do hub eles ficam de fora
          id: tab.id + 1000000, priority: 1, action: { type: "block" },
          condition: { tabIds: [tab.id], initiatorDomains: ["yandex.com", "yandex.ru", "ya.ru"],
            requestDomains: ["mc.yandex.ru", "mc.yandex.com", "mc.webvisor.org", "an.yandex.ru", "yabs.yandex.ru", "yabs.yandex.com", "yandexadexchange.net", "adfox.ru", "adfox.yandex.ru", "strm.yandex.ru", "log.strm.yandex.ru", "yandexmetrica.com", "appmetrica.yandex.ru"],
            resourceTypes: ["script", "image", "xmlhttprequest", "sub_frame", "ping", "other", "media"] },
        }],
      });
      // anúncios e rastreadores de redes de publicidade: o bloqueador do navegador não vale dentro do hub
      await chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: [tab.id + 2000000],
        addRules: [{
          id: tab.id + 2000000, priority: 1, action: { type: "block" },
          condition: { tabIds: [tab.id], excludedInitiatorDomains: ["youtube.com", "youtube-nocookie.com", "youtu.be", "ytimg.com", "google.com"],
            requestDomains: ["doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "adnxs.com", "criteo.com", "criteo.net", "taboola.com", "outbrain.com", "pubmatic.com", "rubiconproject.com", "openx.net", "amazon-adsystem.com", "adsrvr.org", "casalemedia.com", "smartadserver.com", "teads.tv", "moatads.com", "scorecardresearch.com", "ct.pinterest.com", "trk.pinterest.com"],
            resourceTypes: ["script", "image", "xmlhttprequest", "sub_frame", "ping", "other", "media"] },
        }],
      }).catch(() => {});
    }
  })();
  const clean = v => { v = String(v || "").trim(); return !v || /^sua_chave/i.test(v) ? "" : v; };
  const getKey = k => clean(keys[k]);

  function pickFile() {
    return new Promise(res => {
      const i = document.createElement("input"); i.type = "file"; i.accept = ".json,application/json"; i.multiple = true;
      i.onchange = async () => res(await Promise.all([...i.files].map(f => f.text().then(t => { try { return JSON.parse(t); } catch { return null; } }))));
      i.click();
    });
  }
  async function saveJSON(obj, filename) {
    const url = URL.createObjectURL(new Blob([JSON.stringify(obj, null, 1)], { type: "application/json" }));
    try { await chrome.downloads.download({ url, filename, saveAs: true }); return true; } catch { return false; }
    finally { setTimeout(() => URL.revokeObjectURL(url), 60000); }
  }
  // baixa a imagem e guarda uma miniatura (até 480 px) dentro da coleção
  async function toThumb(src) {
    try {
      let blob;
      if (/^data:/.test(src)) blob = await (await fetch(src)).blob();
      else { const r = await fetch(src); if (!r.ok) return null; blob = await r.blob(); }
      const url = URL.createObjectURL(blob);
      const img = new Image(); img.src = url; await img.decode();
      const sc = Math.min(1, 480 / Math.max(img.naturalWidth || 480, img.naturalHeight || 480));
      const c = document.createElement("canvas"); c.width = Math.max(1, Math.round((img.naturalWidth || 480) * sc)); c.height = Math.max(1, Math.round((img.naturalHeight || 480) * sc));
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      return /png|svg|gif|webp/.test(blob.type) ? c.toDataURL("image/png") : c.toDataURL("image/jpeg", 0.85);
    } catch { return null; }
  }

  window.refhub = {
    isExtension: true,
    async search(p) { await ready; return E.search(p, getKey); },
    async types() { await ready; return E.publicTypes(getKey); },
    async links(p) { return E.platformLinks(p); },
    async getKeys() {
      await ready;
      return { list: E.KEYS.map(k => ({ ...k, value: clean(keys[k.key]), team: false,
        usedBy: [...new Set(E.SOURCES.filter(s => s.keys.includes(k.key)).map(s => s.name))] })), teamFile: null };
    },
    async setKeys(k) { keys = Object.fromEntries(Object.entries(k).filter(([, v]) => clean(v))); await chrome.storage.local.set({ keys }); return true; },
    async exportKeys() { return saveJSON({ keys }, "refhub_config.json"); },
    async importKeys() {
      const [d] = await pickFile(); if (!d) return false;
      const k = d.keys || d; keys = { ...keys, ...Object.fromEntries(Object.entries(k).filter(([, v]) => clean(v))) };
      await chrome.storage.local.set({ keys }); return true;
    },
    async resolve(r) { try { return await E.resolveMedia(r); } catch { return {}; } },
    async open(url) { if (/^https?:\/\//.test(url)) chrome.tabs.create({ url }); },
    isOpera: /\bOPR\//.test(navigator.userAgent),
    openExtSettings() { chrome.tabs.create({ url: "chrome://extensions/?id=" + chrome.runtime.id }); },
    async download(url) { try { await chrome.downloads.download({ url, saveAs: true }); } catch {} },
    // baixa vários de uma vez, sem perguntar, na pasta Downloads/AVANT Hub
    async downloadMany(list) {
      let ok = 0;
      for (const it of list) { try { await chrome.downloads.download({ url: it.url, filename: "AVANT Hub/" + it.name, saveAs: false, conflictAction: "uniquify" }); ok++; } catch {} }
      return ok;
    },
    // Instagram: lê um post/reel pelo link. A busca roda DENTRO de um quadro do instagram.com
    // (mesma origem e login do navegador), como o próprio site faz.
    async igFetch(code) {
      if (!chrome.scripting || !chrome.webNavigation) return { items: [], error: "perm" };
      const tab = await chrome.tabs.getCurrent();
      let fr = document.getElementById("igHelper");
      if (!fr) {
        fr = document.createElement("iframe"); fr.id = "igHelper"; fr.name = "igHelper";
        fr.style.cssText = "position:fixed;width:1px;height:1px;left:-10px;top:-10px;opacity:0;pointer-events:none";
        fr.src = "https://www.instagram.com/robots.txt";
        await new Promise(r => { fr.onload = r; document.body.appendChild(fr); setTimeout(r, 8000); });
      }
      const frames = await chrome.webNavigation.getAllFrames({ tabId: tab.id });
      const f = frames.find(x => x.parentFrameId === 0 && x.url.startsWith("https://www.instagram.com/robots.txt"));
      if (!f) return { items: [], error: "noframe" };
      const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [f.frameId] }, func: avantHubIgLookup, args: [code] });
      return (res && res.result) || { items: [] };
    },
    // baixa um arquivo gerado aqui (ex.: o MP3)
    async downloadBlob(blob, name) {
      const url = URL.createObjectURL(blob);
      try { await chrome.downloads.download({ url, filename: "AVANT Hub/" + name, saveAs: false, conflictAction: "uniquify" }); return true; }
      catch { return false; } finally { setTimeout(() => URL.revokeObjectURL(url), 60000); }
    },
    // busca o arquivo (o CDN do Instagram não deixa a página buscar direto; a extensão pode)
    async fetchBlob(url) { const r = await fetch(url); if (!r.ok) throw new Error("HTTP " + r.status); return await r.blob(); },
    // lista as mídias da página aberta num iframe (achado pelo name do iframe; se o site trocar o name, pelo endereço)
    async pageMedia(frameName, hostHint) {
      if (!chrome.scripting || !chrome.webNavigation) return { error: "perm" };
      try {
        const tab = await chrome.tabs.getCurrent();
        const frames = (await chrome.webNavigation.getAllFrames({ tabId: tab.id })) || [];
        const ids = frames.filter(f => f.parentFrameId === 0 && /^https?:/.test(f.url)).map(f => f.frameId);
        if (!ids.length) return { error: "noframe" };
        const res = (await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: ids }, func: avantHubCollectMedia })).map(r => r.result).filter(Boolean);
        const host = u => { try { return new URL(u).hostname.replace(/^www\./, ""); } catch { return ""; } };
        return res.find(r => r.name === frameName)
          || res.filter(r => hostHint && host(r.href).endsWith(hostHint)).sort((a, b) => b.items.length - a.items.length)[0]
          || { error: "noframe" };
      } catch (e) { return { error: String(e && e.message || e) }; }
    },
    async watch(url) { chrome.tabs.create({ url }); },
    async info() { return { version: chrome.runtime.getManifest().version }; },
    onDownloadDone(cb) {
      chrome.downloads.onChanged.addListener(async d => {
        if (!d.state || !["complete", "interrupted"].includes(d.state.current)) return;
        const [it] = await chrome.downloads.search({ id: d.id });
        cb({ state: d.state.current === "complete" ? "completed" : "cancelled", name: (it?.filename || "").split(/[\\/]/).pop() });
      });
    },
    // coleções
    async colGet() { const { colecoes } = await chrome.storage.local.get("colecoes"); lastColJSON = canon(colecoes || {}); return colecoes || { boards: [] }; },
    async colSave(d) { lastColJSON = canon(d); mySaves.add(hsh(lastColJSON)); if (mySaves.size > 20) mySaves.delete(mySaves.values().next().value); await chrome.storage.local.set({ colecoes: d }); return true; },
    async colCache(src) { return toThumb(src); },
    async colExport(b) { return saveJSON({ refhub: "colecao", version: 1, board: b }, `${(b.name || "colecao").replace(/[\\/:*?"<>|]/g, "")}.refhub.json`); },
    async colImport() { return (await pickFile()).filter(d => d && d.refhub === "colecao" && d.board).map(d => d.board); },
    onColChanged(cb) {
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area !== "local" || !ch.colecoes) return;
        const j = canon(ch.colecoes.newValue || {});
        if (j !== lastColJSON && !mySaves.has(hsh(j))) { lastColJSON = j; cb(ch.colecoes.newValue); }
      });
    },
    // print da área da plataforma embutida
    async capture(rect) {
      const shot = await chrome.tabs.captureVisibleTab({ format: "jpeg", quality: 80 });
      const img = new Image(); img.src = shot; await img.decode();
      const r = devicePixelRatio, w = Math.round(rect.width * r), h = Math.round(Math.min(rect.height, 900) * r);
      const c = document.createElement("canvas"); const sc = Math.min(1, 900 / w);
      c.width = Math.round(w * sc); c.height = Math.round(h * sc);
      c.getContext("2d").drawImage(img, Math.round(rect.left * r), Math.round(rect.top * r), w, h, 0, 0, c.width, c.height);
      return c.toDataURL("image/jpeg", 0.8);
    },
    // contas: o login é o do próprio navegador
    // nomes dos cookies de cada site (sem os valores) para saber se a pessoa está logada
    // só nomes e tamanhos, nunca o valor. Uma leitura só de todos os cookies é bem mais rápida que uma por site
    async cookieNames(domains) {
      const out = Object.fromEntries(domains.map(d => [d, []]));
      let all = [];
      try { all = await chrome.cookies.getAll({}); } catch {}
      const now = Date.now() / 1000;
      for (const c of all) {
        if (c.expirationDate && c.expirationDate < now) continue;
        const cd = c.domain.replace(/^\./, "");
        for (const d of domains) if (cd === d || cd.endsWith("." + d)) out[d].push({ n: c.name, one: c.value === "1", len: (c.value || "").length, exp: c.expirationDate || 0, h: !!c.httpOnly, s: !!c.secure, sess: !!c.session });
      }
      return out;
    },
    // avisa quando o site aberto no hub já montou a página (antes de terminar anúncios e rastreadores)
    async onFrameReady(cb) {
      if (!chrome.webNavigation) return;
      const tab = await chrome.tabs.getCurrent(); if (!tab) return;
      chrome.webNavigation.onDOMContentLoaded.addListener(d => { if (d.tabId === tab.id && d.frameId && d.parentFrameId === 0) cb(d.url); });
    },
    onCookieChange(cb) { chrome.cookies.onChanged.addListener(i => { if (!i.removed || i.cause === "explicit") cb({ domain: i.cookie.domain.replace(/^\./, ""), name: i.cookie.name, removed: i.removed, len: (i.cookie.value || "").length }); }); },
    async accountStatus(list) {
      const out = {};
      for (const a of list) { const cs = await chrome.cookies.getAll({ domain: a.domain }); out[a.id] = cs.some(c => new RegExp(a.cookie).test(c.name)); }
      return out;
    },
    async logout(domain) {
      const cs = await chrome.cookies.getAll(domain ? { domain } : {});
      if (!domain) return false; // na extensão não apagamos todos os logins do navegador
      for (const c of cs) await chrome.cookies.remove({ url: `https://${c.domain.replace(/^\./, "")}${c.path}`, name: c.name, storeId: c.storeId }).catch(() => {});
      return true;
    },
  };
})();
