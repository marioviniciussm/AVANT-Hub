// Roda só quando o site está aberto DENTRO do AVANT Hub (quadro direto da página do hub).
// Avisa o hub quando a página muda, para ele acompanhar a busca feita dentro do site.
(() => {
  try {
    if (window === top) return;
    const anc = location.ancestorOrigins;
    if (!anc || anc.length !== 1 || !String(anc[0]).startsWith("chrome-extension://")) return;
    let last = "";
    const send = () => {
      const u = location.href;
      if (u === last) return;
      last = u;
      try { parent.postMessage({ avhNav: 1, url: u }, "*"); } catch {}
    };
    send();
    addEventListener("popstate", send);
    addEventListener("hashchange", send);
    setInterval(send, 800); // sites de página única mudam a URL sem recarregar
  } catch {}
})();
