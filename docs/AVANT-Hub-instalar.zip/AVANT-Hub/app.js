/* AVANT Hub - interface */
const api = window.refhub;
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const store = {
  get(k, d) { try { const v = localStorage.getItem("refhub5:" + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("refhub5:" + k, JSON.stringify(v)); } catch {} },
};

/* ------------------------------------------------------------------ aparência */
const THEMES = [
  { id: "avant", name: "AVANT", note: "Padrão da marca", pri: "#003da5", sec: "#f18f09", ter: "#ffffff", mode: "light" },
  { id: "avant-noite", name: "AVANT noturno", note: "Escuro", pri: "#003da5", sec: "#f18f09", ter: "#ffffff", mode: "dark" },
  { id: "oceano", name: "Oceano", note: "Claro", pri: "#0b6e8a", sec: "#2fd4c6", ter: "#ffffff", mode: "light" },
  { id: "floresta", name: "Floresta", note: "Claro", pri: "#1d5b3c", sec: "#c3e05a", ter: "#ffffff", mode: "light" },
  { id: "uva", name: "Uva", note: "Claro", pri: "#5a2a86", sec: "#ff7a59", ter: "#ffffff", mode: "light" },
  { id: "areia", name: "Areia", note: "Claro, cabeçalho claro", pri: "#efe3cc", sec: "#c2552b", ter: "#3b2a1a", mode: "light" },
  { id: "grafite", name: "Grafite", note: "Escuro", pri: "#2a2f3a", sec: "#f5b324", ter: "#ffffff", mode: "dark" },
  { id: "meianoite", name: "Meia-noite", note: "Escuro", pri: "#1c3b8f", sec: "#22d3ee", ter: "#ffffff", mode: "dark" },
];
const LOOK_DEFAULT = { theme: "avant", pri: "#003da5", sec: "#f18f09", ter: "#ffffff", mode: "light", ui: 0.92, typeIcons: false,
  logo: "original", logoL: "#ffffff", logoA: "#f18f09", logoH: "#ffffff" };
const look = Object.assign({}, LOOK_DEFAULT, store.get("look", {}));
const hexRgb = h => { h = String(h).replace("#", ""); if (h.length === 3) h = h.replace(/./g, "$&$&"); const n = parseInt(h, 16) || 0; return [n >> 16, (n >> 8) & 255, n & 255]; };
const rgbHex = a => "#" + a.map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, "0")).join("");
const mixHex = (a, b, t) => { const x = hexRgb(a), y = hexRgb(b); return rgbHex(x.map((v, i) => v + (y[i] - v) * t)); };
const lum = h => { const [r, g, b] = hexRgb(h).map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const contrast = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
const bestOn = (bg, list) => list.reduce((best, c) => contrast(bg, c) > contrast(bg, best) ? c : best);
const darkMQ = matchMedia("(prefers-color-scheme: dark)");
function applyLook() {
  const r = document.documentElement.style;
  r.setProperty("--pri", look.pri); r.setProperty("--sec", look.sec); r.setProperty("--on-pri", look.ter);
  r.setProperty("--on-sec", bestOn(look.sec, ["#ffffff", mixHex(look.pri, "#000000", 0.55), "#111111"]));
  r.setProperty("--ui", look.ui);
  const dark = look.mode === "dark" || (look.mode === "auto" && darkMQ.matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  // texto na cor primária precisa ser legível no fundo do modo atual
  let ptx = look.pri; const bgc = dark ? "#151922" : "#ffffff", to = dark ? "#ffffff" : "#000000";
  for (let k = 0; k < 10 && contrast(ptx, bgc) < 4.5; k++) ptx = mixHex(ptx, to, 0.18);
  r.setProperty("--pri-tx", ptx);
  document.body.classList.toggle("types-icons", !!look.typeIcons);
  setTimeout(() => { try { if (Tools.frame) Tools.sync(); } catch {} }, 0);
  // cores do logo: original da marca, acompanhando o tema, ou escolhidas na mão
  const orig = lum(look.pri) > 0.45 ? "#1e1e1e" : "#ffffff";
  const lg = look.logo === "theme" ? [look.ter, look.sec, look.ter]
    : look.logo === "custom" ? [look.logoL, look.logoA, look.logoH] : [orig, "#f18f09", orig];
  r.setProperty("--logo-l", lg[0]); r.setProperty("--logo-a", lg[1]); r.setProperty("--logo-h", lg[2]);
}
darkMQ.addEventListener?.("change", () => look.mode === "auto" && applyLook());
function saveLook() { store.set("look", look); applyLook(); }
applyLook();

const state = {
  types: {}, type: store.get("type", "design"),
  filters: store.get("filters", {}), views: store.get("views", {}),
  off: new Set(store.get("sourcesOff", [])), nsfw: true, /* sempre ligado */ lang: store.get("lang", "auto"),
  q: "", page: 1, items: [], seen: new Set(), req: 0, links: [], loading: false, galleryCount: null,
  mode: "home", filtersOpen: store.get("filtersOpen", true),
};
const T = () => state.types[state.type];
const F = () => (state.filters[state.type] = state.filters[state.type] || {});
const currentView = () => {
  const v = state.views[state.type];
  if (v === "gallery" && T().gallery) return v;
  if (v && state.links.some(l => l.id === v)) return v;
  return T().gallery ? "gallery" : T().defaultView;
};
const params = extra => ({ type: state.type, q: state.q, filters: F(), off: [...state.off], nsfw: state.nsfw, lang: state.lang, ...extra });

/* ------------------------------------------------------------------ tipos */
function renderTypes() {
  $("#types").innerHTML = Object.entries(state.types).map(([id, t]) =>
    `<button class="type ${id === state.type ? "on" : ""}" data-type="${id}" role="tab" aria-selected="${id === state.type}" title="${esc(t.label)}">${ico(id)}<span class="tl">${esc(t.label)}</span></button>`).join("");
  $("#types").querySelectorAll("[data-type]").forEach(b => b.onclick = () => setType(b.dataset.type));
}
// família da plataforma: freepik, freepik_video e freepik_social são todos "freepik"
const fam = id => String(id || "").split("_")[0];
function setType(id) {
  if (!state.types[id]) id = "design";
  // ao trocar de tipo, tenta continuar na mesma plataforma; se não tiver, vai para a primeira aba
  if (state.mode === "search" && id !== state.type) { const v = currentView(); state.keepFam = v === "gallery" ? "" : fam(v); state.switching = true; }
  state.type = id; store.set("type", id);
  renderTypes(); renderFilters(); clearGallery(); updatePlaceholder();
  if (state.mode === "home") { renderHome(); return; }
  refresh(true);
  $(".type.on")?.scrollIntoView({ block: "nearest", inline: "nearest" });
}
function updatePlaceholder() {
  $("#q").placeholder = `Buscar em ${T().label}… Ex.: energia por assinatura`;
}

/* ------------------------------------------------------------------ filtros (próprios de cada tipo) */
function renderFilters() {
  const t = T(), f = F();
  let h = "";
  for (const fl of t.filters) {
    if (fl.kind === "color") {
      h += `<div class="group"><span class="glabel">${esc(fl.label)}</span><input type="color" class="colorpick" data-color="${fl.id}" value="${esc(f[fl.id] || fl.default || "#1d1d1f")}"></div>`;
      continue;
    }
    const val = f[fl.id] ?? fl.default ?? "";
    if (fl.options.length <= 5) {
      h += `<div class="group"><span class="glabel">${esc(fl.label)}</span>` + fl.options.map(([v, l]) =>
        `<span class="chip ${v === val ? "on" : ""}" data-f="${fl.id}" data-v="${esc(v)}">${esc(l)}</span>`).join("") + `</div>`;
    } else {
      h += `<div class="group"><span class="glabel">${esc(fl.label)}</span><select class="sel ${val && val !== (fl.default ?? "") ? "set" : ""}" data-sel="${fl.id}">` +
        fl.options.map(([v, l]) => `<option value="${esc(v)}" ${v === val ? "selected" : ""}>${esc(l)}</option>`).join("") + `</select></div>`;
    }
  }
  if (activeFilters()) h += `<button class="fclear" id="fclear" type="button">${ico("eraser")}Limpar filtros</button>`;
  if (t.gallery) h += `<div class="fend"><div class="group dd" id="srcdd"><button class="chip" id="srcbtn" type="button">Fontes ▾</button><div class="dd-menu" id="srcmenu"></div></div></div>`;
  // o idioma fica sempre à mão, na linha das abas (o filtro NSFW fica sempre ligado, sem botão)
  $("#quick").innerHTML = `<div class="seg" id="langSeg" title="Idioma da busca. Auto: cada site recebe no idioma em que funciona melhor">` +
    [["auto", "Auto"], ["pt", "PT"], ["en", "EN"]].map(([v, l]) => `<button data-lang="${v}" class="${state.lang === v ? "on" : ""}">${l}</button>`).join("") + `</div>`;
  $("#filters").innerHTML = `<span class="rowlabel">Filtros</span><div class="fgroups">${h || `<span class="muted small" style="margin:0">Esta categoria não tem filtros.</span>`}</div>`;
  renderFToggle();

  const changed = () => { store.set("filters", state.filters); refresh(false); };
  $("#filters").querySelectorAll("[data-f]").forEach(el => el.onclick = () => {
    F()[el.dataset.f] = el.dataset.v; renderFilters(); changed();
  });
  $("#filters").querySelectorAll("[data-sel]").forEach(el => el.onchange = () => { F()[el.dataset.sel] = el.value; renderFilters(); changed(); });
  $("#filters").querySelectorAll("[data-color]").forEach(el => el.onchange = () => { F()[el.dataset.color] = el.value; changed(); });
  $("#langSeg").querySelectorAll("[data-lang]").forEach(b => b.onclick = () => {
    state.lang = b.dataset.lang; store.set("lang", state.lang); renderFilters(); refresh(false);
  });
  const fc = $("#fclear"); if (fc) fc.onclick = () => { state.filters[state.type] = {}; renderFilters(); changed(); };
  if (!t.gallery) return;
  $("#srcbtn").onclick = e => { e.stopPropagation(); $("#srcdd").classList.toggle("open"); };
  renderSources();
}
// quantos filtros estão fora do padrão
function activeFilters() {
  const f = F();
  return T().filters.filter(fl => { const v = f[fl.id]; return v != null && v !== "" && v !== (fl.default ?? ""); }).length;
}
function renderFToggle() {
  const n = activeFilters(), b = $("#ftoggle");
  b.innerHTML = `${ico("filters")}Filtros${n ? `<span class="count">${n}</span>` : ""}${ico(state.filtersOpen ? "up" : "down")}`;
  b.classList.toggle("open", state.filtersOpen);
  b.setAttribute("aria-expanded", state.filtersOpen);
  b.title = state.filtersOpen ? "Esconder filtros" : "Mostrar filtros";
  if (state.mode === "search") $("#filters").hidden = !state.filtersOpen;
}
$("#ftoggle").onclick = () => { state.filtersOpen = !state.filtersOpen; store.set("filtersOpen", state.filtersOpen); renderFToggle(); };
document.addEventListener("click", e => { const dd = $("#srcdd"); if (dd && !dd.contains(e.target)) dd.classList.remove("open"); });

function renderSources() {
  const list = T().sources;
  $("#srcmenu").innerHTML = `<div class="dd-note" style="border:0;margin:0 0 4px">Fontes da Galeria para ${esc(T().label)}</div>` +
    list.map(x => `<label class="dd-item ${x.ready ? "" : "off"}">
      <input type="checkbox" data-id="${esc(x.id)}" ${x.ready ? "" : "disabled"} ${x.ready && !state.off.has(x.id) ? "checked" : ""}>
      ${esc(x.name)} <small>${x.ready ? "" : "sem chave"}</small></label>`).join("") +
    (list.some(x => !x.ready) ? `<div class="dd-note">"Sem chave" liga quando você coloca a chave grátis em ⚙.</div>` : "");
  $("#srcmenu").querySelectorAll("input").forEach(i => i.onchange = () => {
    i.checked ? state.off.delete(i.dataset.id) : state.off.add(i.dataset.id);
    store.set("sourcesOff", [...state.off]); updateSrcBtn(); refresh(false);
  });
  updateSrcBtn();
}
function updateSrcBtn() {
  if (!$("#srcbtn")) return;
  const ready = T().sources.filter(x => x.ready);
  $("#srcbtn").textContent = `Fontes ${ready.filter(x => !state.off.has(x.id)).length}/${T().sources.length} ▾`;
}

/* ------------------------------------------------------------------ abas: Galeria + plataformas */
function renderViews() {
  const cur = currentView();
  const n = state.galleryCount == null ? "" : `<span class="n">${state.galleryCount}</span>`;
  $("#views").innerHTML = (T().gallery ? `<button class="view ${cur === "gallery" ? "on" : ""}" data-view="gallery" role="tab">Galeria${n}</button>` : "") +
    state.links.map(l => `<button class="view ${cur === l.id ? "on" : ""}" data-view="${l.id}" role="tab" title="Abre ${esc(l.name)} aqui dentro">${esc(l.name)}</button>`).join("");
  $("#views").querySelectorAll("[data-view]").forEach(b => b.onclick = () => setView(b.dataset.view));
}
function setView(v) {
  loginActive = false;
  state.views[state.type] = v; store.set("views", state.views);
  renderViews(); showView();
}
function showView() {
  if (state.mode !== "search") return;
  const v = currentView();
  const isGallery = T().gallery && (v === "gallery" || !state.links.some(l => l.id === v));
  $("#gallery").hidden = !isGallery;
  $("#webpane").hidden = isGallery;
  if (!isGallery) showWeb(v);
}

/* ------------------------------------------------------------------ busca */
$("#form").onsubmit = e => {
  e.preventDefault();
  const q = $("#q").value.trim();
  if (!q) { toast("Digite o que você procura"); $("#q").focus(); return; }
  state.q = q;
  if (state.mode !== "search") { state.switching = true; state.keepFam = ""; }
  setMode("search");
  refresh(true);
};

// Atualiza links das plataformas e a galeria
// O Opera não deixa extensões abrirem o Google dentro de outra página (nem com o embed liberado).
// Lá, a aba "Google Imagens" usa o Startpage, que mostra os resultados do próprio Google.
function adaptLinks(links) {
  if (!api.isOpera) return links;
  return links.map(l => l.id !== "google" || !l.url ? l : { ...l, serp: false, via: "Startpage",
    url: `https://www.startpage.com/sp/search?cat=images&query=${encodeURIComponent(l.query)}&language=portugues&qadf=${state.nsfw ? "heavy" : "none"}` });
}
async function refresh(newSearch) {
  state.links = adaptLinks(await api.links(params()));
  if (state.switching) {
    const hit = state.keepFam && state.links.find(l => fam(l.id) === state.keepFam);
    state.views[state.type] = hit ? hit.id : (T().gallery ? "gallery" : state.links[0]?.id);
    store.set("views", state.views); state.switching = false;
  }
  renderViews(); showView();
  if (!T().gallery) { clearGallery(); return; }
  if (!state.q && !hasFilterTerms()) { clearGallery(); intro(); return; }
  runGallery(true);
}
function hasFilterTerms() { return Object.values(F()).some(v => v && !String(v).startsWith("#")) && state.type !== "foto"; }

function clearGallery() {
  stopAudio();
  state.items = []; state.seen = new Set(); state.page = 1; state.galleryCount = null;
  $("#results").innerHTML = ""; $("#after").innerHTML = ""; $("#meta").textContent = ""; $("#understood").innerHTML = "";
}

async function runGallery(reset) {
  if (state.loading && !reset) return;
  if (reset) clearGallery();
  const my = ++state.req;
  state.loading = true;
  $("#after").innerHTML = `<div class="loading"><div class="spin"></div></div>`;
  if (reset) $("#meta").textContent = "Buscando…";
  let data;
  try { data = await api.search(params({ page: state.page })); }
  catch (e) {
    if (my === state.req) { state.loading = false; $("#after").innerHTML = `<div class="empty"><b>Algo deu errado na busca.</b>${esc(e.message || e)}</div>`; }
    return;
  }
  if (my !== state.req) return;
  state.loading = false;

  renderUnderstood(data.parsed);
  const fresh = (data.items || []).filter(it => !state.seen.has(it.id));
  fresh.forEach(it => state.seen.add(it.id));
  const offset = state.items.length;
  state.items.push(...fresh);
  T().kind === "audio" ? appendAudio(fresh, offset) : appendCards(fresh, offset);
  state.galleryCount = state.items.length;
  renderViews();

  const bits = [`${state.items.length} resultado${state.items.length === 1 ? "" : "s"}`];
  if (data.sourcesUsed) bits.push(`em ${data.sourcesUsed.length} fonte${data.sourcesUsed.length === 1 ? "" : "s"}`);
  if (data.took) bits.push(`${data.took.toFixed(1)}s`);
  if (data.hidden && state.nsfw) bits.push(`${data.hidden} ocultos pelo filtro NSFW`);
  let h = esc(bits.join(" · "));
  if (data.errors?.length) h += ` · <span class="err">${esc(data.errors.join(" · "))}</span>`;
  $("#meta").innerHTML = h;

  const ready = T().sources.filter(x => x.ready && !state.off.has(x.id));
  if (data.blocked) {
    $("#after").innerHTML = `<div class="empty"><b>Busca bloqueada pelo filtro NSFW</b>A busca tem termos de conteúdo sensível. Tente outras palavras.</div>`;
  } else if (!state.items.length) {
    const why = !ready.length
      ? `Nenhuma fonte da Galeria está ligada para ${esc(T().label)}. Elas precisam de chave grátis.`
      : `As fontes abertas não trouxeram nada para essa busca.`;
    $("#after").innerHTML = `<div class="empty"><b>Nada na Galeria</b>${why}<br>Veja direto nas plataformas:
      <div class="row">${state.links.slice(0, 5).map(l => `<button class="ghost" data-go="${l.id}">${esc(l.name)}</button>`).join("")}
      <button class="ghost" id="emptyKeys">⚙ Adicionar chaves</button></div></div>`;
    $("#after").querySelectorAll("[data-go]").forEach(b => b.onclick = () => setView(b.dataset.go));
    $("#emptyKeys").onclick = () => openKeys("keys");
  } else if (fresh.length) {
    $("#after").innerHTML = `<button class="ghost more" id="more">Carregar mais</button>`;
    $("#more").onclick = () => { state.page++; runGallery(false); };
  } else {
    $("#after").innerHTML = `<div class="empty">Fim dos resultados da Galeria. Continue nas plataformas acima.</div>`;
  }
}

function renderUnderstood(p) {
  if (!p) return;
  const parts = [];
  if (p.concepts.length) {
    parts.push(`<span>Entendi:</span>`);
    p.concepts.forEach(c => {
      const tr = c.en.filter(x => x !== c.label);
      parts.push(`<span class="tag">${esc(c.label)}${tr.length ? ` <i>→ ${esc(tr.join(" / "))}</i>` : ""}</span>`);
    });
  }
  if (p.extra?.length) { parts.push(`<span>+</span>`); p.extra.forEach(x => parts.push(`<span class="tag cat">${esc(x)}</span>`)); }
  $("#understood").innerHTML = parts.join("");
  $("#understood").title = "Consultas enviadas: " + p.variants.join(" | ");
}

/* ------------------------------------------------------------------ licença e crédito */
function licClass(l) {
  if (!l || l.code === "unknown") return "un";
  if (!l.commercial || !l.modify) return "no";
  return l.attribution ? "by" : "pd";
}
const licShort = l => ({ pd: "Livre", by: "Livre c/ crédito", no: "Só inspiração", un: "Ver licença" }[licClass(l)]);
function credit(it) {
  const l = it.license || {};
  return `"${it.title || "Sem título"}"${it.author ? ` por ${it.author}` : ""} — ${it.sourceName}` +
    `${l.label ? ` (${l.label})` : ""}${l.url ? ` ${l.url}` : ""}${it.page ? ` · ${it.page}` : ""}`;
}
async function copy(text, msg = "Crédito copiado") {
  try { await navigator.clipboard.writeText(text); }
  catch { const t = document.createElement("textarea"); t.value = text; document.body.appendChild(t); t.select(); document.execCommand("copy"); t.remove(); }
  toast(msg);
}

/* ------------------------------------------------------------------ grade */
function iconColors() {
  const c = F().cor_icone || "#1d1d1f";
  const n = parseInt(c.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  const light = (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.6;
  return { bg: light ? "#1d2027" : "#f4f5f8", fg: light ? "#cfd3da" : "#555" };
}
function appendCards(list, offset) {
  const isIcon = T().kind === "icon";
  let g = $("#results .grid");
  if (!g) { g = document.createElement("div"); g.className = "grid" + (isIcon ? " icons" : ""); $("#results").appendChild(g); }
  if (isIcon) { const ic = iconColors(); g.style.setProperty("--iconbg", ic.bg); g.style.setProperty("--iconfg", ic.fg); }
  const frag = document.createDocumentFragment();
  list.forEach((it, i) => {
    let ratio = it.w && it.h ? it.h / it.w : 0.75;
    ratio = Math.min(1.6, Math.max(0.55, ratio));
    const c = document.createElement("div");
    c.className = "card" + (it.kind === "icon" ? " icon" : "");
    c.style.gridRowEnd = "span " + (it.kind === "icon" ? 12 : Math.round(ratio * 23) + 1);
    c.innerHTML = `
      <img loading="lazy" referrerpolicy="no-referrer" src="${esc(it.thumb)}" alt="">
      <span class="src">${esc(it.sourceName)}</span>
      <span class="lic ${licClass(it.license)}" title="${esc(it.license?.label)}">${licShort(it.license)}</span>
      ${it.kind === "video" ? '<span class="play"></span>' : ""}
      ${it.kind === "model" || it.meta ? `<span class="badge3d">${esc(it.kind === "model" ? "3D interativo" : it.meta)}</span>` : ""}
      <button class="save ${Col.isSaved(it.id) ? "saved" : ""}" title="Salvar em uma coleção">★</button>
      <div class="info"><b>${esc(it.title || "Sem título")}</b>${it.kind === "icon" ? "" : esc(it.author || "")}</div>`;
    // se a miniatura falhar, tenta outra versão; se tudo falhar, o card fica (não some mais)
    const img = c.querySelector("img");
    const tries = [it.thumb2, it.full].filter(u => u && u !== it.thumb);
    img.onerror = () => { const n = tries.shift(); if (n) img.src = n; else c.classList.add("broken"); };
    c.onclick = () => openLB(offset + i);
    const sb = c.querySelector(".save");
    sb.onclick = e => { e.stopPropagation(); Col.pick(it, sb); };
    frag.appendChild(c);
  });
  g.appendChild(frag);
}

/* ------------------------------------------------------------------ áudio */
const player = $("#player");
let playingId = null;
const fmt = s => { if (s == null || isNaN(s)) return "--:--"; s = Math.round(s); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };
function appendAudio(list, offset) {
  let box = $("#results .audio-list");
  if (!box) { box = document.createElement("div"); box.className = "audio-list"; $("#results").appendChild(box); }
  list.forEach((it, i) => {
    const r = document.createElement("div");
    r.className = "arow";
    const art = it.waveform ? `<div class="art wave" style="background-image:url('${esc(it.waveform)}')"></div>`
      : `<div class="art" style="${it.thumb ? `background-image:url('${esc(it.thumb)}')` : ""}"></div>`;
    r.innerHTML = `
      <button class="pbtn" aria-label="Tocar"></button>${art}
      <div class="t"><b title="${esc(it.title)}">${esc(it.title || "Sem título")}</b><span>${esc([it.author, it.sourceName].filter(Boolean).join(" · "))}</span></div>
      <div class="pwrap"><div class="prog" title="Clique ou arraste para avançar"><i></i><b></b></div><div class="dur"><span class="cur">0:00</span><span>${fmt(it.duration)}</span></div></div>
      <div class="acts">
        <span class="lic ${licClass(it.license)}" title="${esc(it.license?.label)}">${licShort(it.license)}</span>
        <button data-a="save" class="${Col.isSaved(it.id) ? "saved" : ""}" title="Salvar em uma coleção">${ico("star")}Salvar</button>
        <button data-a="credit" title="Copiar o crédito">Crédito</button>
        <button data-a="down" title="Baixar o arquivo">Baixar</button>
        <button data-a="src" class="src-btn" title="Abrir na página original">${ico("ext")}Fonte</button>
      </div>`;
    r.querySelector(".pbtn").onclick = () => toggleAudio(offset + i, r);
    // clicar ou arrastar na barra: avança (e começa a tocar se estiver parado)
    const prog = r.querySelector(".prog");
    const seek = e => {
      const b = prog.getBoundingClientRect(), f = Math.max(0, Math.min(1, (e.clientX - b.left) / b.width));
      if (playingId === it.id && player.duration) { player.currentTime = f * player.duration; paintProg(r, f); }
      else { r._seekTo = f; toggleAudio(offset + i, r); }
    };
    prog.onpointerdown = e => { prog.setPointerCapture(e.pointerId); seek(e); prog.onpointermove = seek; };
    prog.onpointerup = prog.onpointercancel = () => { prog.onpointermove = null; };
    r.querySelector('[data-a="credit"]').onclick = () => copy(credit(it));
    const sv = r.querySelector('[data-a="save"]'); sv.onclick = () => Col.pick(it, sv);
    r.querySelector('[data-a="down"]').onclick = () => download(it);
    r.querySelector('[data-a="src"]').onclick = () => it.page && api.open(it.page);
    box.appendChild(r);
  });
}
async function mediaUrl(it, kind) {
  if (it[kind]) return it[kind];
  if (it.resolve) { Object.assign(it, await api.resolve(it.resolve)); return it[kind]; }
  return null;
}
async function toggleAudio(idx, row, list = state.items) {
  const it = list[idx];
  if (it.external) { stopAudio(); openLB(idx, list); return; } // YouTube: toca no player de incorporação
  if (playingId === it.id) { player.paused ? player.play() : player.pause(); return; }
  stopAudio();
  playingId = it.id; row.classList.add("playing");
  const url = await mediaUrl(it, "audio");
  if (playingId !== it.id) return;
  if (!url) { toast("Não consegui abrir esse áudio. Tente ver na fonte."); stopAudio(); return; }
  player.src = url;
  player.play().catch(() => { toast("Esse áudio não tocou aqui. Tente ver na fonte."); stopAudio(); });
}
function stopAudio() {
  player.pause(); player.removeAttribute("src");
  document.querySelectorAll(".arow.playing").forEach(r => { r.classList.remove("playing"); paintProg(r, 0); r.querySelector(".cur").textContent = "0:00"; });
  playingId = null;
}
function paintProg(r, f) {
  r.querySelector(".prog i").style.width = (f * 100) + "%";
  r.querySelector(".prog b").style.left = (f * 100) + "%";
  if (player.duration) r.querySelector(".cur").textContent = fmt(f * player.duration);
}
player.ontimeupdate = () => {
  const r = document.querySelector(".arow.playing"); if (!r || !player.duration) return;
  if (r._seekTo != null) { player.currentTime = r._seekTo * player.duration; r._seekTo = null; }
  paintProg(r, player.currentTime / player.duration);
};
player.onended = stopAudio;

async function download(it) {
  let url = it.download || it.audio || it.video || it.full;
  if (!url && it.resolve) url = await mediaUrl(it, it.resolve.media === "video" ? "video" : "audio");
  if (!url) { toast("Esse item só abre na fonte."); if (it.page) api.open(it.page); return; }
  if (it.license && !it.license.commercial) toast("Atenção: licença só para inspiração");
  api.download(url);
}
api.onDownloadDone(d => toast(d.state === "completed" ? `Salvo: ${d.name}` : "Download cancelado"));

/* ------------------------------------------------------------------ plataformas embutidas */
// No app (Electron) os sites abrem num <webview>; na extensão, num <iframe> (a extensão libera o embed).
const EXT = !!api.isExtension;
let frameSeq = 0;
function makeFrame(url) {
  if (!EXT) {
    const el = document.createElement("webview");
    el.setAttribute("partition", "persist:refhub"); el.setAttribute("allowpopups", ""); el.setAttribute("src", url);
    return el;
  }
  const el = document.createElement("iframe");
  el.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals allow-storage-access-by-user-activation");
  el.setAttribute("allow", "fullscreen; autoplay; clipboard-write; encrypted-media");
  el.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
  el.name = "avh" + (++frameSeq); // nome fixo: é como achamos este quadro para listar as mídias
  el.src = url;
  return el;
}
function frameGo(el, url) { if (EXT) el.src = url; else { try { el.loadURL(url); } catch { el.src = url; } } }
const webviews = new Map(); // id -> { el, url }
const sessionFlags = {};
function showWeb(id) {
  const link = getLink(id);
  if (!link) return;
  const host = $("#webhost");
  let empty = $("#webempty");
  if (!link.url) {
    for (const [, v] of webviews) v.el.classList.add("hide");
    if (!empty) { empty = document.createElement("div"); empty.id = "webempty"; empty.className = "webempty"; host.appendChild(empty); }
    empty.hidden = false;
    empty.innerHTML = `<b>Digite o que você procura</b>A busca abre direto em ${esc(link.name)}, aqui dentro.`;
    $("#wbQuery").textContent = ""; $("#wbUrl").textContent = ""; setLoading(false);
    return;
  }
  if (empty) empty.hidden = true;
  visitedHosts.add(baseDomain(hostOf(link.url)));
  let w = webviews.get(id);
  if (!w) {
    const el = makeFrame(link.url);
    w = { el, url: link.url, loading: true };
    const done = () => { w.loading = false; if (current() === id) setLoading(false); };
    // o Facebook (Biblioteca de Anúncios) só abre na segunda carga: na primeira ele só grava um cookie
    let warm = EXT && /facebook\.com\//.test(link.url) && !sessionFlags.fbWarm;
    if (EXT) el.addEventListener("load", () => {
      if (!warm) { done(); return; }
      // troca por um quadro novo, já com o cookie: igual a abrir de novo
      warm = false; sessionFlags.fbWarm = true;
      setTimeout(() => {
        const nf = makeFrame(w.url); nf.className = w.el.className;
        nf.addEventListener("load", done);
        w.el.replaceWith(nf); w.el = nf;
      }, 1500);
    });
    else {
      el.addEventListener("did-start-loading", () => { w.loading = true; if (current() === id) setLoading(true); });
      el.addEventListener("did-stop-loading", done);
      el.addEventListener("did-navigate", e => { if (current() === id) $("#wbUrl").textContent = e.url; });
      el.addEventListener("did-navigate-in-page", e => { if (current() === id && e.isMainFrame) $("#wbUrl").textContent = e.url; });
    }
    host.appendChild(el);
    webviews.set(id, w);
    if (webviews.size > 5) { const [oldId, old] = webviews.entries().next().value; if (oldId !== id) { old.el.remove(); webviews.delete(oldId); } }
  } else if (w.url !== link.url) {
    w.url = link.url; w.loading = true;
    frameGo(w.el, link.url);
  }
  for (const [k, v] of webviews) v.el.classList.toggle("hide", k !== id);
  setLoading(!!w.loading);
  $("#wbQuery").textContent = link.query;
  $("#wbQuery").title = "Busca enviada para " + link.name;
  $("#wbUrl").textContent = link.url; $("#wbUrl").title = link.url;
  $("#wbNote").textContent = EXT ? "" : state.nsfw && !["google", "yandex"].includes(id) ? "Este site usa o próprio filtro de conteúdo" : "";
  operaTip(link);
}
// a barrinha some quando o site já montou a página, sem esperar anúncios e rastreadores (o Yandex demora 15 s para "terminar")
api.onFrameReady?.(url => {
  const b = baseDomain(hostOf(url)); if (!b) return;
  for (const [id, w] of webviews) if (w.loading && baseDomain(hostOf(w.url)) === b) { w.loading = false; if (current() === id) setLoading(false); }
});
// barrinha laranja no topo enquanto o site carrega
function setLoading(on) {
  let bar = $("#webload");
  if (!bar) { bar = document.createElement("div"); bar.id = "webload"; bar.className = "webload"; $("#webhost").appendChild(bar); }
  bar.hidden = !on;
}
// Opera não deixa extensões mexerem em páginas de buscadores (Google, Yandex) até o usuário liberar
function operaTip(link) {
  let tip = $("#operaTip");
  const show = api.isOpera && link.serp && localStorage.getItem("refhub.operaOk2") !== "1";
  if (!show) { if (tip) tip.hidden = true; return; }
  if (!tip) {
    tip = document.createElement("div");
    tip.id = "operaTip"; tip.className = "operatip";
    tip.innerHTML = `<div><b>Yandex com erro aqui dentro?</b> O Opera bloqueia extensões em páginas de buscadores. Use a aba <b>Bing Imagens</b>, que funciona aqui.
      Ou tente ligar <b>"Permitir acesso aos resultados de páginas de pesquisa"</b> no AVANT Hub e clique em recarregar.</div>
      <div class="row"><button class="btn" id="opGo">Abrir configuração do AVANT Hub</button>
      <button class="ghost" id="opOk">Entendi</button></div>`;
    $("#webhost").before(tip);
    tip.querySelector("#opGo").onclick = () => api.openExtSettings();
    tip.querySelector("#opOk").onclick = () => {
      localStorage.setItem("refhub.operaOk2", "1"); tip.hidden = true;
      const w = curWeb(); if (w) w.src = w.src;
    };
  }
  tip.hidden = false;
}
const current = () => state.mode === "rivals" ? state.rvView : state.mode === "collections" && Col.viewing ? "col:" + Col.viewing : currentView();
// link de uma aba: plataformas da busca, empresas da análise de mercado ou itens das coleções
const getLink = id => state.links.find(l => l.id === id) || Rivals.link(id) || Col.link(id);
const curWeb = () => webviews.get(current())?.el;
$("#wbBack").onclick = () => { const w = curWeb(); if (!w) return; if (EXT) history.back(); else if (w.canGoBack()) w.goBack(); };
$("#wbFwd").onclick = () => { const w = curWeb(); if (!w) return; if (EXT) history.forward(); else if (w.canGoForward()) w.goForward(); };
$("#wbReload").onclick = () => { const w = curWeb(); if (!w) return; const r = webviews.get(current()); if (r) { r.loading = true; setLoading(true); } if (EXT) w.src = w.src; else w.reload(); };
$("#wbSave").onclick = async e => {
  const w = curWeb(); if (!w) return;
  const btn = e.currentTarget;
  let shot = "";
  const link = getLink(current());
  let url = link?.url || "", title = link ? (link.title || `${link.name}: ${link.query}`) : "Página";
  try {
    if (EXT) { shot = await api.capture(w.getBoundingClientRect().toJSON()); }
    else { const img = await w.capturePage(); shot = img.resize({ width: 900 }).toDataURL(); url = w.getURL(); title = w.getTitle() || title; }
  } catch {}
  Col.pick({ id: "page:" + url, kind: "page", title, thumb: shot, page: url,
    sourceName: link?.name || "Página", author: "", license: { code: "rights", label: "Página salva (só referência)", commercial: false, modify: false, attribution: true } }, btn);
};
/* ------------------------------------------------------------------ mídias da página (baixar de sites sem botão de download) */
const PM = {
  data: null, filter: "all", sel: new Set(),
  host: u => { try { return new URL(u).hostname.replace(/^www\./, ""); } catch { return "pagina"; } },
  async open() {
    const w = curWeb(); if (!w) return;
    $("#pmedia").hidden = false; $("#pmTitle").textContent = "Mídias da página"; convState();
    $("#pmConvOut").innerHTML = "";
    $("#pmBar").innerHTML = ""; $("#pmGrid").innerHTML = `<div class="loading"><div class="spin"></div></div>`;
    let d = null;
    const link = getLink(current());
    const hint = (() => { try { return new URL(link.url).hostname.replace(/^www\./, "").split(".").slice(-2).join("."); } catch { return ""; } })();
    try { d = EXT ? await api.pageMedia(w.name, hint) : await w.executeJavaScript(`(${avantHubCollectMedia.toString()})()`); } catch (e) { d = { error: String(e) }; }
    if (!d || d.error) {
      const why = d && d.error === "perm"
        ? `A extensão ainda não tem a permissão nova para ler páginas. Abra <b>opera://extensions</b> (ou chrome://extensions), clique em <b>⟳</b> no AVANT Hub e, se o navegador pedir, aceite as permissões. Depois abra esta aba de novo.`
        : d && d.error === "noframe" ? `Não achei a página aberta. Espere ela terminar de carregar (a barrinha laranja some) e tente de novo.`
        : `O navegador recusou ler esta página. Detalhe técnico: ${esc(d && d.error || "desconhecido")}`;
      $("#pmGrid").innerHTML = `<div class="empty"><b>Não consegui ler esta página</b>${why}</div>`; return;
    }
    this.data = d; this.filter = "all"; this.sel = new Set(); this.render();
    if (IGC.code(d.href) && !$("#pmLink").value) $("#pmLink").value = d.href; // já está num post: deixa o link pronto
  },
  ext(it) { const m = /\.(jpe?g|png|webp|gif|avif|mp4|webm|mov)(?:$|[?#])/i.exec(it.url); return m ? m[1].toLowerCase().replace("jpeg", "jpg") : it.type === "video" ? "mp4" : "jpg"; },
  name(it, i) { return `${this.host(this.data.href)}-${new Date().toISOString().slice(0, 10)}-${i + 1}.${this.ext(it)}`; },
  list() { return this.data.items.filter(it => this.filter === "all" || it.type === this.filter); },
  render() {
    const d = this.data, items = d.items, list = this.list();
    const nImg = items.filter(x => x.type === "image").length, nVid = items.filter(x => x.type === "video").length;
    $("#pmTitle").textContent = `Mídias da página · ${this.host(d.href)}`;
    $("#pmBar").innerHTML = `
      <div class="seg">${[["all", `Todas (${items.length})`], ["image", `Fotos (${nImg})`], ["video", `Vídeos (${nVid})`]].map(([v, l]) => `<button data-pf="${v}" class="${this.filter === v ? "on" : ""}">${l}</button>`).join("")}</div>
      <button class="ghost small" id="pmAll">${this.sel.size && this.sel.size === list.length ? "Limpar seleção" : "Selecionar todas"}</button>
      <span class="spacer"></span>
      <button class="btn btn-acc small" id="pmDown" ${this.sel.size ? "" : "disabled"}>${ico("download")}Baixar ${this.sel.size || ""} selecionada${this.sel.size === 1 ? "" : "s"}</button>
      ${d.blobVideos ? `<div class="pm-note">${d.blobVideos} vídeo${d.blobVideos > 1 ? "s" : ""} desta página vem protegido pelo site e não dá para baixar por aqui. A capa dele aparece na lista. Use <b>Salvar página</b> para guardar a referência.</div>` : ""}
      ${EXT ? `<div class="pm-note soft">Os arquivos vão para a pasta Downloads\\AVANT Hub. Role a página do site antes para carregar mais fotos e abra de novo esta janela.</div>` : ""}`;
    $("#pmGrid").innerHTML = list.length ? list.map(it => {
      const i = items.indexOf(it);
      return `<div class="pm-card ${this.sel.has(i) ? "on" : ""}" data-i="${i}">
        <div class="pm-thumb">${it.type === "video" ? `<video src="${esc(it.url)}" muted preload="metadata"></video><span class="pm-kind">Vídeo</span>` : `<img src="${esc(it.url)}" referrerpolicy="no-referrer" alt="">`}
          <label class="pm-check"><input type="checkbox" ${this.sel.has(i) ? "checked" : ""}></label></div>
        <div class="pm-info"><span>${it.w && it.h ? `${it.w}×${it.h}` : it.type === "video" ? "vídeo" : "imagem"}</span>
          <div class="pm-acts"><button data-a="down" title="Baixar">${ico("download")}</button><button data-a="save" title="Salvar numa coleção">${ico("star")}</button><button data-a="open" title="Abrir o arquivo">${ico("ext")}</button></div></div>
      </div>`;
    }).join("") : `<div class="empty"><b>Nada encontrado aqui</b>Role a página do site para carregar as fotos e tente de novo.</div>`;
    $("#pmBar").querySelectorAll("[data-pf]").forEach(b => b.onclick = () => { this.filter = b.dataset.pf; this.render(); });
    convState();
    $("#pmAll").onclick = () => { const idx = list.map(it => items.indexOf(it)); const all = idx.every(i => this.sel.has(i)); idx.forEach(i => all ? this.sel.delete(i) : this.sel.add(i)); this.render(); };
    $("#pmDown").onclick = () => this.download([...this.sel]);
    $("#pmGrid").querySelectorAll(".pm-card").forEach(c => {
      const i = +c.dataset.i, it = items[i];
      c.querySelector("input").onchange = e => { e.target.checked ? this.sel.add(i) : this.sel.delete(i); this.render(); };
      c.querySelector(".pm-thumb").onclick = e => { if (e.target.closest(".pm-check")) return; this.sel.has(i) ? this.sel.delete(i) : this.sel.add(i); this.render(); };
      c.querySelector('[data-a="down"]').onclick = () => this.download([i]);
      c.querySelector('[data-a="open"]').onclick = () => api.open(it.url);
      c.querySelector('[data-a="save"]').onclick = e => Col.pick({ id: "media:" + it.url, kind: it.type === "video" ? "video" : "image", title: it.alt || `${this.host(d.href)} · ${d.title || ""}`.trim(),
        thumb: it.type === "video" ? "" : it.url, full: it.url, video: it.type === "video" ? it.url : undefined, page: d.href, sourceName: this.host(d.href), author: "",
        license: { code: "rights", label: "Mídia de terceiros (só referência)", commercial: false, modify: false, attribution: true } }, e.currentTarget);
      const im = c.querySelector("img"); if (im) im.onerror = () => { im.replaceWith(Object.assign(document.createElement("span"), { className: "pm-noprev", textContent: "Prévia bloqueada pelo site. O download funciona." })); };
    });
  },
  async download(idx) {
    if (!idx.length) return;
    const list = idx.map(i => ({ url: this.data.items[i].url, name: this.name(this.data.items[i], i) }));
    if (EXT) { const n = await api.downloadMany(list); toast(n ? `${n} arquivo${n > 1 ? "s" : ""} em Downloads\\AVANT Hub` : "Não consegui baixar"); }
    else { list.forEach(x => api.download(x.url)); toast("Baixando…"); }
  },
};
/* conversor: link de post/reel do Instagram -> MP4 (arquivo original) e MP3 (áudio extraído aqui mesmo) */
const IGC = {
  code(u) { const m = /instagram\.com\/(?:[^/?#]+\/)?(?:p|reel|reels|tv)\/([A-Za-z0-9_-]+)/.exec(u || ""); return m && m[1]; },
  async go() {
    if (store.get("pmConv", "open") !== "open") convState("open");
    const out = $("#pmConvOut"), code = this.code($("#pmLink").value.trim());
    if (!code) { out.innerHTML = `<div class="pm-note">Cole um link de post ou reel, como <b>instagram.com/reel/ABC123</b>. Links de perfil não servem aqui.</div>`; return; }
    if (!EXT) { out.innerHTML = `<div class="pm-note">O conversor funciona na extensão do navegador.</div>`; return; }
    out.innerHTML = `<div class="loading"><div class="spin"></div></div>`;
    let d; try { d = await api.igFetch(code); } catch { d = { items: [] }; }
    if (!d.items.length) {
      out.innerHTML = `<div class="pm-note">Não achei a mídia desse post. Ele pode ser privado ou ter saído do ar. Se for de uma conta privada que você segue, abra o post aqui no hub e use a lista de mídias abaixo.</div>`; return;
    }
    this.d = { ...d, code };
    const who = d.author ? "@" + d.author : "Instagram";
    const isReel = /\/(reel|reels|tv)\//.test($("#pmLink").value);
    const onlyCover = !d.items.some(x => x.type === "video") && (isReel || d.via === "embed");
    const warn = !onlyCover ? "" : d.logged
      ? `<div class="pm-note">O Instagram só liberou a capa deste post agora. Se for vídeo, espere uns minutos e tente de novo, ou abra o post aqui no hub e use a lista de mídias.</div>`
      : `<div class="pm-note">Se for vídeo, o Instagram só libera o MP4 para quem está logado. <b>Entre no Instagram neste navegador</b> (no botão 👤, em Contas) e tente de novo.${d.limited ? " O Instagram também está limitando consultas sem login agora." : ""}</div>`;
    out.innerHTML = `<div class="pm-conv-head"><b>${esc(who)}</b>${d.caption ? `<span>${esc(d.caption.slice(0, 140))}</span>` : ""}</div>${warn}
      <div class="pm-conv-grid">${d.items.map((it, i) => `
        <div class="pm-conv-card">
          ${it.type === "video" ? `<video src="${esc(it.url)}" controls preload="metadata" playsinline></video>` : `<img src="${esc(it.url)}" referrerpolicy="no-referrer" alt="">`}
          <div class="pm-conv-acts">${it.type === "video"
            ? `<button class="btn btn-acc small" data-mp4="${i}">${ico("download")}MP4</button><button class="btn small" data-mp3="${i}">${ico("musica")}MP3</button>`
            : `<button class="btn btn-acc small" data-img="${i}">${ico("download")}Foto</button>`}
            <button class="ghost small" data-sv="${i}" title="Salvar numa coleção">${ico("star")}</button></div>
        </div>`).join("")}</div>`;
    const name = (i, ext) => `instagram-${d.author || code}-${code}-${i + 1}.${ext}`;
    out.querySelectorAll("[data-mp4],[data-img]").forEach(b => b.onclick = async () => {
      const i = +(b.dataset.mp4 ?? b.dataset.img), it = d.items[i];
      const n = await api.downloadMany([{ url: it.url, name: name(i, it.type === "video" ? "mp4" : "jpg") }]);
      toast(n ? "Baixado em Downloads\\AVANT Hub" : "Não consegui baixar");
    });
    out.querySelectorAll("[data-mp3]").forEach(b => b.onclick = () => this.mp3(d.items[+b.dataset.mp3].url, name(+b.dataset.mp3, "mp3"), b));
    out.querySelectorAll("[data-sv]").forEach(b => b.onclick = e => {
      const it = d.items[+b.dataset.sv];
      Col.pick({ id: "ig:" + it.url.split("?")[0], kind: it.type === "video" ? "video" : "image", title: d.caption ? d.caption.slice(0, 80) : `${who} · ${code}`,
        thumb: it.type === "video" ? "" : it.url, full: it.url, video: it.type === "video" ? it.url : undefined, page: `https://www.instagram.com/p/${code}/`,
        sourceName: "Instagram", author: d.author || "", license: { code: "rights", label: "Mídia de terceiros (só referência)", commercial: false, modify: false, attribution: true } }, e.currentTarget);
    });
  },
  // extrai o áudio do vídeo e gera um MP3 (192 kbps) no próprio navegador
  async mp3(url, filename, btn) {
    const old = btn.innerHTML; btn.disabled = true;
    const status = t => { btn.innerHTML = t; };
    try {
      status("Baixando…");
      const ab = await (await api.fetchBlob(url)).arrayBuffer();
      status("Lendo áudio…");
      const actx = new (window.AudioContext || window.webkitAudioContext)();
      let buf; try { buf = await actx.decodeAudioData(ab); } finally { actx.close(); }
      const ch = Math.min(2, buf.numberOfChannels), rate = buf.sampleRate;
      const enc = new lamejs.Mp3Encoder(ch, rate, 192);
      const toI16 = f => { const o = new Int16Array(f.length); for (let k = 0; k < f.length; k++) { const v = Math.max(-1, Math.min(1, f[k])); o[k] = v < 0 ? v * 0x8000 : v * 0x7fff; } return o; };
      const L = toI16(buf.getChannelData(0)), R = ch > 1 ? toI16(buf.getChannelData(1)) : null;
      const parts = [], step = 1152;
      for (let k = 0, n = 0; k < L.length; k += step, n++) {
        const a = L.subarray(k, k + step), mp = R ? enc.encodeBuffer(a, R.subarray(k, k + step)) : enc.encodeBuffer(a);
        if (mp.length) parts.push(new Uint8Array(mp));
        if (n % 300 === 0) { status(`Convertendo ${Math.round(k / L.length * 100)}%`); await new Promise(r => setTimeout(r)); }
      }
      const end = enc.flush(); if (end.length) parts.push(new Uint8Array(end));
      const ok = await api.downloadBlob(new Blob(parts, { type: "audio/mpeg" }), filename);
      toast(ok ? `MP3 salvo em Downloads\\AVANT Hub (${Math.round(buf.duration)} s)` : "Não consegui salvar o MP3");
    } catch (e) {
      toast(/decode|Unable to decode|EncodingError/i.test(String(e)) ? "Esse vídeo veio sem trilha de áudio" : "Não consegui gerar o MP3");
    } finally { btn.disabled = false; btn.innerHTML = old; }
  },
};
$("#pmGo").onclick = () => IGC.go();
// conversor: aberto, minimizado ou fechado (fica lembrado)
function convState(v) {
  if (v) store.set("pmConv", v); v = store.get("pmConv", "open");
  $("#pmConv").hidden = v === "closed";
  $("#pmConv").classList.toggle("min", v === "min");
  $("#pmConvMin").innerHTML = ico(v === "min" ? "down" : "up"); $("#pmConvMin").title = v === "min" ? "Abrir" : "Minimizar";
  const b = $("#pmConvShow"); if (b) b.hidden = v !== "closed";
}
$("#pmConvMin").onclick = () => convState(store.get("pmConv", "open") === "min" ? "open" : "min");
$("#pmConvClose").onclick = () => convState("closed");
$("#pmConvShow").onclick = () => { convState("open"); $("#pmScroll").scrollTop = 0; $("#pmLink").focus(); };
$("#pmConv .pm-conv-top").ondblclick = () => $("#pmConvMin").click();
$("#pmLink").onkeydown = e => { if (e.key === "Enter") IGC.go(); };
$("#wbMedia").onclick = () => PM.open();
$("#pmClose").onclick = () => { $("#pmedia").hidden = true; };
$("#pmedia").onclick = e => { if (e.target.id === "pmedia") $("#pmedia").hidden = true; };
$("#wbOpen").onclick = () => { const w = curWeb(); const u = w && !EXT ? w.getURL() : getLink(current())?.url; if (u) api.open(u); };

/* ------------------------------------------------------------------ visualizador */
let cur = -1, lbList = [];
async function openLB(i, list = state.items) {
  lbList = list;
  const it = lbList[i]; if (!it) return;
  cur = i;
  const st = $("#lbstage");
  if (it.external) {
    // YouTube e Vimeo tocam numa página embutida (iframe não funciona em app local)
    st.innerHTML = "";
    st.appendChild(makeFrame(EXT ? embedUrl(it.external) : it.external));
  } else if (it.kind === "page") {
    st.innerHTML = `<img referrerpolicy="no-referrer" src="${esc(it.localThumb || it.thumb)}" alt="">`;
  } else if (it.kind === "video" && it.embed && !it.video) {
    st.innerHTML = `<iframe src="${esc(it.embed)}" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
  } else if (it.kind === "video" || (it.kind === "gif" && it.video)) {
    st.innerHTML = `<div class="spin"></div>`;
    const v = await mediaUrl(it, "video");
    if (cur !== i) return;
    st.innerHTML = v ? `<video src="${esc(v)}" poster="${esc(it.thumb)}" ${it.kind === "gif" ? "autoplay loop muted" : "controls autoplay"} playsinline></video>`
      : `<img src="${esc(it.thumb)}" alt="">`;
  } else {
    if (it.kind === "icon") st.style.setProperty("--iconbg", iconColors().bg);
    st.innerHTML = `<img class="${it.kind === "icon" ? "icon" : ""}" referrerpolicy="no-referrer" src="${esc(it.localThumb || it.thumb)}" alt="">`;
    if (it.full && it.full !== it.thumb) {
      const big = new Image(); big.referrerPolicy = "no-referrer";
      big.onload = () => { if (cur === i) { const im = st.querySelector("img"); if (im) im.src = big.src; } };
      big.src = it.full;
    }
  }
  $("#lbt").textContent = it.title || "Sem título";
  $("#lbm").textContent = [it.sourceName, it.author && "por " + it.author].filter(Boolean).join(" · ");
  const l = $("#lblic"); l.className = "lic " + licClass(it.license); l.textContent = it.license?.label || "Licença não informada";
  $("#lbcredit").onclick = () => copy(credit(it));
  $("#lbsave").onclick = e => Col.pick(it, e.currentTarget);
  $("#lbdown").textContent = it.kind === "icon" ? "Baixar SVG" : "Baixar";
  $("#lbdown").onclick = () => download(it);
  $("#lbsrc").onclick = () => it.page && api.open(it.page);
  $("#lb").classList.add("open");
}
// No iframe usa o player de incorporação de cada site
function embedUrl(u) {
  let m = /youtube\.com\/watch\?v=([\w-]+)/.exec(u); if (m) return `https://www.youtube-nocookie.com/embed/${m[1]}?autoplay=1&rel=0`;
  m = /vimeo\.com\/(\d+)/.exec(u); if (m) return `https://player.vimeo.com/video/${m[1]}?autoplay=1`;
  return u;
}
function closeLB() { $("#lb").classList.remove("open"); $("#lbstage").innerHTML = ""; cur = -1; }
function step(d) { if (cur < 0) return; const n = cur + d; if (n >= 0 && n < lbList.length) openLB(n, lbList); }
$("#lbx").onclick = closeLB; $("#lbp").onclick = () => step(-1); $("#lbn").onclick = () => step(1);
$("#lb").onclick = e => { if (e.target.id === "lb" || e.target.id === "lbstage") closeLB(); };
document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    if (!$("#savePop").hidden) { $("#savePop").hidden = true; return; }
    if (!$("#itemEdit").hidden) { $("#itemEdit").hidden = true; return; }
    if (!$("#rvEdit").hidden) { $("#rvEdit").hidden = true; return; }
    if (!$("#pmedia").hidden) { $("#pmedia").hidden = true; return; }
    if (!$("#accounts").hidden) { $("#accounts").hidden = true; return; }
    if (!$("#keys").hidden) { closeKeys(); return; }
  }
  if (cur < 0) return;
  if (e.key === "Escape") closeLB();
  if (e.key === "ArrowRight") step(1);
  if (e.key === "ArrowLeft") step(-1);
});

/* ------------------------------------------------------------------ chaves */
async function openKeys(tab) {
  setSTab(typeof tab === "string" ? tab : "look");
  renderLook();
  const d = await api.getKeys();
  // só as chaves das fontes de áudio (os únicos tipos com Galeria)
  const used = new Set(Object.values(state.types).filter(t => t.gallery).flatMap(t => t.sources.flatMap(x => x.keys || [])));
  $("#keyList").innerHTML = d.list.filter(k => used.has(k.key) || k.value).map(k => `
    <div class="krow">
      <div class="kn">${esc(k.name)}<small>Usado em: ${esc(k.usedBy.join(", "))}</small></div>
      <input data-key="${esc(k.key)}" value="${esc(k.value)}" placeholder="${k.team ? "usando a chave da equipe" : "cole a chave aqui"}" spellcheck="false">
      <div class="kh">${esc(k.note)} <a data-help="${esc(k.help)}">Pegar chave</a>${k.team ? ' · <span class="teamok">chave da equipe ativa</span>' : ""}</div>
    </div>`).join("");
  $("#keyList").querySelectorAll("[data-help]").forEach(a => a.onclick = () => api.open(a.dataset.help));
  $("#teamNote").textContent = d.teamFile ? `Arquivo da equipe carregado: ${d.teamFile}`
    : EXT ? "Para passar as chaves para um colega, use Exportar." : "Dica: coloque um refhub_config.json ao lado do .exe para já abrir com as chaves da equipe.";
  $("#keys").hidden = false;
}
function closeKeys() { $("#keys").hidden = true; }
$("#openKeys").onclick = () => openKeys("look");
function setSTab(t) {
  document.querySelectorAll(".stab").forEach(b => b.classList.toggle("on", b.dataset.stab === t));
  $("#sLook").hidden = t !== "look"; $("#sKeys").hidden = t !== "keys"; $("#sUpd").hidden = t !== "upd";
  if (t === "upd") Upd.render();
}
document.querySelectorAll(".stab").forEach(b => b.onclick = () => setSTab(b.dataset.stab));
function renderLook() {
  const prev = th => {
    const bg = th.mode === "dark" ? mixHex(th.pri, "#13161e", 0.88) : "#ffffff";
    return `<div class="prev" style="background:linear-gradient(${th.pri} 0 42%, ${bg} 42%)"><i style="width:34%;background:${th.sec}"></i><i style="width:22%;background:${th.pri}"></i><i style="width:16%;background:${th.mode === "dark" ? "#3a4256" : "#dfe3ea"}"></i></div>`;
  };
  const warn = contrast(look.pri, look.ter) < 3 ? `<div class="cwarn">A terciária quase some sobre a primária. Escolha uma cor mais clara ou mais escura.</div>` : "";
  $("#sLook").innerHTML = `
    <div class="sgroup"><h3>Temas prontos</h3><div class="themes">${THEMES.map(th => `
      <button class="theme ${look.theme === th.id ? "on" : ""}" data-theme="${th.id}">${prev(th)}<span>${esc(th.name)}<br><small>${esc(th.note)}</small></span></button>`).join("")}
    </div></div>
    <div class="sgroup"><h3>Modo</h3><div class="seg" id="lkMode" style="display:inline-flex">
      ${[["light", "sun", "Claro"], ["dark", "moon", "Escuro"], ["auto", "monitor", "Igual ao sistema"]].map(([v, i, l]) => `<button data-mode="${v}" class="${look.mode === v ? "on" : ""}" style="display:inline-flex;gap:6px;align-items:center;padding:6px 14px">${ico(i)}${l}</button>`).join("")}
    </div></div>
    <div class="sgroup"><h3>Cores</h3><div class="colors">
      ${[["pri", "Primária", "Cabeçalho, botões e seleção"], ["sec", "Secundária", "Destaques: Buscar, Salvar, abas"], ["ter", "Terciária", "Texto e ícones sobre a primária"]].map(([k, l, d]) => `
        <label class="cpick"><input type="color" data-c="${k}" value="${look[k]}"><span><b>${l}</b><span>${d}</span></span><input class="hex" data-hex="${k}" value="${look[k]}" maxlength="7" spellcheck="false"></label>`).join("")}
    </div>${warn}</div>
    <div class="sgroup"><h3>Logo</h3>
      <div class="logo-prev"><span class="logo-mark"><i class="lg-l"></i><i class="lg-a"></i></span><span class="hub">Hub</span></div>
      <div class="seg" id="lkLogo" style="display:inline-flex;margin-top:10px">
        ${[["original", "Original da marca"], ["theme", "Acompanha o tema"], ["custom", "Personalizada"]].map(([v, l]) => `<button data-logo="${v}" class="${look.logo === v ? "on" : ""}" style="padding:6px 14px">${l}</button>`).join("")}
      </div>
      ${look.logo === "custom" ? `<div class="colors" style="margin-top:12px">
        ${[["logoL", "Letras", "AVANT e Energia"], ["logoA", "Detalhe", "O V cortado"], ["logoH", "Palavra Hub", "Ao lado do logo"]].map(([k, l, d]) => `
          <label class="cpick"><input type="color" data-c="${k}" value="${look[k]}"><span><b>${l}</b><span>${d}</span></span><input class="hex" data-hex="${k}" value="${look[k]}" maxlength="7" spellcheck="false"></label>`).join("")}
      </div>` : ""}
    </div>
    <div class="sgroup"><h3>Tamanho da interface</h3>
      <div class="srow"><span class="muted" style="margin:0">Menor</span><input type="range" id="lkUi" min="0.8" max="1.15" step="0.01" value="${look.ui}"><span class="muted" style="margin:0">Maior</span><output id="lkUiOut">${Math.round(look.ui * 100)}%</output></div>
      <p class="muted small">Menor mostra mais do site embutido na tela. O site em si não muda de tamanho.</p>
      <label class="scheck"><input type="checkbox" id="lkIcons" ${look.typeIcons ? "checked" : ""}>Mostrar os tipos só com ícone (economiza espaço)</label>
    </div>
    <div class="modal-foot"><button class="ghost" id="lkReset">${ico("reset")}Voltar ao padrão AVANT</button><span class="spacer"></span><span class="muted small" style="margin:0">As mudanças valem na hora.</span></div>`;
  const L = $("#sLook");
  L.querySelectorAll("[data-theme]").forEach(b => b.onclick = () => {
    const th = THEMES.find(x => x.id === b.dataset.theme);
    Object.assign(look, { theme: th.id, pri: th.pri, sec: th.sec, ter: th.ter, mode: th.mode }); saveLook(); renderLook();
  });
  L.querySelectorAll("[data-mode]").forEach(b => b.onclick = () => { look.mode = b.dataset.mode; look.theme = "custom"; saveLook(); renderLook(); });
  const setColor = (k, v) => { if (!/^#[0-9a-f]{6}$/i.test(v)) return; look[k] = v.toLowerCase(); if (!k.startsWith("logo")) look.theme = "custom"; saveLook(); };
  L.querySelectorAll("[data-logo]").forEach(b => b.onclick = () => {
    if (b.dataset.logo === "custom" && look.logo !== "custom") { // começa das cores que estão na tela
      const cs = getComputedStyle(document.documentElement);
      look.logoL = cs.getPropertyValue("--logo-l").trim() || "#ffffff"; look.logoA = cs.getPropertyValue("--logo-a").trim() || "#f18f09"; look.logoH = cs.getPropertyValue("--logo-h").trim() || "#ffffff";
    }
    look.logo = b.dataset.logo; saveLook(); renderLook();
  });
  L.querySelectorAll("[data-c]").forEach(el => {
    el.oninput = () => { setColor(el.dataset.c, el.value); L.querySelector(`[data-hex="${el.dataset.c}"]`).value = el.value; };
    el.onchange = () => renderLook();
  });
  L.querySelectorAll("[data-hex]").forEach(el => el.onchange = () => { setColor(el.dataset.hex, el.value.startsWith("#") ? el.value : "#" + el.value); renderLook(); });
  $("#lkUi").oninput = e => { look.ui = +e.target.value; $("#lkUiOut").textContent = Math.round(look.ui * 100) + "%"; saveLook(); };
  $("#lkIcons").onchange = e => { look.typeIcons = e.target.checked; saveLook(); };
  $("#lkReset").onclick = () => { Object.assign(look, LOOK_DEFAULT); saveLook(); renderLook(); toast("Aparência AVANT restaurada"); };
}
$("#keysClose").onclick = closeKeys;
$("#keys").onclick = e => { if (e.target.id === "keys") closeKeys(); };
$("#keysSave").onclick = async () => {
  const keys = {};
  $("#keyList").querySelectorAll("input").forEach(i => { if (i.value.trim()) keys[i.dataset.key] = i.value.trim(); });
  await api.setKeys(keys);
  await reloadTypes(); closeKeys(); toast("Chaves salvas"); if (state.mode === "search") refresh(false);
};
$("#keysExport").onclick = async () => { if (await api.exportKeys()) toast("Arquivo salvo. Mande para a equipe junto com a extensão."); };
$("#keysImport").onclick = async () => { if (await api.importKeys()) { await reloadTypes(); openKeys(); toast("Chaves importadas"); } };

/* ------------------------------------------------------------------ util */
let tt;
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(tt); tt = setTimeout(() => t.classList.remove("show"), 2600); }
async function reloadTypes() { state.types = await api.types(); renderFilters(); }
function intro() {
  const t = T();
  const ready = t.sources.filter(x => x.ready).length;
  $("#understood").innerHTML = `<span>Digite o assunto e use os filtros de ${esc(t.label)}. Use "aspas" para frase exata. Clique em ★ para guardar o que gostar.</span>`;
  $("#after").innerHTML = ready < t.sources.length
    ? `<div class="empty"><b>Galeria com ${ready} de ${t.sources.length} fontes ligadas</b>As outras precisam de chave grátis. As abas ao lado (${esc(state.links.slice(0, 3).map(l => l.name).join(", "))}…) funcionam sem chave.
      <div class="row"><button class="ghost" id="introKeys">⚙ Adicionar chaves</button></div></div>` : "";
  const b = $("#introKeys"); if (b) b.onclick = () => openKeys("keys");
}

/* ------------------------------------------------------------------ coleções */
const COLORS = ["#003da5", "#f18f09", "#14915a", "#1f9bd1", "#c2410c", "#7c3aed", "#db2777", "#64748b"];
const KIND_LABEL = { palette: "Paleta", text: "Texto", tool: "Ferramenta", image: "Imagem", gif: "GIF", icon: "Ícone", video: "Vídeo", audio: "Áudio", model: "3D", page: "Página" };
// reduz uma imagem do computador para caber na coleção (JPEG)
function shrinkImage(file, max) {
  return new Promise(res => {
    const fr = new FileReader();
    fr.onload = () => { const im = new Image(); im.onload = () => {
      const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement("canvas");
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL("image/jpeg", 0.86));
    }; im.onerror = () => res(""); im.src = fr.result; };
    fr.onerror = () => res(""); fr.readAsDataURL(file);
  });
}
// capa da coleção: imagem de um item, cor e ícone, ou imagem enviada
function coverImg(b) {
  if (b.coverMode === "color") return "";
  if (b.coverMode === "upload" && b.coverImg) return b.coverImg;
  const c = (b.cover && b.items.find(x => x.uid === b.cover)) || b.items.find(x => x.localThumb || x.thumb);
  return c ? (c.localThumb || c.thumb || "") : "";
}
const Col = {
  data: { boards: [] }, cur: null, sort: "manual", find: "", tag: "", kind: "", sideFind: "", sel: new Set(), selecting: false, lookOpen: false, linkOpen: false,
  view: store.get("colView", "grid"), size: store.get("colSize", 220), last: store.get("lastBoard", null),
  async load() {
    try { this.data = await api.colGet(); } catch {} if (!this.data.boards) this.data.boards = [];
    // coisas salvas pelo menu do botão direito do navegador chegam aqui
    api.onColChanged?.(d => { if (d && d.boards) { this.data = d; this.renderSide(); this.renderMain(); } });
  },
  save() { api.colSave(this.data); },
  board(id) { return this.data.boards.find(b => b.id === id); },
  isSaved(id) { return this.data.boards.some(b => b.items.some(x => x.id === id)); },
  create(name) {
    const b = { id: "b" + Date.now().toString(36), name: name || "Nova coleção", color: COLORS[this.data.boards.length % COLORS.length],
      emoji: "", desc: "", cover: "", items: [], createdAt: Date.now() };
    this.data.boards.unshift(b); this.save(); return b;
  },
  // guarda só o que precisa para mostrar e abrir de novo
  slim(it) {
    const keep = ["id", "kind", "title", "thumb", "thumb2", "full", "video", "audio", "embed", "external", "resolve", "page", "author",
      "license", "sourceName", "source", "w", "h", "duration", "download", "waveform", "meta", "colors", "text", "fromTool"];
    return Object.fromEntries(keep.filter(k => it[k] !== undefined).map(k => [k, it[k]]));
  },
  async add(boardId, it) {
    const b = this.board(boardId); if (!b) return;
    if (b.items.some(x => x.id === it.id)) return;
    const saved = { ...this.slim(it), uid: "i" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), note: "", tags: [], savedAt: Date.now() };
    b.items.unshift(saved); this.touch(b);
    this.last = boardId; store.set("lastBoard", boardId);
    this.save(); this.markSaved(it.id, true);
    toast(`Salvo em "${b.name}"`);
    const src = it.thumb || it.full;
    if (src) { const local = await api.colCache(src); if (local) { saved.localThumb = local; this.save(); if (this.cur === boardId) this.renderMain(); } }
    this.renderSide();
  },
  remove(boardId, id) {
    const b = this.board(boardId); if (!b) return;
    b.items = b.items.filter(x => x.id !== id);
    this.save(); this.markSaved(id, this.isSaved(id)); this.renderSide();
  },
  markSaved(id, on) {
    state.items.forEach((x, i) => { if (x.id !== id) return;
      const card = $("#results .grid")?.children[i]; card?.querySelector(".save")?.classList.toggle("saved", on);
      const row = $("#results .audio-list")?.children[i]; row?.querySelector('[data-a="save"]')?.classList.toggle("saved", on); });
  },

  // escolher coleção (popover)
  pick(it, anchor) {
    const pop = $("#savePop");
    const draw = () => {
      const ordered = [...this.data.boards].sort((a, c) => (c.id === this.last) - (a.id === this.last) || (c.pin ? 1 : 0) - (a.pin ? 1 : 0) || (c.updatedAt || 0) - (a.updatedAt || 0));
      pop.innerHTML = `<h4>Salvar em</h4>` + (ordered.length ? ordered.map(b => {
        const has = b.items.some(x => x.id === it.id);
        return `<button class="pb" data-b="${b.id}"><span class="dot" style="background:${b.color}"></span>${esc(b.emoji ? b.emoji + " " : "")}${esc(b.name)}<span class="chk">${has ? "✓" : ""}</span></button>`;
      }).join("") : `<div class="muted small" style="padding:4px 8px">Nenhuma coleção ainda.</div>`) +
        `<div class="pnew"><input id="pnName" placeholder="Nova coleção…"><button class="btn" id="pnOk">Criar</button></div>`;
      pop.querySelectorAll("[data-b]").forEach(b => b.onclick = () => {
        const bd = this.board(b.dataset.b);
        bd.items.some(x => x.id === it.id) ? this.remove(bd.id, it.id) : this.add(bd.id, it);
        setTimeout(draw, 0);
      });
      const mk = () => { const n = $("#pnName").value.trim(); if (!n) return; const b = this.create(n); this.add(b.id, it); this.renderSide(); draw(); };
      $("#pnOk").onclick = mk;
      $("#pnName").onkeydown = e => { if (e.key === "Enter") mk(); };
    };
    draw();
    const r = anchor.getBoundingClientRect();
    pop.hidden = false;
    const w = 260, h = pop.offsetHeight;
    pop.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w)) + "px";
    pop.style.top = (r.bottom + h + 8 > window.innerHeight ? Math.max(8, r.top - h - 6) : r.bottom + 6) + "px";
  },

  // tela de coleções
  open(id) {
    this.back = state.mode === "collections" ? this.back : state.mode;
    setMode("collections");
    if (id) this.cur = id;
    if (!this.cur || (this.cur !== "all" && !this.board(this.cur))) this.cur = this.data.boards.length ? "all" : null;
    this.renderSide(); this.renderMain();
  },
  close() { setMode(this.back === "search" && state.q ? "search" : "home"); },
  // marca a coleção como mexida agora (para ordenar a lateral)
  touch(b) { if (b) b.updatedAt = Date.now(); },
  boardsSorted() {
    const f = norm(this.sideFind || "");
    return this.data.boards.filter(b => !f || norm(b.name).includes(f))
      .sort((a, c) => (c.pin ? 1 : 0) - (a.pin ? 1 : 0) || (c.updatedAt || c.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
  },
  // endereço que dá para abrir: a página de origem, o vídeo externo ou o arquivo
  urlOf(it) { const u = it.page || it.external || (/^https?:/.test(it.full || "") ? it.full : ""); return /^https?:/.test(u || "") ? u : ""; },
  link(id) {
    const m = /^col:(.+)$/.exec(id || ""); if (!m) return null;
    for (const b of this.data.boards) { const it = b.items.find(x => x.uid === m[1]); if (it) return { id, name: it.sourceName || "Coleção", url: this.urlOf(it), query: "", serp: false, title: it.title || "Página salva" }; }
    return null;
  },
  viewing: null,
  // abre o item salvo aqui dentro, no mesmo visualizador da busca
  // Google e YouTube não deixam o hub abrir as páginas deles num quadro (o navegador recusa e fica "bloqueado"): abrem em outra aba
  cantEmbed(url) { try { const h = new URL(url).hostname; return /(^|\.)(google\.[a-z.]+|youtube\.com|youtu\.be|gmail\.com|googleusercontent\.com)$/.test(h); } catch { return false; } },
  viewItem(uid) {
    const b = this.board(this.cur); const it = b?.items.find(x => x.uid === uid); if (!it || !this.urlOf(it)) return;
    if (this.cantEmbed(this.urlOf(it))) { api.open(this.urlOf(it)); toast("Esse site não abre dentro do hub. Abri em outra aba."); return; }
    this.viewing = uid;
    const list = this.visible(b).filter(x => this.urlOf(x)), i = list.findIndex(x => x.uid === uid);
    this.renderSide();
    $("#colMain").hidden = true; $("#colView").hidden = false;
    $("#cvTitle").textContent = it.title || "Sem título";
    $("#cvFrom").textContent = b.name;
    $("#cvPos").textContent = list.length > 1 ? `${i + 1} de ${list.length}` : "";
    $("#cvPrev").disabled = i <= 0; $("#cvNext").disabled = i < 0 || i >= list.length - 1;
    $("#cvPrev").onclick = () => list[i - 1] && this.viewItem(list[i - 1].uid);
    $("#cvNext").onclick = () => list[i + 1] && this.viewItem(list[i + 1].uid);
    $("#cvBody").appendChild($("#webpane")); $("#webpane").hidden = false;
    showWeb("col:" + uid);
  },
  closeView() {
    if (!this.viewing) return;
    this.viewing = null; $("#colView").hidden = true; $("#colMain").hidden = false;
    wpSpot.after($("#webpane")); $("#webpane").hidden = state.mode !== "search";
  },
  // miniatura da coleção (capa, ou cor com emoji)
  tileHtml(b, big) {
    const img = coverImg(b);
    return `<span class="mk-tile ${big ? "big" : ""} ${img ? "img" : ""}" style="${img ? `background-image:url('${esc(img)}')` : `--fc:${esc(b.color)}`}">${img ? "" : b.emoji ? `<em>${esc(b.emoji)}</em>` : ico("star")}</span>`;
  },
  isAll() { return this.cur === "all"; },
  renderSide() {
    if (state.mode !== "collections") return;
    const list = this.boardsSorted();
    const total = this.data.boards.reduce((n, b) => n + b.items.length, 0);
    $("#colList").innerHTML = `
      <button class="mk-row ${this.isAll() ? "on" : ""}" data-all="1"><span class="mk-tile all">${ico("layers")}</span><b>Todos os itens</b><span class="mk-n">${total}</span></button>
      <div class="mk-label"><span>Coleções</span><button class="linkbtn" id="colNew">${ico("plus")}Nova coleção</button></div>
      ${list.map(b => `
        <div class="mk-row ${b.id === this.cur ? "on" : ""}" data-b="${b.id}" role="button" tabindex="0" style="--fc:${esc(b.color)}" title="Arraste itens até aqui para copiar (Shift move)">
          ${this.tileHtml(b)}<b>${esc(b.name)}</b>
          ${b.pin ? `<span class="mk-pin" title="Fixada no topo">${ico("star")}</span>` : ""}
          <span class="mk-n">${b.items.length}</span>
          <span class="mk-fed" data-pin="${b.id}" role="button" title="${b.pin ? "Desafixar" : "Fixar no topo"}">${ico("star")}</span>
          <span class="mk-fed" data-look="${b.id}" role="button" title="Capa, cor e ícone">${ico("pencil")}</span>
        </div>`).join("") || `<div class="mk-empty">${this.sideFind ? "Nenhuma coleção com esse nome." : "Crie sua primeira coleção."}</div>`}`;
    const L = $("#colList");
    $("#colNew").onclick = () => { const b = this.create("Nova coleção"); this.closeView(); this.cur = b.id; this.renderSide(); this.renderMain(); setTimeout(() => { const n = $("#cName"); n?.focus(); n?.select(); }, 0); };
    L.querySelector("[data-all]").onclick = () => this.go("all");
    L.querySelectorAll("[data-pin]").forEach(el => el.onclick = e => { e.stopPropagation(); const b = this.board(el.dataset.pin); b.pin = !b.pin; this.save(); this.renderSide(); });
    L.querySelectorAll("[data-look]").forEach(el => el.onclick = e => { e.stopPropagation(); this.go(el.dataset.look, true); this.lookOpen = true; this.renderMain(); });
    L.querySelectorAll("[data-b]").forEach(el => {
      // clicar de novo na coleção aberta volta para Todos os itens
      el.onclick = () => this.go(el.dataset.b === this.cur && !this.viewing ? "all" : el.dataset.b);
      el.onkeydown = e => { if (e.key === "Enter") el.click(); };
      el.ondragover = e => { if (![...e.dataTransfer.types].includes("text/uid")) return; e.preventDefault(); el.classList.add("drop"); };
      el.ondragleave = () => el.classList.remove("drop");
      el.ondrop = e => {
        e.preventDefault(); el.classList.remove("drop");
        const uids = (e.dataTransfer.getData("text/uids") || e.dataTransfer.getData("text/uid") || "").split(",").filter(Boolean);
        const from = e.dataTransfer.getData("text/from") || this.cur;
        const to = this.board(el.dataset.b); if (!uids.length || !to || to.id === from) return;
        const n = this.transfer(uids, to.id, e.shiftKey, from);
        toast(e.shiftKey ? `${n} movido(s) para "${to.name}"` : `${n} copiado(s) para "${to.name}" (Shift move)`);
      };
    });
  },
  go(id, keep) {
    this.closeView(); this.cur = id;
    if (!keep) { this.tag = ""; this.find = ""; this.kind = ""; this.lookOpen = false; this.linkOpen = false; }
    this.sel.clear(); this.selecting = false;
    this.renderSide(); this.renderMain(); $("#colBody")?.scrollTo(0, 0);
  },
  // copia (ou move) itens de uma coleção para outra
  transfer(uids, toId, move, fromId = this.cur) {
    const from = this.board(fromId), to = this.board(toId); if (!from || !to) return 0;
    let n = 0;
    for (const uid of uids) {
      const it = from.items.find(x => x.uid === uid); if (!it) continue;
      if (!to.items.some(x => x.id === it.id)) { to.items.unshift({ ...it, uid: "i" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5) }); n++; }
      if (move) from.items = from.items.filter(x => x.uid !== uid);
    }
    this.touch(from); this.touch(to); this.sel.clear(); this.save(); this.renderSide(); this.renderMain();
    return n;
  },
  filterList(items) {
    let list = items.slice();
    const f = this.find && norm(this.find);
    if (f) list = list.filter(x => norm(`${x.title} ${x.note} ${(x.tags || []).join(" ")} ${x.sourceName}`).includes(f));
    if (this.tag) list = list.filter(x => (x.tags || []).includes(this.tag));
    if (this.kind) list = list.filter(x => this.kindOf(x) === this.kind);
    if (this.sort === "recentes") list.sort((a, c) => c.savedAt - a.savedAt);
    if (this.sort === "antigos") list.sort((a, c) => a.savedAt - c.savedAt);
    if (this.sort === "titulo") list.sort((a, c) => (a.title || "").localeCompare(c.title || ""));
    if (this.sort === "fonte") list.sort((a, c) => (a.sourceName || "").localeCompare(c.sourceName || ""));
    return list;
  },
  visible(b) { return this.filterList(b.items); },
  kindOf(x) { return x.kind === "gif" || x.kind === "icon" ? "image" : x.kind === "model" ? "image" : x.kind || "image"; },
  // botões de um item: mesmo tamanho, uma linha só
  itemActs(it) {
    const q = (a, icon, title) => `<button class="mk-q" data-a="${a}" title="${title}">${ico(icon)}</button>`;
    return `<div class="mk-qs">${this.urlOf(it) ? q("open", "globe", "Abrir aqui no hub") + q("src", "ext", "Abrir no navegador") : ""}${q("cover", "media", "Usar como capa da coleção")}${q("edit", "pencil", "Nota, tags, copiar ou mover")}${q("del", "x", "Tirar da coleção")}</div>`;
  },
  renderMain() {
    if (state.mode !== "collections") return;
    const m = $("#colMain");
    const all = this.isAll();
    const b = all ? null : this.board(this.cur);
    if (!all && !b) {
      m.innerHTML = `<div class="col-body"><div class="cempty"><b>Nenhuma coleção ainda</b>Nas plataformas, clique em <b>Salvar página</b>, em ★ nos áudios, ou baixe mídias em <b>Mídias da página</b> e salve aqui.<br><br><button class="btn" id="cmNew">Criar coleção</button></div></div>`;
      $("#cmNew").onclick = () => { const nb = this.create("Minha coleção"); this.cur = nb.id; this.renderSide(); this.renderMain(); };
      return;
    }
    const pool = all ? this.data.boards.flatMap(x => x.items) : b.items;
    const tagCount = {}; pool.forEach(x => (x.tags || []).forEach(t => tagCount[t] = (tagCount[t] || 0) + 1));
    if (this.tag && !tagCount[this.tag]) this.tag = "";
    const counts = { image: 0, video: 0, page: 0, audio: 0, palette: 0, text: 0, tool: 0 };
    pool.forEach(x => { counts[this.kindOf(x)] = (counts[this.kindOf(x)] || 0) + 1; });
    const kinds = [["", "Tudo", pool.length, "layers"], ["image", "Imagens", counts.image, "media"], ["video", "Vídeos", counts.video, "video"], ["page", "Páginas", counts.page, "globe"], ["audio", "Áudios", counts.audio, "musica"], ["palette", "Paletas", counts.palette, "paint"], ["text", "Textos", counts.text, "note"], ["tool", "Ferramentas", counts.tool, "tools"]].filter(k => k[0] === "" || k[2]);
    const list = all ? null : this.visible(b);
    const others = all ? [] : this.data.boards.filter(x => x.id !== b.id);
    const upd = b && (b.updatedAt || b.createdAt);
    m.style.setProperty("--colw", this.size + "px");
    const head = all ? `
      <div class="col-head">
        <div class="mk-head"><span class="mk-tile big all">${ico("layers")}</span><div><h2>Todos os itens</h2><span>${pool.length} ${pool.length === 1 ? "item" : "itens"} em ${this.data.boards.length} ${this.data.boards.length === 1 ? "coleção" : "coleções"}</span></div></div>
        <span class="spacer"></span>
      </div>` : `
      <div class="col-head">
        <div class="mk-head">${this.tileHtml(b, true)}
          <div class="col-ttl"><input class="cname" id="cName" value="${esc(b.name)}" spellcheck="false" title="Clique para renomear">
            <span>${b.items.length} ${b.items.length === 1 ? "item" : "itens"}${upd ? ` · atualizada ${new Date(upd).toLocaleDateString("pt-BR")}` : ""}</span></div></div>
        <span class="spacer"></span>
        <button class="ghost small ${this.lookOpen ? "on" : ""}" id="cLook">${ico("paint")}Capa e cor</button>
        <button class="ghost small" id="cExport">${ico("download")}Exportar</button>
        <button class="ghost small" id="cLinkBtn">${ico("ext")}Adicionar link</button>
        <button class="btn btn-acc small" id="cUpload">${ico("upload")}Enviar arquivos</button>
        <button class="mk-q ghosty" id="cDel" title="Apagar a coleção">${ico("trash")}</button>
      </div>`;
    const look = !all && this.lookOpen ? `<div class="clook">
        <div class="clook-row"><span>Capa</span><div class="seg">${[["auto", "Imagem de um item"], ["color", "Cor e ícone"], ["upload", "Imagem enviada"]].map(([v, l]) => `<button data-cm="${v}" class="${(b.coverMode || "auto") === v ? "on" : ""}">${l}</button>`).join("")}</div>
          <button class="ghost small" id="cCoverUp">${ico("upload")}${b.coverImg ? "Trocar imagem" : "Enviar imagem"}</button></div>
        ${(b.coverMode || "auto") === "auto" ? `<div class="muted small">Para escolher o item da capa, clique em ${ico("media")} <b>Usar como capa</b> no item.</div>` : ""}
        <div class="clook-row"><span>Cor</span><div class="swatches">${COLORS.map(c => `<span class="sw ${c === b.color ? "on" : ""}" data-c="${c}" style="background:${c}"></span>`).join("")}</div></div>
        <div class="clook-row"><span>Ícone</span><input id="cEmoji" class="cemoji" value="${esc(b.emoji || "")}" maxlength="2" placeholder="☺" title="Ícone da coleção (emoji)"><span class="muted small" style="margin:0">Um emoji. Aparece quando a capa é <b>Cor e ícone</b>.</span></div>
        <div class="clook-row"><span>Sobre</span><input id="cDesc" class="cdesc2" value="${esc(b.desc || "")}" placeholder="Para que serve esta coleção? (opcional)"></div>
      </div>` : "";
    const tools = `
      <div class="col-tools">
        <div class="mk-find">${ico("search")}<input id="cFind" placeholder="Procurar ${all ? "em todas as coleções" : "nesta coleção"}" value="${esc(this.find)}" spellcheck="false"></div>
        <div class="mk-filter">${kinds.map(([v, l, n, i]) => `<button class="mk-tog neutral ${(this.kind || "") === v ? "on" : ""}" data-kind="${v}">${ico(i)}${l}<small>${n}</small></button>`).join("")}</div>
        <span class="spacer"></span>
        <select class="sel" id="cSort" title="Ordem">
          ${[["manual", "Ordem manual"], ["recentes", "Mais recentes"], ["antigos", "Mais antigos"], ["titulo", "Título"], ["fonte", "Fonte"]].map(([v, l]) => `<option value="${v}" ${v === this.sort ? "selected" : ""}>${l}</option>`).join("")}
        </select>
        <div class="seg mk-vseg"><button data-view="grid" class="${this.view === "grid" ? "on" : ""}">${ico("grid")}Cartões</button><button data-view="list" class="${this.view === "list" ? "on" : ""}">${ico("list")}Lista</button></div>
        ${this.view === "grid" ? `<input type="range" id="cSize" min="200" max="400" step="20" value="${this.size}" title="Tamanho dos cartões">` : ""}
        ${all ? "" : `<button class="ghost small ${this.selecting ? "on" : ""}" id="cSelect">${ico("check")}${this.selecting ? "Concluir" : "Selecionar"}</button>`}
      </div>
      ${Object.keys(tagCount).length ? `<div class="mk-filter col-tags"><span class="mk-flabel">${ico("tag")}Filtrar por tag</span>
        ${Object.entries(tagCount).sort((x, y) => y[1] - x[1]).map(([t, n]) => `<button class="mk-tog info ${this.tag === t ? "on" : ""}" data-tag="${esc(t)}"><i></i>#${esc(t)}<small>${n}</small></button>`).join("")}
        ${this.tag ? `<button class="linkbtn" data-tag="">Limpar</button>` : ""}</div>` : ""}`;
    const bulk = !all && this.selecting ? `<div class="cbulk">
        <b>${this.sel.size} selecionado${this.sel.size === 1 ? "" : "s"}</b>
        <button class="linkbtn" id="bAll">${list.length && list.every(x => this.sel.has(x.uid)) ? "Limpar" : "Selecionar todos"}</button>
        <span class="spacer"></span>
        ${others.length ? `<select class="sel" id="bTarget"><option value="">Mover ou copiar para…</option>${others.map(o => `<option value="${o.id}">${esc(o.name)}</option>`).join("")}</select>
        <button class="ghost small" id="bCopy" ${this.sel.size ? "" : "disabled"}>Copiar</button><button class="ghost small" id="bMove" ${this.sel.size ? "" : "disabled"}>Mover</button>` : ""}
        <input class="btag" id="bTag" placeholder="+ tag" ${this.sel.size ? "" : "disabled"}>
        <button class="ghost small" id="bDown" ${this.sel.size ? "" : "disabled"}>${ico("download")}Baixar</button>
        <button class="ghost small danger" id="bDel" ${this.sel.size ? "" : "disabled"}>${ico("trash")}Remover</button>
      </div>` : "";
    const holder = id => `<div class="${this.view === "list" ? "mk-list" : "cgrid"}" id="${id}"></div>`;
    let content;
    if (all) {
      const secs = this.boardsSorted().map(x => [x, this.filterList(x.items)]).filter(([, l]) => l.length);
      content = secs.length ? secs.map(([x, l]) => `<section class="mk-sec"><h3 data-goto="${x.id}"><i style="background:${esc(x.color)}"></i>${esc(x.name)}<small>${l.length}</small><span class="mk-seeall">Abrir coleção ${ico("chev")}</span></h3>${holder("cg-" + x.id)}</section>`).join("")
        : `<div class="cempty"><b>${pool.length ? "Nada com esse filtro" : "Nenhum item salvo ainda"}</b>${pool.length ? "Tente outra busca ou limpe o filtro." : "Nas plataformas, clique em <b>Salvar página</b> ou em ★ para guardar aqui."}</div>`;
    } else {
      content = list.length ? holder("cGrid") : `<div class="cempty"><b>${b.items.length ? "Nada com esse filtro" : "Coleção vazia"}</b>${b.items.length ? "Tente outra busca ou limpe o filtro." : "Arraste imagens do computador para cá, cole (Ctrl+V) uma imagem ou um link, ou use <b>Salvar página</b> na busca."}</div>`;
    }
    m.innerHTML = `${head}
      <div class="col-body" id="colBody">
        ${look}
        ${!all && this.linkOpen ? `<div class="clink"><input id="cLinkIn" placeholder="Cole o link de uma imagem ou de uma página (Enter para adicionar)" spellcheck="false"><button class="btn small" id="cLinkOk">Adicionar</button></div>` : ""}
        ${tools}${bulk}
        <div class="cdrop" id="cDrop">${content}<div class="cdrop-hint">Solte aqui para adicionar à coleção</div></div>
      </div>`;

    // filtros e visualização
    $("#cFind").oninput = e => { this.find = e.target.value; const pos = e.target.selectionStart; this.renderMain(); const f = $("#cFind"); f.focus(); f.setSelectionRange(pos, pos); };
    m.querySelectorAll("[data-kind]").forEach(el => el.onclick = () => { this.kind = this.kind === el.dataset.kind ? "" : el.dataset.kind; this.renderMain(); });
    m.querySelectorAll("[data-tag]").forEach(el => el.onclick = () => { this.tag = this.tag === el.dataset.tag ? "" : el.dataset.tag; this.renderMain(); });
    $("#cSort").onchange = e => { this.sort = e.target.value; this.renderMain(); };
    m.querySelectorAll("[data-view]").forEach(el => el.onclick = () => { this.view = el.dataset.view; store.set("colView", this.view); this.renderMain(); });
    const sz = $("#cSize"); if (sz) sz.oninput = e => { this.size = +e.target.value; store.set("colSize", this.size); m.style.setProperty("--colw", this.size + "px"); };
    m.querySelectorAll("[data-goto]").forEach(h => h.onclick = () => this.go(h.dataset.goto));

    if (all) {
      for (const x of this.data.boards) { const g = $("#cg-" + x.id); if (g) this.fill(g, x, this.filterList(x.items), true); }
      return;
    }
    const upd2 = () => { this.touch(b); this.save(); this.renderSide(); };
    $("#cName").oninput = e => { b.name = e.target.value; upd2(); };
    $("#cLook").onclick = () => { this.lookOpen = !this.lookOpen; this.renderMain(); };
    if (this.lookOpen) {
      $("#cDesc").oninput = e => { b.desc = e.target.value; this.save(); };
      $("#cEmoji").onchange = e => { b.emoji = e.target.value.trim(); b.coverMode = "color"; upd2(); this.renderMain(); };
      m.querySelectorAll("[data-c]").forEach(el => el.onclick = () => { b.color = el.dataset.c; b.coverMode = "color"; upd2(); this.renderMain(); });
      m.querySelectorAll("[data-cm]").forEach(el => el.onclick = () => {
        if (el.dataset.cm === "upload" && !b.coverImg) { $("#cCoverUp").click(); return; }
        b.coverMode = el.dataset.cm; upd2(); this.renderMain();
      });
      $("#cCoverUp").onclick = () => {
        const inp = document.createElement("input"); inp.type = "file"; inp.accept = "image/*";
        inp.onchange = async () => {
          const f = inp.files[0]; if (!f) return;
          const url = await shrinkImage(f, 600); if (!url) { toast("Não consegui abrir essa imagem"); return; }
          b.coverImg = url; b.coverMode = "upload"; upd2(); this.renderMain(); toast("Capa atualizada");
        };
        inp.click();
      };
    }
    $("#cUpload").onclick = () => $("#colFile").click();
    $("#cLinkBtn").onclick = () => { this.linkOpen = !this.linkOpen; this.renderMain(); if (this.linkOpen) $("#cLinkIn").focus(); };
    if (this.linkOpen) {
      const go = () => { const v = $("#cLinkIn").value.trim(); if (v) { this.addLink(b, v); this.linkOpen = false; } };
      $("#cLinkOk").onclick = go; $("#cLinkIn").onkeydown = e => { if (e.key === "Enter") go(); if (e.key === "Escape") { this.linkOpen = false; this.renderMain(); } };
    }
    $("#cSelect").onclick = () => { this.selecting = !this.selecting; this.sel.clear(); this.renderMain(); };
    $("#cExport").onclick = async () => { if (await api.colExport(b)) toast("Coleção exportada. Mande o arquivo para quem quiser."); };
    $("#cDel").onclick = () => {
      if (!$("#cDel").dataset.armed) { $("#cDel").dataset.armed = "1"; $("#cDel").classList.add("armed"); toast("Clique de novo na lixeira para apagar a coleção"); setTimeout(() => { const d = $("#cDel"); if (d) { delete d.dataset.armed; d.classList.remove("armed"); } }, 2500); return; }
      this.data.boards = this.data.boards.filter(x => x.id !== b.id); this.cur = this.data.boards[0]?.id || "all";
      this.save(); this.renderSide(); this.renderMain(); toast("Coleção apagada");
    };
    // ações em lote
    if (this.selecting) {
      const sel = () => [...this.sel];
      $("#bAll").onclick = () => { const every = list.every(x => this.sel.has(x.uid)); list.forEach(x => every ? this.sel.delete(x.uid) : this.sel.add(x.uid)); this.renderMain(); };
      const tgt = () => $("#bTarget")?.value;
      if ($("#bCopy")) $("#bCopy").onclick = () => { if (!tgt()) { toast("Escolha a coleção de destino"); return; } const n = this.transfer(sel(), tgt(), false); toast(`${n} copiado(s)`); };
      if ($("#bMove")) $("#bMove").onclick = () => { if (!tgt()) { toast("Escolha a coleção de destino"); return; } const k = this.sel.size; this.transfer(sel(), tgt(), true); toast(`${k} movido(s)`); };
      $("#bTag").onkeydown = e => {
        if (e.key !== "Enter") return;
        const t = e.target.value.trim().toLowerCase().replace(/^#/, ""); if (!t) return;
        b.items.forEach(x => { if (this.sel.has(x.uid)) x.tags = [...new Set([...(x.tags || []), t])]; });
        upd2(); this.renderMain(); toast(`Tag #${t} aplicada`);
      };
      $("#bDown").onclick = () => this.downloadItems(b.items.filter(x => this.sel.has(x.uid)));
      $("#bDel").onclick = () => {
        if (!confirmInline($("#bDel"), `Remover ${this.sel.size}?`)) return;
        const n = this.sel.size; b.items = b.items.filter(x => !this.sel.has(x.uid)); this.sel.clear();
        upd2(); this.renderMain(); toast(`${n} removido(s)`);
      };
    }
    // soltar arquivos do computador
    const drop = $("#cDrop");
    drop.ondragover = e => { if ([...e.dataTransfer.types].includes("Files")) { e.preventDefault(); drop.classList.add("over"); } };
    drop.ondragleave = e => { if (!drop.contains(e.relatedTarget)) drop.classList.remove("over"); };
    drop.ondrop = e => { if (!e.dataTransfer.files.length) return; e.preventDefault(); drop.classList.remove("over"); this.addFiles(b, e.dataTransfer.files); };
    const g = $("#cGrid"); if (g) this.fill(g, b, list, false);
  },
  // cartões (ou linhas) de itens dentro de um contêiner
  fill(g, b, list, inAll) {
    b.items.filter(x => !x.localThumb && x.thumb && !x._caching).forEach(x => {
      x._caching = true;
      api.colCache(x.thumb).then(l => { delete x._caching; if (l) { x.localThumb = l; this.save(); } });
    });
    const upd2 = () => { this.touch(b); this.save(); this.renderSide(); };
    list.forEach((it, i) => {
      const c = document.createElement("div");
      const on = this.sel.has(it.uid);
      const isList = this.view === "list";
      c.className = (isList ? "mk-lrow crow2" : "ccard2") + (on ? " sel" : "") + (this.selecting ? " selecting" : "");
      c.draggable = true; c.dataset.uid = it.uid;
      const img = it.localThumb || it.thumb || "";
      const date = it.savedAt ? new Date(it.savedAt).toLocaleDateString("pt-BR") : "";
      const meta = `${esc(KIND_LABEL[it.kind] || "Item")}${it.sourceName ? " · " + esc(it.sourceName) : ""}`;
      const thumb = `<div class="cimg ${it.kind === "icon" ? "contain" : ""}" style="${img ? `background-image:url('${esc(img)}')` : ""}">${img ? "" : `<span class="cnoimg">${ico(it.kind === "page" ? "globe" : it.kind === "audio" ? "musica" : it.kind === "video" ? "video" : "media")}</span>`}
          ${this.selecting ? `<span class="ccheck">${on ? ico("check") : ""}</span>` : ""}${b.cover === it.uid && (b.coverMode || "auto") === "auto" ? `<span class="ccover" title="Capa da coleção">${ico("star")}</span>` : ""}</div>`;
      const tags = (it.tags || []).length ? `<div class="mk-tags">${it.tags.map(t => `<span class="mk-tag info"><i></i>#${esc(t)}</span>`).join("")}</div>` : "";
      c.innerHTML = isList
        ? `<div class="mk-lname">${thumb}<div class="mk-ct"><b title="${esc(it.title)}">${esc(it.title || "Sem título")}</b><span>${meta}${date ? " · " + date : ""}</span></div></div>
           ${inAll ? `<div class="mk-lfold"><i style="background:${esc(b.color)}"></i>${esc(b.name)}</div>` : ""}
           <div>${tags}</div><div class="mk-lobs">${esc(it.note || "")}</div>${this.itemActs(it)}`
        : `${thumb}<div class="ccb"><div class="mk-ct"><b title="${esc(it.title)}">${esc(it.title || "Sem título")}</b><span>${meta}</span></div>
            <div class="mk-tags ccb-tags">${(it.tags || []).map(t => `<span class="mk-tag info"><i></i>#${esc(t)}</span>`).join("")}</div><p class="mk-obs ccb-note">${esc(it.note || "")}</p></div>
           <footer>${this.itemActs(it)}</footer>`;
      const openIt = () => {
        if (this.selecting) { on ? this.sel.delete(it.uid) : this.sel.add(it.uid); this.renderMain(); return; }
        if (it.kind === "audio" || it.kind === "palette" || it.kind === "text" || it.kind === "tool") { this.edit(b, it); return; }
        if (it.kind === "page" && this.urlOf(it)) { if (inAll) this.cur = b.id; this.viewItem(it.uid); return; }
        openLB(i, list);
      };
      c.onclick = e => {
        const a = e.target.closest("[data-a]");
        if (!a) { if (!isList || e.target.closest(".cimg, .mk-ct")) openIt(); return; }
        const act = a.dataset.a;
        if (act === "edit") this.edit(b, it);
        if (act === "cover") { b.cover = it.uid; b.coverMode = "auto"; upd2(); this.renderMain(); toast(`Capa de "${b.name}" atualizada`); }
        if (act === "open") { if (inAll) this.cur = b.id; this.viewItem(it.uid); }
        if (act === "src") api.open(this.urlOf(it));
        if (act === "del") { this.remove(b.id, it.id); this.touch(b); this.renderMain(); }
      };
      c.ondragstart = e => {
        const uids = this.selecting && this.sel.has(it.uid) ? [...this.sel] : [it.uid];
        e.dataTransfer.setData("text/uids", uids.join(",")); e.dataTransfer.setData("text/uid", it.uid); e.dataTransfer.setData("text/from", b.id); c.classList.add("dragging");
      };
      c.ondragend = () => c.classList.remove("dragging");
      if (!inAll) {
        c.ondragover = e => { if (!e.dataTransfer.types.includes("text/uid")) return; e.preventDefault(); c.classList.add("over"); };
        c.ondragleave = () => c.classList.remove("over");
        c.ondrop = e => {
          const uid = e.dataTransfer.getData("text/uid"); if (!uid) return;
          e.preventDefault(); e.stopPropagation(); c.classList.remove("over");
          if (uid === it.uid) return;
          const from = b.items.findIndex(x => x.uid === uid), to = b.items.findIndex(x => x.uid === it.uid);
          if (from < 0) return;
          const [mv] = b.items.splice(from, 1); b.items.splice(to, 0, mv);
          this.sort = "manual"; this.save(); this.renderMain();
        };
      }
      g.appendChild(c);
    });
  },
  // arquivos do computador (imagens): guarda uma cópia reduzida dentro da coleção
  async addFiles(b, files) {
    const imgs = [...files].filter(f => /^image\//.test(f.type));
    if (!imgs.length) { toast("Por enquanto dá para enviar imagens (JPG, PNG, WEBP, GIF)"); return; }
    const shrink = (src, max, type = "image/jpeg") => new Promise(res => {
      const im = new Image(); im.onload = () => {
        const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement("canvas");
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
        res({ url: c.toDataURL(type, 0.86), w: im.width, h: im.height });
      }; im.onerror = () => res(null); im.src = src;
    });
    let n = 0;
    for (const f of imgs) {
      const raw = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
      const png = /png|gif|webp/.test(f.type);
      const full = await shrink(raw, 1800, png ? "image/png" : "image/jpeg"), th = await shrink(raw, 480);
      if (!full) continue;
      b.items.unshift({ id: "up:" + Date.now().toString(36) + n + f.name, uid: "i" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        kind: "image", title: f.name.replace(/\.[^.]+$/, ""), thumb: th.url, localThumb: th.url, full: full.url, w: full.w, h: full.h,
        sourceName: "Enviado por você", author: "", license: { code: "rights", label: "Arquivo enviado", commercial: false, modify: false, attribution: false },
        note: "", tags: [], savedAt: Date.now() });
      n++;
    }
    this.touch(b); this.save(); this.renderSide(); this.renderMain();
    toast(`${n} ${n === 1 ? "imagem adicionada" : "imagens adicionadas"}`);
  },
  // link colado: imagem vira item de imagem; o resto vira página
  async addLink(b, url) {
    if (!/^https?:\/\//i.test(url)) { toast("Cole um link que comece com http"); return; }
    const host = (() => { try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return "link"; } })();
    const isImg = /\.(jpe?g|png|webp|gif|avif|svg)(\?|#|$)/i.test(url), isVid = /\.(mp4|webm|mov)(\?|#|$)/i.test(url);
    const it = { id: "link:" + url, uid: "i" + Date.now().toString(36), kind: isImg ? "image" : isVid ? "video" : "page",
      title: isImg || isVid ? decodeURIComponent(url.split("/").pop().split("?")[0]).replace(/\.[^.]+$/, "") || host : host,
      thumb: isImg ? url : "", full: isImg ? url : undefined, video: isVid ? url : undefined, page: url, sourceName: host, author: "",
      license: { code: "rights", label: "Link salvo (só referência)", commercial: false, modify: false, attribution: true }, note: "", tags: [], savedAt: Date.now() };
    if (b.items.some(x => x.id === it.id)) { toast("Esse link já está na coleção"); return; }
    b.items.unshift(it); this.touch(b); this.save(); this.renderSide(); this.renderMain(); toast("Link adicionado");
    if (isImg) { const l = await api.colCache(url); if (l) { it.localThumb = l; this.save(); this.renderMain(); } }
  },
  async downloadItems(items) {
    const list = items.map((x, i) => {
      const url = x.download || x.video || x.audio || x.full || x.localThumb || x.thumb; if (!url) return null;
      const ext = (/\.(jpe?g|png|webp|gif|mp4|webm|mp3|wav|ogg|svg)(\?|$)/i.exec(url) || [])[1] || (x.kind === "video" ? "mp4" : x.kind === "audio" ? "mp3" : /^data:image\/png/.test(url) ? "png" : "jpg");
      const nm = (x.title || "item").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 60) || "item";
      return { url, name: `${nm}-${i + 1}.${ext.toLowerCase().replace("jpeg", "jpg")}` };
    }).filter(Boolean);
    if (!list.length) { toast("Esses itens são só links. Use Abrir a fonte."); return; }
    if (EXT && api.downloadMany) { const n = await api.downloadMany(list); toast(`${n} arquivo(s) em Downloads\\AVANT Hub`); }
    else list.forEach(x => api.download(x.url));
  },
  // itens salvos pelas ferramentas: cores, texto e atalho
  preview(it) {
    if (it.kind === "audio") return `<audio controls src="${esc(it.audio || "")}" style="width:100%"></audio>`;
    if (it.kind === "palette") return `<div class="ie-sw">${(it.colors || []).map(c => `<button class="ie-sw-i" data-hex="${esc(c)}" style="background:${esc(c)}" title="Copiar ${esc(c)}"><span>${esc(c)}</span></button>`).join("")}</div><div class="muted small">Clique numa cor para copiar o código.</div>`;
    if (it.kind === "text") return `<textarea class="ie-text" readonly spellcheck="false">${esc(it.text || "")}</textarea>`;
    if (it.kind === "tool") return `<div class="ieprev" style="background-image:url('${esc(it.localThumb || "")}')"></div><div class="muted small">Atalho para ${esc(it.fromTool?.title || "a ferramenta")}.</div>`;
    return `<div class="ieprev" style="background-image:url('${esc(it.localThumb || it.thumb || "")}')"></div>`;
  },
  extraBtns(it) {
    if (it.kind === "palette") return `<button class="ghost" id="ieHex">Copiar HEX</button><button class="ghost" id="ieCss">Copiar CSS</button><button class="ghost" id="ieGen">Abrir no gerador</button>`;
    if (it.kind === "text") return `<button class="ghost" id="ieTxt">Copiar texto</button>`;
    if (it.kind === "tool") return `<button class="ghost" id="ieTool">Abrir ferramenta</button>`;
    if (it.fromTool) return `<button class="ghost" id="ieDown">Baixar</button>`;
    return `<button class="ghost" id="ieDown">Baixar</button><button class="ghost" id="ieCred">Copiar crédito</button>`;
  },
  wireExtra(it) {
    document.querySelectorAll("#ieBody [data-hex]").forEach(b => b.onclick = () => copy(b.dataset.hex, b.dataset.hex + " copiado"));
    const on = (id, fn) => { const e = $(id); if (e) e.onclick = fn; };
    const cols = it.colors || [];
    on("#ieHex", () => copy(cols.join("\n"), "Cores copiadas"));
    on("#ieCss", () => copy(`:root {\n${cols.map((c, i) => `  --cor-${i + 1}: ${c};`).join("\n")}\n}`, "CSS copiado"));
    on("#ieGen", () => { $("#itemEdit").hidden = true; Tools.go(`#/tools/palette-genny?colors=${cols.map(c => c.slice(1)).join(",")}`); });
    on("#ieTxt", () => copy(it.text || "", "Texto copiado"));
    on("#ieTool", () => { $("#itemEdit").hidden = true; Tools.go(it.fromTool?.hash || ""); });
  },
  edit(b, it) {
    const others = this.data.boards.filter(x => x.id !== b.id);
    $("#ieBody").innerHTML = `
      ${this.preview(it)}
      <div><label>Título</label><input id="ieTitle" value="${esc(it.title || "")}"></div>
      <div><label>Nota</label><textarea id="ieNote" placeholder="Por que guardou? Onde vai usar?">${esc(it.note || "")}</textarea></div>
      <div><label>Tags (separe por vírgula)</label><input id="ieTags" value="${esc((it.tags || []).join(", "))}" placeholder="ex.: campanha verão, cliente X, paleta"></div>
      ${others.length ? `<div><label>Copiar / mover para</label><select id="ieMove"><option value="">—</option>${others.map(o => `<option value="${o.id}">${esc(o.name)}</option>`).join("")}</select></div>` : ""}
      <div class="muted small">${esc(it.sourceName || "")}${it.author ? " · " + esc(it.author) : ""} · ${esc(it.license?.label || "")}</div>
      <div class="ie-row">
        ${others.length ? `<button class="ghost" id="ieCopy">Copiar</button><button class="ghost" id="ieMv">Mover</button>` : ""}
        ${this.extraBtns(it)}<button class="btn" id="ieOk">Salvar</button>
      </div>`;
    $("#itemEdit").hidden = false;
    const commit = () => {
      it.title = $("#ieTitle").value.trim() || it.title;
      it.note = $("#ieNote").value.trim();
      it.tags = [...new Set($("#ieTags").value.split(",").map(t => t.trim().toLowerCase().replace(/^#/, "")).filter(Boolean))];
      this.save();
    };
    const target = () => this.board($("#ieMove")?.value);
    $("#ieOk").onclick = () => { commit(); $("#itemEdit").hidden = true; this.renderMain(); };
    if ($("#ieDown")) $("#ieDown").onclick = () => download(it);
    if ($("#ieCred")) $("#ieCred").onclick = () => copy(credit(it));
    this.wireExtra(it);
    if ($("#ieCopy")) {
      $("#ieCopy").onclick = () => { const t = target(); if (!t) return; commit(); if (!t.items.some(x => x.id === it.id)) t.items.unshift({ ...it, uid: "i" + Date.now().toString(36) }); this.save(); this.renderSide(); toast(`Copiado para "${t.name}"`); };
      $("#ieMv").onclick = () => { const t = target(); if (!t) return; commit(); if (!t.items.some(x => x.id === it.id)) t.items.unshift(it); b.items = b.items.filter(x => x.uid !== it.uid); this.save(); $("#itemEdit").hidden = true; this.renderSide(); this.renderMain(); toast(`Movido para "${t.name}"`); };
    }
  },
};
function confirmInline(btn, msg) {
  if (btn.dataset.armed) return true;
  btn.dataset.armed = "1"; const old = btn.textContent; btn.textContent = msg;
  setTimeout(() => { btn.textContent = old; delete btn.dataset.armed; }, 2500);
  return false;
}
const norm = s => String(s || "").normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase();

$("#openCollections").onclick = () => { if (state.mode !== "collections") Col.open(); };
// Banco de mídia: volta para a busca em andamento, ou para o início se não houver
$("#openMedia").onclick = () => { if (state.mode === "search") return; state.q ? setMode("search") : goHome(); };
$("#goHome").onclick = e => { e.preventDefault(); goHome(); };
$("#colBack").onclick = () => Col.close();
$("#colImport").onclick = async () => {
  const boards = await api.colImport();
  for (const b of boards) {
    const nb = { ...b, id: "b" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5) };
    for (const it of nb.items) if (/^data:image/.test(it.localThumb || "")) it.localThumb = await api.colCache(it.localThumb) || it.thumb;
    Col.data.boards.unshift(nb);
  }
  if (boards.length) { Col.cur = Col.data.boards[0].id; Col.save(); Col.renderSide(); Col.renderMain(); toast(`${boards.length} coleção(ões) importada(s)`); }
};
$("#ieClose").onclick = () => { $("#itemEdit").hidden = true; };
$("#colSideFind").oninput = e => { Col.sideFind = e.target.value; Col.renderSide(); };
$("#colSideNew").onclick = () => $("#colNew")?.click();
$("#colFile").onchange = e => { const b = Col.board(Col.cur) || Col.create("Minha coleção"); Col.cur = b.id; Col.addFiles(b, e.target.files); e.target.value = ""; };
// colar (Ctrl+V) imagem ou link dentro de Coleções
document.addEventListener("paste", e => {
  if (state.mode !== "collections" || /^(INPUT|TEXTAREA)$/.test(document.activeElement?.tagName)) return;
  const b = Col.board(Col.cur); if (!b) return;
  const files = [...(e.clipboardData?.files || [])];
  if (files.length) { e.preventDefault(); Col.addFiles(b, files); return; }
  const t = (e.clipboardData?.getData("text") || "").trim();
  if (/^https?:\/\//.test(t)) { e.preventDefault(); Col.addLink(b, t); }
});
document.addEventListener("mousedown", e => { const p = $("#savePop"); if (!p.hidden && !p.contains(e.target) && !e.target.closest(".save,#lbsave,#wbSave,[data-a='save']")) p.hidden = true; });

/* ------------------------------------------------------------------ contas */
// Contas: login de cada site (domínio + cookie que indica "logado"). auth = nomes conhecidos; sem auth, usa a regra geral.
const ACC_GROUPS = [
  ["Design e inspiração", [
    { id: "pinterest", name: "Pinterest", login: "https://br.pinterest.com/login/", domains: ["pinterest.com"], auth: "^_auth$", one: true },
    { id: "behance", name: "Behance (conta Adobe)", login: "https://www.behance.net/", domains: ["behance.net", "adobe.com"], auth: "^(bcp|iat0|ims_sid|aux_sid)$" },
    { id: "dribbble", name: "Dribbble", login: "https://dribbble.com/session/new", domains: ["dribbble.com"], auth: "^(user_session_token|remember_user_token|_dribbble_session_token)$" },
    { id: "freepik", name: "Freepik", login: "https://www.magnific.com/log-in", domains: ["magnific.com", "freepik.com", "freepik.com.br", "freepik.es"], auth: "^(GR_TOKEN|GR_LGD|GR_REFRESH|GR_USER|FP_LGD|FP_SESSION|fp_session|freepik_session|GR_.*|FP_.*)$" },
    { id: "canva", name: "Canva", login: "https://www.canva.com/login", domains: ["canva.com"], auth: "^(CAZ|CAU|CSESSION|CS)$" },
    { id: "envato", name: "Envato / Mixkit", login: "https://elements.envato.com/sign-in", domains: ["envato.com"], auth: "^(envatosession|_elements_session_4)$" },
    { id: "artstation", name: "ArtStation", login: "https://www.artstation.com/users/sign_in", domains: ["artstation.com"] },
    { id: "deviantart", name: "DeviantArt", login: "https://www.deviantart.com/users/login", domains: ["deviantart.com"], auth: "^(auth|auth_secure|userinfo)$" },
  ]],
  ["Fotos e vídeos", [
    { id: "pexels", name: "Pexels", login: "https://www.pexels.com/pt-br/entrar/", domains: ["pexels.com"] },
    { id: "unsplash", name: "Unsplash", login: "https://unsplash.com/login", domains: ["unsplash.com"], auth: "^(_unsplash_session|ugid_logged|un_sesh)$" },
    { id: "pixabay", name: "Pixabay", login: "https://pixabay.com/pt/accounts/login/", domains: ["pixabay.com"], auth: "^(sessionid)$" },
    { id: "vimeo", name: "Vimeo", login: "https://vimeo.com/log_in", domains: ["vimeo.com"], auth: "^(vimeo)$" },
    { id: "youtube", name: "YouTube / Google", login: "https://accounts.google.com/ServiceLogin?service=youtube", domains: ["youtube.com", "google.com"], auth: "^(LOGIN_INFO|SID|__Secure-3PSID)$" },
    { id: "coverr", name: "Coverr", login: "https://coverr.co/login", domains: ["coverr.co"] },
  ]],
  ["Ícones, 3D e motion", [
    { id: "flaticon", name: "Flaticon", login: "https://www.flaticon.com/log-in", domains: ["flaticon.com"], auth: "^(GR_TOKEN|GR_LGD|GR_REFRESH|FI_LGD)$" },
    { id: "iconscout", name: "IconScout", login: "https://iconscout.com/login", domains: ["iconscout.com"] },
    { id: "nounproject", name: "Noun Project", login: "https://thenounproject.com/login/", domains: ["thenounproject.com"] },
    { id: "icons8", name: "Icons8", login: "https://icons8.com/login", domains: ["icons8.com"] },
    { id: "lottiefiles", name: "LottieFiles", login: "https://lottiefiles.com/login", domains: ["lottiefiles.com"] },
    { id: "giphy", name: "GIPHY", login: "https://giphy.com/login", domains: ["giphy.com"] },
    { id: "sketchfab", name: "Sketchfab", login: "https://sketchfab.com/login", domains: ["sketchfab.com"], auth: "^(sb_sessionid|sessionid)$" },
    { id: "cgtrader", name: "CGTrader", login: "https://www.cgtrader.com/login", domains: ["cgtrader.com"] },
  ]],
  ["Áudio", [
    { id: "freesound", name: "Freesound", login: "https://freesound.org/home/login/", domains: ["freesound.org"], auth: "^(sessionid)$" },
    { id: "zapsplat", name: "Zapsplat", login: "https://www.zapsplat.com/login/", domains: ["zapsplat.com"], auth: "^wordpress_logged_in" },
    { id: "fma", name: "Free Music Archive", login: "https://freemusicarchive.org/login", domains: ["freemusicarchive.org"] },
  ]],
  ["Redes e anúncios", [
    { id: "instagram", name: "Instagram", login: "https://www.instagram.com/accounts/login/", domains: ["instagram.com"], auth: "^(sessionid|ds_user_id)$" },
    { id: "facebook", name: "Facebook (Biblioteca de Anúncios)", login: "https://www.facebook.com/login/", domains: ["facebook.com"], auth: "^(c_user)$" },
    { id: "linkedin", name: "LinkedIn", login: "https://www.linkedin.com/login", domains: ["linkedin.com"], auth: "^(li_at)$" },
    { id: "tiktok", name: "TikTok", login: "https://www.tiktok.com/login", domains: ["tiktok.com"], auth: "^(sessionid|sid_tt|uid_tt)$" },
    { id: "x", name: "X (Twitter)", login: "https://x.com/i/flow/login", domains: ["x.com", "twitter.com"], auth: "^(auth_token)$" },
  ]],
];
const ACCOUNTS = ACC_GROUPS.flatMap(g => g[1]);
// regra geral: cookie com cara de login (e não de anúncio, consentimento ou visitante)
const AUTH_RE = /(^|[_-])(session_?token|sessionid|auth(_?token)?|access_?token|refresh_?token|jwt|logged_?in|is_?logged|remember_?(me|user)?(_token)?|user_?(id|token)|uid|login(_token)?)([_-]|$)|^wordpress_logged_in/i;
const NOT_AUTH = /(csrf|xsrf|_ga|_gid|_gcl|utm|consent|optanon|^cf_|__cf|ab_|_fbp|visitor|anon|guest|device|tracking|_hj|amp_|mp_|ajs_|intercom|hubspot|__stripe|cookie_?(notice|policy)|lang|locale|theme)/i;
const accExtra = () => store.get("accExtra", []);
const accAll = () => [...ACCOUNTS, ...accExtra()];
// cookie com cara de login guardado (não de visitante): nome de login, valor grande e validade longa
const LONG_AUTH_RE = /(token|auth|sess|logged|lgd|jwt|refresh|remember|sid$|^sid|user|account|member|ident)/i;
const looksLogged = c => c.len >= 16 && !NOT_AUTH.test(c.n) && (AUTH_RE.test(c.n) || (LONG_AUTH_RE.test(c.n) && c.exp - Date.now() / 1000 > 7 * 86400));
const accManual = () => store.get("accManual", {});
let accCookies = {};
function accState(a, cookies) {
  const man = accManual()[a.id]; if (man) return man;
  const list = a.domains.flatMap(d => cookies[d] || []);
  if (a.auth) { const re = new RegExp(a.auth); const hit = list.filter(c => re.test(c.n)); if (hit.length) return a.one ? (hit.some(c => c.one) ? "on" : "off") : "on"; }
  return list.some(looksLogged) ? "maybe" : "off";
}
let accStatus = {}, accBusy = null;
async function refreshAccStatus() {
  if (!api.cookieNames) return accStatus;
  if (accBusy) return accBusy;
  accBusy = (async () => {
    const all = accAll();
    accCookies = await api.cookieNames([...new Set(all.flatMap(a => a.domains))]);
    accStatus = Object.fromEntries(all.map(a => [a.id, accState(a, accCookies)]));
    const n = Object.values(accStatus).filter(v => v !== "off").length;
    const b = $("#openAccounts"); b.dataset.count = n || ""; b.title = n ? `Contas: ${n} conectada${n > 1 ? "s" : ""}` : "Contas nas plataformas";
    return accStatus;
  })();
  try { return await accBusy; } finally { accBusy = null; }
}
const accUI = { find: "", open: new Set() };
function renderAccounts() {
  const st = accStatus, extra = accExtra(), man = accManual();
  const row = a => {
    const v = st[a.id] || "off";
    const label = !api.cookieNames ? "" : man[a.id] === "on" ? "● marcado por você" : v === "on" ? "● conectado" : v === "maybe" ? "● parece conectado" : "não conectado";
    const names = [...new Set(a.domains.flatMap(d => (accCookies[d] || []).map(c => c.n)))];
    return `<div class="acc ${v}" data-row="${esc(a.id)}"><div class="acc-n"><img class="acc-fav" src="https://www.google.com/s2/favicons?domain=${esc(a.domains[0])}&sz=32" alt="" referrerpolicy="no-referrer"><b>${esc(a.name)}</b>${a.extra ? `<span class="acc-new">detectado</span>` : ""}</div>
      <button class="st ${v} linkbtn" data-more="${esc(a.id)}" title="Ver detalhes">${label}</button>
      <button class="${v === "off" ? "btn" : "ghost"} small" data-login="${esc(a.id)}">${v === "off" ? "Entrar" : "Abrir"}</button>
      <button class="ghost small" data-out="${esc(a.id)}" ${v === "off" || man[a.id] ? "disabled" : ""}>Sair</button>
      ${accUI.open.has(a.id) ? `<div class="acc-more">
        <div>${names.length ? `O hub achou ${names.length} cookie${names.length > 1 ? "s" : ""} deste site neste navegador (só os nomes): <code>${names.slice(0, 40).map(esc).join(", ")}${names.length > 40 ? "…" : ""}</code>` : "Nenhum cookie deste site neste navegador. Se você está logado, talvez seja em outro navegador ou em outro perfil."}</div>
        <div class="acc-more-b">${man[a.id] === "on" ? `<button class="ghost small" data-man="${esc(a.id)}" data-v="">Desmarcar</button>` : v === "on" ? "" : `<button class="ghost small" data-man="${esc(a.id)}" data-v="on">${ico("check")}Estou logado: marcar como conectado</button>`}
          <button class="ghost small" data-copy="${esc(a.id)}">Copiar detalhes</button></div></div>` : ""}</div>`;
  };
  const groups = [...ACC_GROUPS, ...(extra.length ? [["Detectados por você", extra]] : [])];
  const on = Object.values(st).filter(v => v !== "off").length;
  const L = $("#accList");
  const top = L.scrollTop;
  L.innerHTML = `<div class="acc-sum"><b>${on}</b> de ${accAll().length} contas conectadas neste navegador
      <span class="spacer"></span><input id="accFind" placeholder="Procurar site" spellcheck="false" value="${esc(accUI.find)}"><button class="ghost small" id="accRefresh">${ico("reload")}Verificar de novo</button></div>` +
    groups.map(([g, list]) => `<div class="acc-g" data-g><h4>${esc(g)}</h4>${list.map(row).join("")}</div>`).join("");
  L.scrollTop = top;
  L.querySelectorAll(".acc-fav").forEach(i => i.onerror = () => i.style.visibility = "hidden");
  const filter = () => {
    const f = norm(accUI.find);
    L.querySelectorAll(".acc").forEach(r => { r.hidden = f && !norm(r.querySelector(".acc-n").textContent).includes(f); });
    L.querySelectorAll(".acc-g").forEach(g => { g.hidden = ![...g.querySelectorAll(".acc")].some(r => !r.hidden); });
  };
  filter();
  $("#accFind").oninput = e => { accUI.find = e.target.value; filter(); };
  $("#accRefresh").onclick = async () => { await refreshAccStatus(); renderAccounts(); toast("Contas verificadas"); };
  L.querySelectorAll("[data-more]").forEach(b => b.onclick = () => { const id = b.dataset.more; accUI.open.has(id) ? accUI.open.delete(id) : accUI.open.add(id); renderAccounts(); });
  L.querySelectorAll("[data-man]").forEach(b => b.onclick = async () => {
    const m = accManual(); if (b.dataset.v) m[b.dataset.man] = b.dataset.v; else delete m[b.dataset.man];
    store.set("accManual", m); await refreshAccStatus(); renderAccounts();
  });
  L.querySelectorAll("[data-copy]").forEach(b => b.onclick = () => {
    const a = accAll().find(x => x.id === b.dataset.copy);
    const txt = `AVANT Hub ${globalThis.chrome?.runtime?.getManifest?.().version || ""} · ${a.name} · status ${st[a.id] || "off"}\n` +
      a.domains.map(d => `${d}: ${(accCookies[d] || []).map(c => `${c.n}[${c.len}${c.h ? ",h" : ""}${c.exp ? "," + Math.round((c.exp - Date.now() / 1000) / 86400) + "d" : ",sessão"}]`).join(" ") || "nenhum"}`).join("\n");
    navigator.clipboard.writeText(txt).then(() => toast("Detalhes copiados (só nomes, sem valores). Cole na conversa com o Claude."), () => toast("Não consegui copiar"));
  });
  L.querySelectorAll("[data-login]").forEach(b => b.onclick = () => {
    const a = accAll().find(x => x.id === b.dataset.login);
    $("#accounts").hidden = true;
    if (EXT) { openLoginPane(a); return; }
    if (state.mode !== "search") setMode("search");
    openLoginPane(a);
  });
  L.querySelectorAll("[data-out]").forEach(b => b.onclick = async () => {
    const a = accAll().find(x => x.id === b.dataset.out);
    if (!confirmInline(b, "Sair?")) return;
    for (const d of a.domains) await api.logout(d);
    toast(`Saiu de ${a.name}`); await refreshAccStatus(); renderAccounts();
  });
}
// abre na hora com o que já se sabe e confere de novo em seguida
async function openAccounts() {
  renderAccounts();
  $("#accounts").hidden = false;
  await refreshAccStatus();
  if (!$("#accounts").hidden) renderAccounts();
}
// sites abertos dentro do hub: se a pessoa logar num site que não está na lista, ele entra sozinho em "Detectados por você"
const visitedHosts = new Set();
function hostOf(u) { try { return new URL(u).hostname.replace(/^www\./, ""); } catch { return ""; } }
function baseDomain(h) { const p = h.split("."); return p.slice(/\.(com|net|org|gov|edu)\.br$/.test(h) ? -3 : -2).join("."); }
if (api.onCookieChange) {
  let t;
  api.onCookieChange(c => {
    const d = baseDomain(c.domain);
    if (!c.removed && c.len >= 8 && AUTH_RE.test(c.name) && !NOT_AUTH.test(c.name) && visitedHosts.has(d) && !accAll().some(a => a.domains.some(x => d.endsWith(x) || x.endsWith(d)))) {
      const ex = accExtra(); ex.push({ id: "x-" + d, name: d, login: "https://" + d, domains: [d], extra: true }); store.set("accExtra", ex);
      toast(`Login detectado em ${d}. Ele entrou na lista de Contas.`);
    }
    clearTimeout(t); t = setTimeout(async () => { await refreshAccStatus(); if (!$("#accounts").hidden) renderAccounts(); }, 1200);
  });
}
// ao voltar para a aba do hub (depois de logar em outra aba), atualiza
document.addEventListener("visibilitychange", async () => { if (!document.hidden) { await refreshAccStatus(); if (!$("#accounts").hidden) renderAccounts(); } });
// abre a página de login numa aba embutida temporária
function openLoginPane(a) {
  if (EXT) { api.open(a.login); toast(`Entre em ${a.name} na aba que abriu. Quando voltar, a lista de Contas se atualiza sozinha.`); return; }
  $("#gallery").hidden = true; $("#webpane").hidden = false;
  let w = webviews.get("login");
  if (!w) {
    const el = makeFrame(a.login);
    el.addEventListener("did-navigate", e => { if (loginActive) $("#wbUrl").textContent = e.url; });
    $("#webhost").appendChild(el); w = { el, url: a.login }; webviews.set("login", w);
  } else { w.url = a.login; frameGo(w.el, a.login); }
  for (const [k, v] of webviews) v.el.classList.toggle("hide", k !== "login");
  loginActive = true;
  $("#wbUrl").textContent = a.login;
  $("#wbNote").textContent = `Entrando em ${a.name}. Depois é só voltar para uma aba da busca.`;
  document.querySelectorAll("#views .view").forEach(v => v.classList.remove("on"));
}
let loginActive = false;
$("#openAccounts").onclick = openAccounts;
$("#accClose").onclick = () => { $("#accounts").hidden = true; };


/* ------------------------------------------------------------------ telas: início, busca, coleções */
const PANES = ["#home", "#subbar", "#filters", "#viewbar", "#gallery", "#webpane", "#collections", "#rivals", "#avantools"];
const wpSpot = document.createComment("webpane");
$("#webpane").before(wpSpot);
function setMode(m) {
  if (m !== "collections" && Col.viewing) { Col.viewing = null; $("#colView").hidden = true; $("#colMain").hidden = false; }
  state.mode = m;
  const show = { home: ["#home"], search: ["#subbar", "#viewbar"], collections: ["#collections"], rivals: ["#rivals"], tools: ["#avantools"] }[m];
  PANES.forEach(sel => { $(sel).hidden = !show.includes(sel); });
  // o mesmo visualizador de sites serve à busca, à análise de mercado e às coleções
  if (m === "rivals") $("#rvBody").appendChild($("#webpane")); else wpSpot.after($("#webpane"));
  (m === "home" ? $("#heroSlot") : $("#topSlot")).appendChild($("#form"));
  document.body.dataset.mode = m;
  $("#openMedia").classList.toggle("on", m === "home" || m === "search");
  $("#openCollections").classList.toggle("on", m === "collections");
  $("#openRivals").classList.toggle("on", m === "rivals");
  $("#openTools").classList.toggle("on", m === "tools");
  if (m === "tools") Tools.render();
  if (m === "search") { renderFToggle(); showView(); }
  if (m === "home") renderHome();
  if (m === "rivals") Rivals.render();
}

/* ------------------------------------------------------------------ análise de mercado */
// pastas (nichos) que já vêm prontas. Dá para renomear, trocar a cor, apagar e criar outras.
const MK_FOLDERS_DEFAULT = [
  { id: "gd", name: "Energia por assinatura", color: "#003da5" },
  { id: "coop", name: "Cooperativas e geração compartilhada", color: "#1f8a5b" },
  { id: "solar", name: "Solar e integradoras", color: "#f18f09" },
  { id: "livre", name: "Mercado livre e grandes grupos", color: "#6b4fbb" },
  { id: "eaas", name: "Marketplaces e energy as a service", color: "#0e8fb3" },
  { id: "agencias", name: "Agências e comunicação", color: "#c2386b" },
];
// marcadores com cor: verde = seguir, vermelho = evitar, laranja = atenção, azul = informação
const MK_TAGS = { "Bench / norte": "good", "Referência": "good", "Site bom": "good", "Fluxo de cobrança": "good", "Inspirou nosso site": "info", "Parceira": "info", "Acompanhar": "info", "Não seguir": "bad", "Arquirrival": "warn", "Atenção": "warn" };
const IG = h => `https://www.instagram.com/${h}/`, LI = h => `https://www.linkedin.com/company/${h}/`;
const RIVALS_DEFAULT = [
  { id: "lemon", folder: "gd", name: "Lemon Energia", site: "https://energialemon.com.br", insta: IG("energialemon"), linkedin: LI("lemon-energia"), tags: ["Bench / norte"], obs: "Investida da AMBEV. O Will aponta como bench, o norte." },
  { id: "simplifica", folder: "gd", name: "Simplifica Energia", site: "https://simplificaenergia.com.br", insta: IG("simplifica.energia"), linkedin: LI("simplifica-energia"), tags: ["Arquirrival"], obs: "Arquirrival da AVANT. São do Grupo Ludfor, que é forte.",
    links: [{ label: "Ludfor (site)", url: "https://www.ludfor.com.br/" }, { label: "Ludfor (Instagram)", url: IG("ludforenergia") }] },
  { id: "plin", folder: "gd", name: "Plin Energia", site: "https://www.plinenergia.com.br", insta: IG("plinenergia"), linkedin: LI("plinenergia"), tags: ["Inspirou nosso site"], obs: "Segundo o Will, o site da AVANT foi muito inspirado no deles." },
  { id: "nextron", folder: "gd", name: "Nextron Energia", site: "https://nextronenergia.com.br", insta: IG("nextronenergia"), linkedin: LI("nextron-energia"), tags: ["Referência"], obs: "O Will suspeita de parceria com a Stone (o ecossistema Stone é boa referência). Tem programa de parcerias.",
    links: [{ label: "Programa de parcerias", url: "https://embaixador.nextronenergia.com.br/" }] },
  { id: "nex", folder: "gd", name: "Nex Energy", site: "https://www.nexenergy.com.br", insta: IG("nex.energy"), linkedin: LI("25032485"), tags: ["Referência"], obs: "Boa referência. Parecem bem organizados." },
  { id: "fit", folder: "gd", name: "Fit Energia", site: "https://www.fitenergia.com.br", insta: IG("fitenergiaoficial"), linkedin: LI("fitenergia"), obs: "Empresa do Santander." },
  { id: "evolua", folder: "gd", name: "Evolua Energia", site: "https://evoluaenergia.com.br", insta: IG("evoluaenergia"), linkedin: LI("evolua-energia") },
  { id: "flora", folder: "gd", name: "Flora Energia", site: "https://www.floraenergia.com.br", insta: "", linkedin: "" },
  { id: "gedisa", folder: "gd", name: "Gedisa", site: "https://gedisa.com.br", insta: "", linkedin: "" },
  { id: "matrix", folder: "gd", name: "Matrix Energia", site: "https://matrixenergia.com/energia-por-assinatura-gd", insta: IG("matrixenergia"), linkedin: LI("matrixenergia") },
  { id: "origo", folder: "gd", name: "Origo Energia", site: "https://origoenergia.com.br", insta: IG("origoenergia"), linkedin: LI("origo-energia") },
  { id: "wattmais", folder: "gd", name: "Watt Mais", site: "https://wattmais.com.br", insta: IG("wattmais"), linkedin: "" },
  { id: "cogecom", folder: "coop", name: "Cogecom", site: "https://cogecom.com.br", insta: IG("cogecom"), linkedin: "", tags: ["Não seguir"], obs: "Segundo o Will, um estilo de comunicação que não queremos seguir. Olhar crítico." },
  { id: "cotesa", folder: "coop", name: "Cotesa Energia", site: "https://cotesaenergia.com.br", insta: "", linkedin: "", obs: "Hoje usa a marca Move Energia by Cotesa." },
  { id: "solled", folder: "solar", name: "Solled Energia", site: "https://solledenergia.com.br", insta: IG("solledenergia"), linkedin: LI("solled-energia"), tags: ["Parceira", "Acompanhar"], obs: "Empresa parceira, começando no caminho que a AVANT já faz. Acompanhar." },
  { id: "sonnental", folder: "solar", name: "Sonnental Energia", site: "https://www.sonnental.com.br/energia-por-assinatura", insta: IG("sonnentalenergia"), linkedin: LI("sonnental-energia"), tags: ["Fluxo de cobrança"], obs: "O comercial e os parceiros elogiam o fluxo de cobrança, que aparece na home do site.",
    links: [{ label: "Home do site", url: "https://www.sonnental.com.br/" }] },
  { id: "portalsolar", folder: "solar", name: "Portal Solar", site: "https://www.portalsolar.com.br", insta: IG("portal_solar"), linkedin: LI("portal-solar") },
  { id: "comerc", folder: "livre", name: "Comerc Energia", site: "https://www.comerc.com.br/energia-solar", insta: IG("comercenergia"), linkedin: LI("comerc-energia"), tags: ["Site bom"], obs: "Site bom." },
  { id: "ultragaz", folder: "livre", name: "Ultragaz Energia (Witzler)", site: "https://www.ultragaz.com.br/energia-eletrica/", insta: IG("ultragazoficial"), linkedin: LI("ultragaz"), obs: "Mercado livre em parceria com a Witzler. O Instagram e o LinkedIn são da Ultragaz como um todo.",
    links: [{ label: "Mercado livre", url: "https://www.ultragaz.com.br/mercado-livre-de-energia/" }] },
  { id: "volters", folder: "eaas", name: "Volters", site: "https://volters.com.br", insta: IG("voltersenergia"), linkedin: "", tags: ["Atenção"], obs: "Energy as a service. Causou alvoroço no mercado: provavelmente quebrou ou vai quebrar." },
  { id: "duo", folder: "eaas", name: "Duo Energy", site: "https://duoenergy.com.br", insta: IG("duoenergy.com.br"), linkedin: LI("duoenergy"), obs: "Liga quem gera energia solar a quem consome, com pontos trocáveis por PIX." },
  { id: "isla", folder: "agencias", name: "Isla Territórios Digitais", site: "", insta: IG("isla.td"), linkedin: "", obs: "Agência de marketing de Porto Alegre. Referência de comunicação." },
];
const RV_TABS = [["site", "globe", "Site"], ["insta", "insta", "Instagram"], ["linkedin", "linkedin", "LinkedIn"]];
// lista salva: na primeira vez junta a lista antiga de concorrentes (com as notas) às empresas novas
function mkLoad() {
  let list = store.get("market", null);
  if (list) return list;
  const old = store.get("rivals", null) || [];
  list = RIVALS_DEFAULT.map(d => { const o = old.find(x => x.id === d.id); return { ...d, tags: d.tags || [], links: d.links || [], obs: d.obs || "", note: o?.note || "" }; });
  for (const o of old) if (!list.some(x => x.id === o.id)) list.push({ ...o, folder: "gd", tags: [], links: [], obs: "" });
  store.set("market", list);
  return list;
}
const Rivals = {
  list: mkLoad(),
  folders: store.get("marketFolders", null) || MK_FOLDERS_DEFAULT.map(f => ({ ...f })),
  collapsed: new Set(store.get("mkCollapsed", [])),
  find: "", fFolder: "all", fTag: "",
  save() { store.set("market", this.list); store.set("marketFolders", this.folders); store.set("mkCollapsed", [...this.collapsed]); },
  get(id) { return this.list.find(x => x.id === id); },
  folder(id) { return this.folders.find(f => f.id === id); },
  host: u => { try { return new URL(u).hostname.replace(/^www\./, ""); } catch { return ""; } },
  sub(r) { return this.host(r.site) || this.handle(r.insta) || ""; },
  favicon(r) { const h = this.host(r.site) || (r.insta ? "instagram.com" : ""); return h ? `https://www.google.com/s2/favicons?domain=${h}&sz=64` : ""; },
  // ícone do site; se não carregar, fica a inicial do nome
  fav(r) { return `<span class="fav"><b>${esc((r.name || "?").trim()[0].toUpperCase())}</b>${r.site ? `<img src="${esc(this.favicon(r))}" alt="" referrerpolicy="no-referrer">` : ""}</span>`; },
  instaUrl(v) {
    v = String(v || "").trim(); if (!v) return "";
    if (/^https?:\/\//.test(v)) return v;
    return `https://www.instagram.com/${v.replace(/^@/, "").replace(/\/$/, "")}/`;
  },
  handle(u) { const m = /instagram\.com\/([^/?#]+)/.exec(u || ""); return m ? "@" + m[1] : ""; },
  tabs(r) { return [...RV_TABS, ...(r.links || []).map((l, i) => ["x" + i, "ext", l.label || "Link"])]; },
  url(r, tab) {
    if (tab === "site") return r.site;
    if (tab === "insta") return r.insta;
    // sem página cadastrada: abre a busca de empresas do LinkedIn pelo nome
    if (tab === "linkedin") return r.linkedin || `https://www.linkedin.com/search/results/companies/?keywords=${encodeURIComponent(r.name)}`;
    const m = /^x(\d+)$/.exec(tab || ""); if (m) return r.links?.[+m[1]]?.url || "";
    return "";
  },
  firstTab(r) { return r.site ? "site" : r.insta ? "insta" : "linkedin"; },
  // link no formato que o visualizador entende
  link(id) {
    const m = /^rv:([^:]+):(\w+)$/.exec(id || ""); if (!m) return null;
    const r = this.get(m[1]); if (!r) return null;
    const tab = this.tabs(r).find(t => t[0] === m[2]);
    return { id, name: r.name, url: this.url(r, m[2]), query: "", serp: false, title: `${r.name} · ${tab ? tab[2] : ""}` };
  },
  open(id, tab) {
    if (state.mode !== "rivals") setMode("rivals");
    if (id) this.select(id, tab); else { state.rvSel = null; this.render(); }
  },
  select(id, tab) {
    const r = this.get(id); if (!r) return;
    if (!tab || !this.tabs(r).some(t => t[0] === tab) || !this.url(r, tab)) tab = this.firstTab(r);
    state.rvSel = id; state.rvTab = tab; state.rvView = `rv:${id}:${tab}`;
    this.render();
  },
  match(r) {
    const f = norm(this.find);
    return !f || norm([r.name, r.site, r.insta, r.obs, ...(r.tags || [])].join(" ")).includes(f);
  },
  groups(filterFolder = true) {
    const known = new Set(this.folders.map(f => f.id));
    const out = this.folders.map(f => [f, this.list.filter(r => r.folder === f.id)]);
    const loose = this.list.filter(r => !known.has(r.folder));
    if (loose.length) out.push([{ id: "", name: "Sem pasta", color: "#8a94a6" }, loose]);
    return out.filter(([f]) => !filterFolder || !this.fFolder || f.id === this.fFolder);
  },
  tone(t) { return MK_TAGS[t] || "neutral"; },
  // marcador como selo (cartões e lista)
  tagHtml(t) { return `<span class="mk-tag ${this.tone(t)}"><i></i>${esc(t)}</span>`; },
  view: store.get("mkView", "grid"),
  folderCount(id) { return this.list.filter(r => (id === "" ? !this.folder(r.folder) : r.folder === id)).length; },
  curFolder() { const sel = this.get(state.rvSel); return sel ? (this.folder(sel.folder) ? sel.folder : "") : this.fFolder; },
  renderSide(sel) {
    const active = sel ? (this.folder(sel.folder) ? sel.folder : "") : this.fFolder;
    const f = norm(this.find);
    const loose = this.folderCount("");
    const folders = [...this.folders, ...(loose ? [{ id: "", name: "Sem pasta", color: "#8a94a6" }] : [])];
    const coRow = r => `<button class="mk-co ${sel && sel.id === r.id ? "on" : ""}" data-r="${esc(r.id)}" draggable="true" title="${esc(r.name)}">${this.fav(r)}<span>${esc(r.name)}</span>
      ${(r.tags || []).slice(0, 1).map(t => `<i class="mk-pip ${this.tone(t)}" title="${esc(t)}"></i>`).join("")}</button>`;
    $("#rvList").innerHTML = `
      <div class="mk-find">${ico("search")}<input id="mkFind" placeholder="Procurar empresa" spellcheck="false" value="${esc(this.find)}"></div>
      <button class="mk-row ${!sel && this.fFolder === "all" ? "on" : ""}" data-nav="all"><span class="mk-tile all">${ico("layers")}</span><b>Todas as empresas</b><span class="mk-n">${this.list.length}</span></button>
      <div class="mk-label"><span>Pastas</span><button class="linkbtn" id="mkNewFolder">${ico("plus")}Nova pasta</button></div>
      ${folders.map(fo => {
        const list = this.list.filter(r => (fo.id ? r.folder === fo.id : !this.folder(r.folder)));
        const hits = f ? list.filter(r => this.match(r)) : list;
        if (f && !hits.length) return "";
        const open = f || active === fo.id && this.fFolder !== "all" || (sel && active === fo.id);
        return `<div class="mk-fold" data-fold="${esc(fo.id)}">
          <div class="mk-row ${!sel && this.fFolder === fo.id ? "on" : ""} ${open ? "open" : ""}" data-nav="${esc(fo.id)}" role="button" tabindex="0" style="--fc:${esc(fo.color)}">
            <span class="mk-tile">${ico("fold")}</span><b>${esc(fo.name)}</b><span class="mk-n">${list.length}</span>
            ${fo.id ? `<span class="mk-fed" data-fed="${esc(fo.id)}" role="button" title="Renomear, trocar a cor ou apagar">${ico("pencil")}</span>` : ""}
          </div>
          ${open ? `<div class="mk-cos">${hits.map(coRow).join("") || `<div class="mk-empty">Pasta vazia. Arraste empresas para cá.</div>`}</div>` : ""}
        </div>`;
      }).join("")}`;
    const L = $("#rvList");
    $("#mkFind").oninput = e => { this.find = e.target.value; const pos = e.target.selectionStart; this.render(); const i = $("#mkFind"); i.focus(); i.setSelectionRange(pos, pos); };
    L.querySelectorAll("[data-nav]").forEach(el => el.onclick = e => {
      if (e.target.closest("[data-fed]")) return;
      // clicar de novo na pasta aberta fecha ela e volta para Todas as empresas
      const id = el.dataset.nav, isOpen = id !== "all" && (sel ? active === id : this.fFolder === id);
      state.rvSel = null; this.fFolder = isOpen ? "all" : id; this.fTag = ""; this.render();
    });
    L.querySelectorAll("[data-fed]").forEach(b => b.onclick = e => { e.stopPropagation(); this.editFolder(b.dataset.fed); });
    L.querySelectorAll("[data-r]").forEach(el => {
      el.onclick = () => this.select(el.dataset.r, sel && sel.id === el.dataset.r ? state.rvTab : null);
      el.ondragstart = e => { e.dataTransfer.setData("text/mk", el.dataset.r); };
    });
    L.querySelectorAll("[data-fold]").forEach(fo => {
      fo.ondragover = e => { if (![...e.dataTransfer.types].includes("text/mk")) return; e.preventDefault(); fo.classList.add("drop"); };
      fo.ondragleave = e => { if (!fo.contains(e.relatedTarget)) fo.classList.remove("drop"); };
      fo.ondrop = e => {
        const r = this.get(e.dataTransfer.getData("text/mk")); fo.classList.remove("drop"); if (!r) return;
        e.preventDefault(); r.folder = fo.dataset.fold; this.save(); this.render();
        toast(`${r.name} foi para ${this.folder(r.folder)?.name || "Sem pasta"}`);
      };
    });
    $("#mkNewFolder").onclick = () => this.editFolder(null);
  },
  // botões de link de uma empresa: mesmo tamanho, uma linha só
  quick(r) {
    const b = (tab, icon, label, ok = true) => `<button class="mk-q" data-go="${esc(r.id)}" data-tab="${tab}" title="${esc(label)}" ${ok ? "" : "disabled"}>${ico(icon)}</button>`;
    return b("site", "globe", r.site ? "Site" : "Sem site cadastrado", !!r.site) + b("insta", "insta", r.insta ? "Instagram" : "Sem Instagram cadastrado", !!r.insta) +
      b("linkedin", "linkedin", r.linkedin ? "LinkedIn" : "LinkedIn (abre a busca pelo nome)") +
      (r.links || []).map((l, i) => b("x" + i, "ext", l.label || "Link")).join("");
  },
  card(r, showFolder) {
    const fo = this.folder(r.folder);
    return `<article class="mk-card" data-open="${esc(r.id)}" tabindex="0">
      <header>${this.fav(r)}<div class="mk-ct"><b>${esc(r.name)}</b><span>${esc(this.sub(r))}</span></div>
        <button class="mk-q ghosty" data-ed="${esc(r.id)}" title="Editar">${ico("pencil")}</button></header>
      ${showFolder && fo ? `<div class="mk-cfold"><i style="background:${esc(fo.color)}"></i>${esc(fo.name)}</div>` : ""}
      <div class="mk-tags">${(r.tags || []).map(t => this.tagHtml(t)).join("") || `<span class="mk-none">Sem marcador</span>`}</div>
      <p class="mk-obs">${r.obs ? esc(r.obs) : `<span class="mk-none">Sem observação.</span>`}</p>
      <footer><div class="mk-qs">${this.quick(r)}</div>${r.note ? `<span class="mk-hasnote" title="Tem notas">${ico("note")}</span>` : ""}<span class="mk-openlbl">Abrir ${ico("chev")}</span></footer>
    </article>`;
  },
  row(r, showFolder) {
    const fo = this.folder(r.folder);
    return `<div class="mk-lrow" data-open="${esc(r.id)}" tabindex="0">
      <div class="mk-lname">${this.fav(r)}<div class="mk-ct"><b>${esc(r.name)}</b><span>${esc(this.sub(r))}</span></div></div>
      ${showFolder ? `<div class="mk-lfold">${fo ? `<i style="background:${esc(fo.color)}"></i>${esc(fo.name)}` : "Sem pasta"}</div>` : ""}
      <div class="mk-tags">${(r.tags || []).map(t => this.tagHtml(t)).join("")}</div>
      <div class="mk-lobs">${esc(r.obs || "")}</div>
      <div class="mk-qs">${this.quick(r)}<button class="mk-q ghosty" data-ed="${esc(r.id)}" title="Editar">${ico("pencil")}</button></div>
    </div>`;
  },
  render() {
    if (state.mode !== "rivals") return;
    const sel = this.get(state.rvSel);
    if (!this.fFolder) this.fFolder = "all";
    this.renderSide(sel);
    const notes0 = $("#rvNotes");

    if (!sel) { // lista: todas as empresas ou uma pasta
      $("#webpane").hidden = true; if (notes0) notes0.hidden = true;
      const all = this.fFolder === "all";
      const fo = all ? null : this.folder(this.fFolder) || { id: "", name: "Sem pasta", color: "#8a94a6" };
      const base = this.list.filter(r => all || (fo.id ? r.folder === fo.id : !this.folder(r.folder)));
      const shown = base.filter(r => this.match(r) && (!this.fTag || (r.tags || []).includes(this.fTag)));
      const tagCount = {}; base.forEach(r => (r.tags || []).forEach(t => tagCount[t] = (tagCount[t] || 0) + 1));
      $("#rvBar").innerHTML = `
        <div class="mk-head">${all ? `<span class="mk-tile big all">${ico("layers")}</span>` : `<span class="mk-tile big" style="--fc:${esc(fo.color)}">${ico("fold")}</span>`}
          <div><h2>${esc(all ? "Todas as empresas" : fo.name)}</h2><span>${base.length} ${base.length === 1 ? "empresa" : "empresas"}${all ? ` em ${this.folders.length} pastas` : ""}</span></div></div>
        <span class="spacer"></span>
        ${!all && fo.id ? `<button class="ghost small" id="mkEdFolder">${ico("pencil")}Editar pasta</button>` : ""}
        <button class="btn small" id="mkAddCo">${ico("plus")}Adicionar empresa</button>`;
      if ($("#mkEdFolder")) $("#mkEdFolder").onclick = () => this.editFolder(fo.id);
      $("#mkAddCo").onclick = () => this.edit(null, all ? "" : fo.id);
      let ov = $("#rvOverview");
      if (!ov) { ov = document.createElement("div"); ov.id = "rvOverview"; ov.className = "rv-overview"; $("#rvBody").appendChild(ov); }
      ov.hidden = false;
      const tagsBar = Object.keys(tagCount).length ? `<div class="mk-filter"><span class="mk-flabel">${ico("tag")}Filtrar por marcador</span>
          ${Object.entries(tagCount).sort((a, b) => b[1] - a[1]).map(([t, n]) => `<button class="mk-tog ${this.tone(t)} ${this.fTag === t ? "on" : ""}" data-ft="${esc(t)}" aria-pressed="${this.fTag === t}"><i></i>${esc(t)}<small>${n}</small></button>`).join("")}
          ${this.fTag ? `<button class="linkbtn" data-ft="">Limpar</button>` : ""}</div>` : "";
      const viewSeg = `<div class="seg mk-vseg"><button data-v="grid" class="${this.view === "grid" ? "on" : ""}" title="Cartões">${ico("grid")}Cartões</button><button data-v="list" class="${this.view === "list" ? "on" : ""}" title="Lista">${ico("list")}Lista</button></div>`;
      const block = list => this.view === "list"
        ? `<div class="mk-list">${list.map(r => this.row(r, all)).join("")}</div>`
        : `<div class="mk-grid">${list.map(r => this.card(r, false)).join("")}</div>`;
      let body;
      if (!shown.length) body = `<div class="cempty"><b>Nenhuma empresa aqui</b>${this.fTag || this.find ? "Tente outra busca ou limpe o filtro." : "Clique em <b>Adicionar empresa</b> ou arraste empresas para esta pasta na lateral."}</div>`;
      else if (all) body = [...this.folders, { id: "", name: "Sem pasta", color: "#8a94a6" }].map(f => {
        const l = shown.filter(r => (f.id ? r.folder === f.id : !this.folder(r.folder))); if (!l.length) return "";
        return `<section class="mk-sec"><h3 data-goto="${esc(f.id)}"><i style="background:${esc(f.color)}"></i>${esc(f.name)}<small>${l.length}</small><span class="mk-seeall">Ver pasta ${ico("chev")}</span></h3>${block(l)}</section>`;
      }).join("");
      else body = block(shown);
      ov.innerHTML = `<div class="mk-tools">${tagsBar}<span class="spacer"></span>${viewSeg}</div>${body}`;
      ov.querySelectorAll("[data-open]").forEach(c => {
        c.onclick = e => { const go = e.target.closest("[data-go]"), ed = e.target.closest("[data-ed]");
          if (ed) { this.edit(ed.dataset.ed); return; }
          if (go) { if (!go.disabled) this.select(go.dataset.go, go.dataset.tab); return; }
          this.select(c.dataset.open); };
        c.onkeydown = e => { if (e.key === "Enter" && e.target === c) this.select(c.dataset.open); };
      });
      ov.querySelectorAll("[data-ft]").forEach(b => b.onclick = () => { this.fTag = this.fTag === b.dataset.ft ? "" : b.dataset.ft; this.render(); });
      ov.querySelectorAll("[data-v]").forEach(b => b.onclick = () => { this.view = b.dataset.v; store.set("mkView", this.view); this.render(); });
      ov.querySelectorAll("[data-goto]").forEach(h => h.onclick = () => { this.fFolder = h.dataset.goto; this.fTag = ""; this.render(); ov.scrollTop = 0; });
      return;
    }
    // empresa aberta: cabeçalho, abas, notas e o site
    const ov = $("#rvOverview"); if (ov) ov.hidden = true;
    const fo = this.folder(sel.folder);
    $("#rvBar").innerHTML = `
      <div class="mk-open">
        <div class="mk-open-top">
          <button class="ghost small" id="mkBack" title="Voltar para a lista">${ico("back")}${esc(fo ? fo.name : "Lista")}</button>
          ${this.fav(sel)}<div class="mk-ct"><b>${esc(sel.name)}</b><span>${esc(this.sub(sel))}</span></div>
          <div class="mk-tags">${(sel.tags || []).map(t => this.tagHtml(t)).join("")}</div>
          <span class="spacer"></span>
          <button class="ghost small" id="rvEditBtn">${ico("pencil")}Editar</button>
          <button class="ghost small ${state.rvNotes ? "on" : ""}" id="rvNotesBtn">${ico("note")}Notas${sel.note ? " •" : ""}</button>
        </div>
        <div class="rv-tabs" role="tablist">${this.tabs(sel).map(([k, i, l]) => `<button class="rv-tab ${state.rvTab === k ? "on" : ""}" data-tab="${k}" ${this.url(sel, k) ? "" : "disabled"}>${ico(i)}${esc(l)}</button>`).join("")}</div>
      </div>`;
    $("#mkBack").onclick = () => { state.rvSel = null; this.fFolder = fo ? fo.id : "all"; this.render(); };
    $("#rvBar").querySelectorAll("[data-tab]").forEach(b => b.onclick = () => this.select(sel.id, b.dataset.tab));
    $("#rvNotesBtn").onclick = () => { state.rvNotes = !state.rvNotes; this.render(); };
    $("#rvEditBtn").onclick = () => this.edit(sel.id);
    let notes = notes0;
    if (!notes) { notes = document.createElement("div"); notes.id = "rvNotes"; notes.className = "rv-notes"; $("#rvBody").appendChild(notes); }
    notes.hidden = !state.rvNotes;
    if (state.rvNotes) {
      notes.innerHTML = `${sel.obs ? `<div class="mk-notehead"><label>Observação</label><p class="mk-obs">${esc(sel.obs)}</p></div>` : ""}
        <label>Notas sobre ${esc(sel.name)}</label><textarea id="rvNoteTxt" placeholder="Posicionamento, preços, ofertas, tom de voz, o que fazem bem, o que dá para fazer melhor...">${esc(sel.note || "")}</textarea><span class="muted small">Salva sozinho.</span>`;
      $("#rvNoteTxt").oninput = e => { sel.note = e.target.value; this.save(); };
    }
    $("#webpane").hidden = false;
    showWeb(state.rvView);
  },
  edit(id, folderId) {
    const r = id ? this.get(id) : null;
    $("#rvEditTitle").textContent = r ? "Editar empresa" : "Adicionar empresa";
    $("#rvName").value = r?.name || ""; $("#rvSite").value = r?.site || ""; $("#rvInsta").value = r?.insta || ""; $("#rvLinked").value = r?.linkedin || "";
    $("#rvFolder").innerHTML = this.folders.map(f => `<option value="${esc(f.id)}">${esc(f.name)}</option>`).join("") + `<option value="">Sem pasta</option>`;
    $("#rvFolder").value = r ? (this.folder(r.folder) ? r.folder : "") : (folderId || (this.folder(this.fFolder) ? this.fFolder : this.folders[0]?.id) || "");
    let tags = [...(r?.tags || [])];
    const drawTags = () => {
      const all = [...new Set([...Object.keys(MK_TAGS), ...this.list.flatMap(x => x.tags || []), ...tags])];
      $("#rvTags").innerHTML = all.map(t => `<button type="button" class="mk-tog ${this.tone(t)} ${tags.includes(t) ? "on" : ""}" data-t="${esc(t)}" aria-pressed="${tags.includes(t)}"><i></i>${esc(t)}${tags.includes(t) ? ico("check") : ""}</button>`).join("") +
        `<span class="mk-newtag"><input id="rvTagNew" placeholder="Novo marcador" spellcheck="false"><button type="button" class="ghost small" id="rvTagAdd">${ico("plus")}Criar</button></span>`;
      $("#rvTags").querySelectorAll("[data-t]").forEach(b => b.onclick = () => { const t = b.dataset.t; tags = tags.includes(t) ? tags.filter(x => x !== t) : [...tags, t]; drawTags(); });
      const addNew = () => { const t = $("#rvTagNew").value.trim(); if (t && !tags.includes(t)) tags.push(t); drawTags(); $("#rvTagNew").focus(); };
      $("#rvTagNew").onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); addNew(); } };
      $("#rvTagAdd").onclick = addNew;
    };
    drawTags();
    $("#rvObs").value = r?.obs || "";
    $("#rvLinks").value = (r?.links || []).map(l => `${l.label} | ${l.url}`).join("\n");
    $("#rvDel").hidden = !r;
    $("#rvEdit").hidden = false; $("#rvName").focus();
    $("#rvSave").onclick = () => {
      const name = $("#rvName").value.trim(); let site = $("#rvSite").value.trim();
      const insta = this.instaUrl($("#rvInsta").value);
      if (!name || (!site && !insta)) { toast("Preencha o nome e o site ou o Instagram"); return; }
      if (site && !/^https?:\/\//.test(site)) site = "https://" + site;
      let linkedin = $("#rvLinked").value.trim(); if (linkedin && !/^https?:\/\//.test(linkedin)) linkedin = "https://www.linkedin.com/company/" + linkedin.replace(/^@/, "") + "/";
      const nt = $("#rvTagNew").value.trim(); if (nt && !tags.includes(nt)) tags.push(nt);
      const links = $("#rvLinks").value.split("\n").map(l => l.trim()).filter(Boolean).map(l => {
        const m = /^(.*?)\s*\|\s*(\S+)$/.exec(l); let url = m ? m[2] : l; if (!/^https?:\/\//.test(url)) url = "https://" + url;
        return { label: m ? m[1] || this.host(url) : this.host(url), url };
      });
      const data = { name, site, insta, linkedin, folder: $("#rvFolder").value, tags, obs: $("#rvObs").value.trim(), links };
      if (r) Object.assign(r, data);
      else this.list.push({ id: "c" + Date.now().toString(36), ...data, note: "" });
      this.save(); $("#rvEdit").hidden = true;
      // limpa abas antigas dessa empresa para recarregar com o link novo
      for (const k of [...webviews.keys()]) if (r && k.startsWith(`rv:${r.id}:`)) { webviews.get(k).el.remove(); webviews.delete(k); }
      this.render(); toast(r ? "Empresa atualizada" : `${name} adicionada`);
    };
    $("#rvDel").onclick = () => {
      if (!confirmInline($("#rvDel"), "Clique de novo para remover")) return;
      this.list = this.list.filter(x => x.id !== id); this.save();
      if (state.rvSel === id) state.rvSel = null;
      $("#rvEdit").hidden = true; this.render(); toast("Empresa removida");
    };
  },
  editFolder(id) {
    const f = id ? this.folder(id) : null;
    let color = f?.color || COLORS[this.folders.length % COLORS.length];
    $("#mkFolderTitle").textContent = f ? "Editar pasta" : "Nova pasta";
    $("#mkFName").value = f?.name || "";
    const draw = () => { $("#mkFColors").innerHTML = COLORS.map(c => `<span class="sw ${c === color ? "on" : ""}" data-c="${c}" style="background:${c}"></span>`).join(""); $("#mkFColors").querySelectorAll("[data-c]").forEach(s => s.onclick = () => { color = s.dataset.c; draw(); }); };
    draw();
    $("#mkFDel").hidden = !f;
    $("#mkFolder").hidden = false; $("#mkFName").focus();
    $("#mkFSave").onclick = () => {
      const name = $("#mkFName").value.trim(); if (!name) { toast("Dê um nome para a pasta"); return; }
      if (f) Object.assign(f, { name, color }); else this.folders.push({ id: "f" + Date.now().toString(36), name, color });
      this.save(); $("#mkFolder").hidden = true; this.render();
    };
    $("#mkFDel").onclick = () => {
      const n = this.list.filter(r => r.folder === id).length;
      if (!confirmInline($("#mkFDel"), n ? `Apagar? ${n} empresa(s) vão para Sem pasta` : "Clique de novo para apagar")) return;
      this.folders = this.folders.filter(x => x.id !== id);
      if (this.fFolder === id) this.fFolder = "all";
      this.save(); $("#mkFolder").hidden = true; this.render(); toast("Pasta apagada");
    };
  },
  exportList() {
    const blob = new Blob([JSON.stringify({ avantHubMercado: 1, folders: this.folders, list: this.list }, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "analise-de-mercado-avant-hub.json"; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast("Lista exportada. Mande o arquivo para a equipe.");
  },
  async importList(file) {
    try {
      const d = JSON.parse(await file.text()); const list = Array.isArray(d) ? d : d.list;
      if (!Array.isArray(list)) throw 0;
      for (const f of d.folders || []) if (f && f.id && f.name && !this.folder(f.id)) this.folders.push({ id: f.id, name: f.name, color: f.color || COLORS[0] });
      let n = 0;
      const key = x => this.host(x.site) || this.handle(x.insta) || norm(x.name);
      for (const x of list) {
        if (!x || !x.name || (!x.site && !x.insta)) continue;
        const same = this.list.find(y => key(y) === key(x));
        if (same) {
          same.insta = same.insta || x.insta || ""; same.linkedin = same.linkedin || x.linkedin || "";
          if (x.note && !same.note) same.note = x.note; if (x.obs && !same.obs) same.obs = x.obs;
          same.tags = [...new Set([...(same.tags || []), ...(x.tags || [])])];
          continue;
        }
        this.list.push({ id: "c" + Date.now().toString(36) + n, name: x.name, site: x.site || "", insta: x.insta || "", linkedin: x.linkedin || "", folder: x.folder || "", tags: x.tags || [], obs: x.obs || "", links: x.links || [], note: x.note || "" }); n++;
      }
      this.save(); this.render(); toast(n ? `${n} empresa(s) importada(s)` : "Nada novo: todas já estavam na lista");
    } catch { toast("Arquivo inválido"); }
  },
};
// extensões não aceitam onerror no HTML: um ouvinte só para todos os ícones de site
document.addEventListener("error", e => { if (e.target.matches?.(".fav img")) e.target.remove(); }, true);
document.addEventListener("load", e => { if (e.target.matches?.(".fav img") && e.target.naturalWidth > 1) e.target.classList.add("ok"); }, true);

/* ------------------------------------------------------------------ atualizações */
// O hub confere a versão publicada no Firebase (só com login @avantenergia.com.br) e, se for maior, baixa
// o pacote e troca os arquivos da própria pasta da extensão (o usuário escolhe essa pasta uma vez). Depois recarrega.
const FB = { key: "AIzaSyCYe4xuoxPTxrATPui_2UJCKVIE92XYkDA", project: "avant-hub-c7f41" };
const LOGIN_URL = "https://marioviniciussm.github.io/AVANT-Hub/";
const FS = `https://firestore.googleapis.com/v1/projects/${FB.project}/databases/(default)/documents`;
const Upd = {
  info: null, busy: false, err: false, msg: "", dirName: "", dir: null, auth: null, idTok: "", idExp: 0,
  cur() { return chrome.runtime.getManifest().version; },
  newer(a, b) { const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; },
  // login da empresa: a chave de acesso fica no chrome.storage (gravada pelo background depois do login)
  async loadAuth() { try { this.auth = (await chrome.storage.local.get("avtAuth")).avtAuth || null; } catch { this.auth = null; } },
  async token() {
    if (!this.auth) await this.loadAuth();
    if (!this.auth) throw new Error("login");
    if (this.idTok && Date.now() < this.idExp - 60e3) return this.idTok;
    const r = await fetch("https://securetoken.googleapis.com/v1/token?key=" + FB.key, {
      method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "grant_type=refresh_token&refresh_token=" + encodeURIComponent(this.auth.refreshToken) });
    if (!r.ok) { await this.logout(true); throw new Error("login"); }
    const j = await r.json();
    this.idTok = j.id_token; this.idExp = Date.now() + (+j.expires_in || 3600) * 1000;
    if (j.refresh_token && j.refresh_token !== this.auth.refreshToken) { this.auth.refreshToken = j.refresh_token; chrome.storage.local.set({ avtAuth: this.auth }); }
    return this.idTok;
  },
  async logout(silent) { this.auth = null; this.idTok = ""; this.info = null; try { await chrome.storage.local.remove("avtAuth"); } catch {} if (!silent) { this.msg = ""; this.render(); } },
  login() { window.open(LOGIN_URL + "?ext=" + chrome.runtime.id, "_blank"); this.msg = "Termine o login na aba que abriu. Volto aqui sozinho."; this.render(); },
  async api(path) {
    const t = await this.token();
    const r = await fetch(FS + path, { cache: "no-store", headers: { Authorization: "Bearer " + t } });
    if (r.status === 401 || r.status === 403) throw new Error("Esse e-mail não tem acesso. Entre com o e-mail da AVANT.");
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.json();
  },
  // pasta escolhida fica guardada no IndexedDB
  idb() { return new Promise((res, rej) => { const r = indexedDB.open("avant-upd", 1); r.onupgradeneeded = () => r.result.createObjectStore("kv"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); },
  async kvGet(k) { const db = await this.idb(); return new Promise(res => { const q = db.transaction("kv").objectStore("kv").get(k); q.onsuccess = () => res(q.result); q.onerror = () => res(null); }); },
  async kvSet(k, v) { const db = await this.idb(); return new Promise(res => { const t = db.transaction("kv", "readwrite"); t.objectStore("kv").put(v, k); t.oncomplete = () => res(); }); },
  async loadDir() { try { this.dir = await this.kvGet("dir"); this.dirName = this.dir ? this.dir.name : ""; } catch { this.dir = null; } },
  async check(silent) {
    if (!this.auth) await this.loadAuth();
    if (!this.auth) { this.msg = silent ? "" : "Entre com o e-mail da AVANT para ver as atualizações."; return null; }
    try {
      this.err = false;
      const d = await this.api("/releases/latest");
      const f = d.fields || {}, s = k => f[k] && (f[k].stringValue ?? f[k].integerValue ?? "");
      const j = { version: s("version"), sha256: s("sha256"), notes: s("notes") || "", size: +s("size") || 0, parts: +s("parts") || 0, rid: s("rid") };
      try { const m = s("manifest"); if (m) j.files = JSON.parse(m); } catch {}
      if (!j.version || !(j.files || (j.rid && j.parts))) throw new Error("versão publicada incompleta");
      this.info = j; store.set("updChecked", Date.now());
      const nw = this.newer(j.version, this.cur());
      $("#updDot").hidden = !nw;
      $("#openKeys").classList.toggle("has-upd", nw);
      this.msg = nw ? "" : "Você está na versão mais nova.";
      this.bar();
      return j;
    } catch (e) {
      if (e.message === "login") this.msg = silent ? "" : "Sua sessão acabou. Entre de novo.";
      else this.msg = silent ? "" : (/HTTP 404/.test(e.message) ? "Ainda não foi publicada nenhuma versão." : "Não consegui verificar: " + (e.message || e));
      return null;
    }
  },
  // baixa as partes do Firestore e junta num arquivo só
  async download(info, p) {
    const bufs = new Array(info.parts); let done = 0;
    const get = async i => {
      const d = await this.api("/parts/" + info.rid + "_" + i);
      const b64 = d.fields && d.fields.data && d.fields.data.bytesValue;
      if (!b64) throw new Error("parte " + i + " vazia");
      const bin = atob(b64), u = new Uint8Array(bin.length); for (let k = 0; k < bin.length; k++) u[k] = bin.charCodeAt(k);
      bufs[i] = u; p(`Baixando… ${++done}/${info.parts}`);
    };
    const q = [...Array(info.parts).keys()];
    await Promise.all([0, 1, 2, 3].map(async () => { while (q.length) await get(q.shift()); }));
    const out = new Uint8Array(bufs.reduce((n, b) => n + b.length, 0)); let o = 0;
    for (const b of bufs) { out.set(b, o); o += b.length; }
    return out.buffer;
  },
  async pickFolder() {
    if (!window.showDirectoryPicker) { this.msg = "Este navegador não permite escolher pasta."; return this.render(); }
    try {
      if (!store.get("dirTipSeen", 0)) { alert("Na próxima janela, escolha a pasta onde você instalou o hub.\n\nÉ a pasta que tem o arquivo manifest.json dentro (o nome costuma ser AVANT-Hub, em Documentos).\n\nVocê faz isso só uma vez."); store.set("dirTipSeen", 1); }
      const h = await showDirectoryPicker({ id: "avant-hub-ext", mode: "readwrite", startIn: "documents" });
      let ok = false;
      try { const f = await (await h.getFileHandle("manifest.json")).getFile(); const m = JSON.parse(await f.text()); ok = m.name === chrome.runtime.getManifest().name; } catch {}
      if (!ok) { this.msg = "Essa não parece ser a pasta do hub. Escolha a pasta que tem o arquivo manifest.json dentro. Para ver qual é: abra a página de extensões do navegador, clique em Detalhes no AVANT Hub e olhe o campo “Origem” (Chrome) ou “Carregado de” (Opera)."; return this.render(); }
      await this.kvSet("dir", h); this.dir = h; this.dirName = h.name; this.msg = "Pasta salva.";
    } catch (e) { if (e.name !== "AbortError") this.msg = "Não deu para abrir a pasta: " + e.message; }
    this.render();
  },
  async sha256(buf) { const d = await crypto.subtle.digest("SHA-256", buf); return [...new Uint8Array(d)].map(b => b.toString(16).padStart(2, "0")).join(""); },
  // grava os arquivos do zip na pasta e apaga o que sobrou da versão velha
  // atualização por diferença: baixa só os arquivos que mudaram (cada arquivo tem o seu sha256 no manifesto)
  async applyDiff(dir, info, p) {
    const files = info.files, paths = Object.keys(files);
    if (!files["manifest.json"]) throw new Error("Pacote sem manifest.json.");
    const sub = async (parts, make) => { let d = dir; for (const x of parts) d = await d.getDirectoryHandle(x, { create: make }); return d; };
    const need = []; let k = 0;
    for (const f of paths) {
      const [sha, , size] = files[f]; let same = false;
      try {
        const parts = f.split("/"), name = parts.pop(), d = await sub(parts, false), file = await (await d.getFileHandle(name)).getFile();
        if (file.size === size) same = (await this.sha256(await file.arrayBuffer())) === sha;
      } catch {}
      if (!same) need.push(f);
      if (++k % 40 === 0) p(`Conferindo arquivos… ${k}/${paths.length}`);
    }
    const inflate = async u8 => new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer());
    const write = async (f, u8) => {
      const parts = f.split("/"), name = parts.pop(), d = await sub(parts, true), w = await (await d.getFileHandle(name, { create: true })).createWritable();
      await w.write(u8); await w.close();
    };
    const fetchFile = async f => {
      const [sha, n] = files[f], bufs = [];
      for (let i = 0; i < n; i++) {
        const d = await this.api("/parts/f_" + sha.slice(0, 32) + "_" + i), b64 = d.fields && d.fields.data && d.fields.data.bytesValue;
        if (!b64) throw new Error("parte de " + f + " vazia");
        const bin = atob(b64), u = new Uint8Array(bin.length); for (let q = 0; q < bin.length; q++) u[q] = bin.charCodeAt(q); bufs.push(u);
      }
      const all = new Uint8Array(bufs.reduce((t, b) => t + b.length, 0)); let o = 0; for (const b in bufs) { all.set(bufs[b], o); o += bufs[b].length; }
      const raw = await inflate(all);
      if ((await this.sha256(raw)) !== sha) throw new Error("O arquivo " + f + " não confere (sha256).");
      return raw;
    };
    const first = need.filter(f => f !== "manifest.json"), queue = [...first]; let done = 0;
    if (!first.length) p("Nenhum arquivo novo para baixar.");
    await Promise.all([0, 1, 2, 3].map(async () => {
      while (queue.length) { const f = queue.shift(); await write(f, await fetchFile(f)); p(`Baixando só o que mudou… ${++done}/${first.length}`); }
    }));
    await write("manifest.json", await fetchFile("manifest.json")); // por último
    p("Limpando arquivos antigos…");
    const keep = new Set(paths);
    const sweep = async (d, prefix) => {
      for await (const [n, h] of d.entries()) {
        const path = prefix + n;
        if (h.kind === "directory") { await sweep(h, path + "/"); let empty = true; for await (const _ of h.entries()) { empty = false; break; } if (empty) await d.removeEntry(n).catch(() => {}); }
        else if (!keep.has(path)) await d.removeEntry(n).catch(() => {});
      }
    };
    await sweep(dir, "");
    return need.length;
  },
  async apply(dir, info, progress) {
    const p = progress || (() => {});
    if ((await dir.requestPermission({ mode: "readwrite" })) !== "granted") throw new Error("Sem permissão para gravar na pasta.");
    if (info.files) return this.applyDiff(dir, info, p);
    p("Baixando…");
    const buf = await this.download(info, p);
    if (info.sha256 && (await this.sha256(buf)) !== String(info.sha256).toLowerCase()) throw new Error("O arquivo baixado não confere (sha256).");
    p("Abrindo o pacote…");
    const zip = await JSZip.loadAsync(buf);
    const names = Object.keys(zip.files).filter(n => !zip.files[n].dir);
    const root = names.every(n => n.startsWith("RefHub-extensao/")) ? "RefHub-extensao/" : "";
    const rel = n => n.slice(root.length);
    if (!names.some(n => rel(n) === "manifest.json")) throw new Error("Pacote sem manifest.json.");
    const keep = new Set(names.map(rel));
    const sub = async (parts, make) => { let d = dir; for (const s of parts) d = await d.getDirectoryHandle(s, { create: make }); return d; };
    const order = names.map(rel).sort((a, b) => (a === "manifest.json") - (b === "manifest.json")); // manifest por último
    let i = 0;
    for (const f of order) {
      const parts = f.split("/"), name = parts.pop();
      const d = await sub(parts, true);
      const fh = await d.getFileHandle(name, { create: true });
      const w = await fh.createWritable();
      await w.write(await zip.file(root + f).async("uint8array")); await w.close();
      if (++i % 40 === 0) p(`Gravando arquivos… ${i}/${order.length}`);
    }
    p("Limpando arquivos antigos…");
    const sweep = async (d, prefix) => {
      for await (const [n, h] of d.entries()) {
        const path = prefix + n;
        if (h.kind === "directory") { await sweep(h, path + "/"); let empty = true; for await (const _ of h.entries()) { empty = false; break; } if (empty) await d.removeEntry(n).catch(() => {}); }
        else if (!keep.has(path)) await d.removeEntry(n).catch(() => {});
      }
    };
    await sweep(dir, "");
    return order.length;
  },
  async run() {
    if (this.busy) return;
    if (!this.info) { this.fail("Ainda não conferi a versão. Clique em “Verificar agora”."); return; }
    if (!this.dir) { this.fail("Escolha a pasta da extensão primeiro."); return; }
    this.busy = true; this.err = false; this.msg = "Começando a atualizar…"; this.render();
    try {
      const n = await this.apply(this.dir, this.info, m => { this.msg = m; this.render(); });
      this.msg = `Pronto: ${n} arquivos atualizados. O hub vai reiniciar e abrir de novo sozinho…`; this.render();
      try { await chrome.storage.local.set({ avtReopen: Date.now() }); } catch {}
      setTimeout(() => chrome.runtime.reload(), 1500);
    } catch (e) {
      const m = e && e.message || String(e);
      this.busy = false;
      this.fail(m === "login" ? "Sua sessão acabou. Entre de novo (botão Entrar)." :
        /permiss|denied|NotAllowed/i.test(m) ? "O navegador não deu permissão para gravar na pasta. Clique em Atualizar de novo e aceite “Editar arquivos”." :
        "Não consegui atualizar: " + m);
    }
  },
  fail(m) { this.msg = m; this.err = true; toast(m); this.render(); },
  // clique em "Atualizar": se ainda não tem pasta, pede a pasta e já atualiza
  async go() {
    this.err = false;
    if (!this.dir) { await this.pickFolder(); if (!this.dir) { this.err = true; this.render(); return; } }
    this.run();
  },
  // faixa no topo: pede o login ou avisa de versão nova
  bar() {
    const b = $("#updBar"); if (!b) return;
    const nw = this.info && this.newer(this.info.version, this.cur());
    let txt = "", btn = "", fn = null, x = true;
    if (this.busy) { txt = this.msg || "Atualizando…"; x = false; }
    else if (this.err && this.msg) { txt = this.msg; btn = nw ? "Tentar de novo" : ""; fn = () => this.go(); }
    else if (nw && store.get("updHide", "") !== this.info.version) { txt = `Tem versão nova do hub: ${this.info.version}.`; btn = this.dir ? "Atualizar agora" : "Escolher pasta e atualizar"; fn = () => this.go(); }
    else if (!this.auth && Date.now() > store.get("updLoginHide", 0)) { txt = "Entre com seu e-mail da AVANT para receber as atualizações do hub."; btn = "Entrar"; fn = () => this.login(); }
    b.hidden = !txt; if (!txt) return;
    $("#updTxt").textContent = txt;
    const g = $("#updBarGo"); g.hidden = !btn; g.textContent = btn; g.onclick = fn;
    const c = $("#updBarX"); c.hidden = !x;
    c.onclick = () => { if (nw) store.set("updHide", this.info.version); else store.set("updLoginHide", Date.now() + 864e5); b.hidden = true; };
  },
  async render() {
    this.bar();
    const box = $("#sUpd"); if (!box) return;
    if (!this.dir && this.dir !== false) await this.loadDir();
    if (!this.auth) await this.loadAuth();
    const nw = this.info && this.newer(this.info.version, this.cur());
    const last = store.get("updChecked", 0);
    box.innerHTML = `
      <div class="sgroup"><h3>Conta da AVANT</h3>
        ${this.auth ? `<p>Conectado como <b>${esc(this.auth.email)}</b>.</p><button class="ghost" id="updOut">Sair</button>`
          : `<p class="muted small">As atualizações são só para quem tem e-mail da AVANT.</p><button class="btn" id="updIn">Entrar com e-mail da AVANT</button>`}
      </div>
      <div class="sgroup"><h3>Versão</h3>
        <p>Você está na <b>${esc(this.cur())}</b>.${this.info ? ` Última versão publicada: <b>${esc(this.info.version)}</b>.` : ""}</p>
        ${last ? `<p class="muted small">Última verificação: ${new Date(last).toLocaleString("pt-BR")}</p>` : ""}
        ${nw ? `<div class="upd-new"><b>Tem versão nova (${esc(this.info.version)}).</b>${this.info.notes ? `<div class="muted small" style="margin-top:4px;white-space:pre-line">${esc(this.info.notes)}</div>` : ""}</div>` : ""}
        <div class="upd-actions">
          <button class="ghost" id="updCheck" ${this.busy || !this.auth ? "disabled" : ""}>Verificar agora</button>
          ${nw ? `<button class="btn" id="updGo" ${this.busy ? "disabled" : ""}>${this.dir ? "Atualizar agora" : "Escolher pasta e atualizar"}</button>` : ""}
        </div>
        ${this.msg ? `<p class="upd-msg">${esc(this.msg)}</p>` : ""}
      </div>
      <div class="sgroup"><h3>Pasta da extensão</h3>
        <p class="muted small">Escolha uma vez a pasta onde você instalou o hub: a que tem o arquivo <b>manifest.json</b> dentro (costuma ser <b>Documentos › AVANT-Hub</b>). Sem isso o “Atualizar agora” não funciona. O hub só mexe nessa pasta.</p>
        <p>${this.dir ? `Pasta escolhida: <b>${esc(this.dirName)}</b>` : "Nenhuma pasta escolhida ainda."}</p>
        <button class="ghost" id="updPick" ${this.busy ? "disabled" : ""}>${this.dir ? "Trocar pasta" : "Escolher pasta"}</button>
      </div>`;
    const bi = $("#updIn"); if (bi) bi.onclick = () => this.login();
    const bo = $("#updOut"); if (bo) bo.onclick = () => this.logout();
    $("#updCheck").onclick = async () => { this.msg = "Verificando…"; this.render(); await this.check(false); this.render(); };
    const go = $("#updGo"); if (go) go.onclick = () => this.go();
    $("#updPick").onclick = () => this.pickFolder();
  },
};
window.AvantUpd = Upd;
// depois do login (feito na aba da página de login) o background grava a chave: atualiza a tela e confere
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== "local" || !c.avtAuth) return;
  Upd.auth = c.avtAuth.newValue || null; Upd.idTok = "";
  if (Upd.auth) { Upd.msg = "Login feito. Verificando…"; Upd.render(); Upd.check(false).then(() => Upd.render()); } else Upd.render();
});
// confere ao abrir o hub (é uma leitura pequena)
setTimeout(async () => { await Upd.loadAuth(); Upd.bar(); await Upd.loadDir(); if (Upd.auth) { await Upd.check(true); Upd.bar(); } }, 1500);

/* ------------------------------------------------------------------ AVANTools */
// as ferramentas (DelphiTools, código aberto) ficam na pasta tools/ da extensão e abrem aqui dentro
const Tools = {
  frame: null,
  // passa as cores e o modo claro/escuro do hub para dentro das ferramentas
  sync() {
    const dark = document.documentElement.dataset.theme === "dark";
    try { localStorage.setItem("theme", dark ? "dark" : "light"); } catch {}
    const d = this.frame && this.frame.contentDocument; if (!d || !d.documentElement) return;
    const cs = getComputedStyle(document.documentElement), r = d.documentElement;
    const map = { pri: "--pri", sec: "--sec", "on-pri": "--on-pri", "pri-tx": "--pri-tx", bg: "--bg", panel: "--panel", panel2: "--panel2", line: "--line", tx: "--tx", tx2: "--tx2", tx3: "--tx3", "pri-l": "--pri-l" };
    for (const k in map) r.style.setProperty("--avt-" + k, cs.getPropertyValue(map[k]).trim());
    r.classList.toggle("dark", dark); r.classList.toggle("light", !dark);
  },
  // abre uma ferramenta pelo endereço (#/tools/id?...)
  go(hash) {
    if (state.mode !== "tools") setMode("tools"); else this.render();
    const h = hash || "";
    if (this.frame && this.frame.contentWindow) { try { if (h) this.frame.contentWindow.location.hash = h; } catch {} }
    else this.pending = h;
  },
  render() {
    this.sync();
    if (this.frame) return;
    const f = document.createElement("iframe");
    f.id = "avtFrame"; f.title = "AVANTools";
    f.allow = "clipboard-read; clipboard-write; fullscreen; microphone; camera; display-capture";
    f.onload = () => { const l = $("#avtLoad"); if (l) l.hidden = true; this.sync(); };
    f.src = "tools/index.html" + (this.pending || ""); this.pending = "";
    $("#avantools").appendChild(f);
    this.frame = f;
  },
};
/* ------------------------------------------------------------------ itens salvos pelas ferramentas */
// o AVANTools (iframe) manda {avt:"save", item}; aqui vira item da coleção "AVANTools"
const ToolSave = {
  hash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(36); },
  board() {
    let b = Col.data.boards.find(x => x.fromTools);
    if (!b) { b = Col.create("AVANTools"); b.fromTools = true; b.color = "#f18f09"; b.desc = "Cores, imagens, textos e atalhos salvos nas ferramentas"; }
    return b;
  },
  canvas(w, h, draw) { const c = document.createElement("canvas"); c.width = w; c.height = h; draw(c.getContext("2d"), w, h); return c.toDataURL("image/png"); },
  strip(colors) { return this.canvas(480, 240, (x, w, h) => { colors.forEach((c, i) => { x.fillStyle = c; x.fillRect(Math.floor(i * w / colors.length), 0, Math.ceil(w / colors.length) + 1, h); }); }); },
  wrap(x, text, maxW, maxLines) {
    const lines = []; for (const para of String(text).split(/\r?\n/)) { let cur = ""; for (const w of para.split(/(\s+)/)) { if (x.measureText(cur + w).width > maxW && cur) { lines.push(cur); cur = w.trimStart(); } else cur += w; if (lines.length >= maxLines) return lines; } lines.push(cur); if (lines.length >= maxLines) return lines; }
    return lines;
  },
  textCard(text) { return this.canvas(480, 300, (x, w, h) => { x.fillStyle = "#fff"; x.fillRect(0, 0, w, h); x.fillStyle = "#f18f09"; x.fillRect(0, 0, 8, h); x.fillStyle = "#0f1830"; x.font = "20px ui-monospace, Consolas, monospace"; x.textBaseline = "top";
    this.wrap(x, text, w - 48, 10).forEach((l, i) => x.fillText(l, 24, 20 + i * 27)); }); },
  toolCard(title) { return this.canvas(480, 300, (x, w, h) => { const g = x.createLinearGradient(0, 0, w, h); g.addColorStop(0, "#003da5"); g.addColorStop(1, "#0a2a6b"); x.fillStyle = g; x.fillRect(0, 0, w, h);
    x.fillStyle = "#f18f09"; x.fillRect(70, 62, 56, 6); x.fillStyle = "#fff"; x.font = "700 30px system-ui, sans-serif"; x.textBaseline = "top"; this.wrap(x, title, w - 140, 4).forEach((l, i) => x.fillText(l, 70, 88 + i * 40)); x.font = "16px system-ui, sans-serif"; x.fillStyle = "#cfd8ee"; x.fillText("Atalho do AVANTools", 70, h - 62); }); },
  save(m) {
    if (!m || !m.kind) return { ok: false, err: "Nada para salvar." };
    const tool = m.tool || {}, title = String(m.title || tool.title || "Sem título").slice(0, 120);
    let it;
    if (m.kind === "palette") {
      const cols = (m.colors || []).filter(c => /^#[0-9a-f]{6}$/i.test(c)).slice(0, 24); if (cols.length < 2) return { ok: false, err: "Preciso de pelo menos 2 cores." };
      it = { id: "tool:pal:" + this.hash(cols.join("")), kind: "palette", colors: cols, localThumb: this.strip(cols) };
    } else if (m.kind === "text") {
      const t = String(m.text || ""); if (!t.trim()) return { ok: false, err: "Texto vazio." };
      it = { id: "tool:txt:" + this.hash(t), kind: "text", text: t.slice(0, 200000), localThumb: this.textCard(t) };
    } else if (m.kind === "image") {
      if (!/^data:image\//.test(m.full || "")) return { ok: false, err: "Imagem inválida." };
      it = { id: "tool:img:" + this.hash((m.full || "").length + (m.full || "").slice(-200)), kind: "image", full: m.full, localThumb: /^data:image\//.test(m.thumb || "") ? m.thumb : m.full, w: m.w, h: m.h };
    } else if (m.kind === "tool") {
      if (!tool.hash) return { ok: false, err: "Sem endereço da ferramenta." };
      it = { id: "tool:link:" + this.hash(tool.hash), kind: "tool", localThumb: this.toolCard(tool.title || title) };
    } else return { ok: false, err: "Tipo não suportado." };
    const b = this.board();
    const old = b.items.find(x => x.id === it.id);
    if (old) { old.title = title; old.savedAt = Date.now(); Col.touch(b); Col.save(); Col.renderSide(); Col.renderMain(); toast(`Já estava em "${b.name}" (atualizei o nome)`); return { ok: true, board: b.name, again: true }; }
    b.items.unshift({ ...it, title, fromTool: { id: tool.id || "", title: tool.title || "", hash: tool.hash || "" }, sourceName: "AVANTools" + (tool.title ? " · " + tool.title : ""),
      uid: "i" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), note: "", tags: [], savedAt: Date.now() });
    Col.touch(b); Col.save(); Col.renderSide(); Col.renderMain();
    toast(`Salvo em "${b.name}"`);
    return { ok: true, board: b.name };
  },
  del(uid) { for (const b of Col.data.boards) { const n = b.items.length; b.items = b.items.filter(x => x.uid !== uid); if (b.items.length !== n) { Col.touch(b); Col.save(); Col.renderSide(); Col.renderMain(); return; } } },
};
window.addEventListener("message", e => {
  const m = e.data;
  if (e.origin !== location.origin || !m || (m.avt !== "save" && m.avt !== "del")) return;
  if (!Tools.frame || e.source !== Tools.frame.contentWindow) return;
  let r; try { r = m.avt === "save" ? ToolSave.save(m.item) : (ToolSave.del(m.uid), { ok: true }); } catch (err) { r = { ok: false, err: String(err && err.message || err) }; }
  try { e.source.postMessage({ avt: "saved", ref: m.ref, ...r }, location.origin); } catch {}
});

$("#openTools").onclick = () => { if (state.mode !== "tools") setMode("tools"); };
$("#openRivals").onclick = () => { if (state.mode !== "rivals") Rivals.open(state.rvSel || null); };
$("#rvEditClose").onclick = () => { $("#rvEdit").hidden = true; };
$("#rvEdit").onclick = e => { if (e.target.id === "rvEdit") $("#rvEdit").hidden = true; };
$("#rvExport").onclick = () => Rivals.exportList();
$("#rvImport").onclick = () => $("#rvFile").click();
$("#rvFile").onchange = e => { const f = e.target.files[0]; if (f) Rivals.importList(f); e.target.value = ""; };
function goHome() {
  stopAudio();
  state.q = ""; $("#q").value = "";
  setMode("home");
  $("#q").focus();
}
// o que cada categoria traz (sem falar de plataforma)
const TYPE_HINT = {
  design: ["Peças gráficas para impresso, web e marca", ["Cartazes", "Flyers", "Identidade visual", "Banners", "Infográficos"]],
  anuncios: ["Anúncios que estão no ar agora, de qualquer marca", ["Meta", "LinkedIn", "TikTok", "Google"]],
  social: ["Referências de posts e campanhas", ["Feed", "Carrossel", "Stories", "Reels", "Anúncios"]],
  mockup: ["Sua arte aplicada em objetos reais", ["Celular", "Embalagem", "Papelaria", "Camiseta", "Outdoor"]],
  ilustracao: ["Desenhos e vetores em vários estilos", ["Flat", "Isométrica", "3D", "Feita à mão", "Personagens"]],
  "3d": ["Objetos e materiais para compor cenas", ["Modelos", "Ícones 3D", "Texturas", "HDRI", "Renders"]],
  foto: ["Fotos de banco para usar nas peças", ["Pessoas", "Lugares", "Produtos", "Natureza", "Energia"]],
  video: ["Cenas prontas para editar", ["Drone", "Câmera lenta", "Time-lapse", "Pessoas", "Tela verde"]],
  musica: ["Trilhas livres para vídeos, com player aqui", ["Corporativa", "Animada", "Calma", "Épica", "Lo-fi"]],
  sfx: ["Sons curtos para vídeo e motion, com player aqui", ["Transições", "Cliques", "Impactos", "Notificações", "Ambientes"]],
  icone: ["Ícones para apresentações, posts e sites", ["Linha", "Preenchido", "Colorido", "3D", "Animado"]],
  gif: ["Movimento para posts e apresentações", ["Reações", "Stickers", "Loops", "Textos animados", "Lottie"]],
  arte: ["Obras clássicas para inspirar cor e composição", ["Pinturas", "Gravuras", "Cartazes antigos", "Fotografia antiga"]],
};
function renderHome() {
  $("#tcards").innerHTML = Object.entries(state.types).map(([id, t]) => `
    <button class="tcard ${id === state.type ? "on" : ""}" data-type="${id}">
      <span class="ti">${ico(id)}</span>
      <span><b>${esc(t.label)}</b><span>${esc(TYPE_HINT[id]?.[0] || "")}</span></span>
    </button>`).join("");
  $("#tcards").querySelectorAll("[data-type]").forEach(b => b.onclick = () => {
    setType(b.dataset.type);
    if ($("#q").value.trim()) $("#form").requestSubmit(); else $("#q").focus();
  });
  let ch = $(".hero .chosen");
  if (!ch) { ch = document.createElement("div"); ch.className = "chosen"; $("#heroSlot").after(ch); }
  ch.innerHTML = `Buscando em <b>${esc(T().label)}</b>. Troque o tipo nos cartões abaixo.`;
  const boards = Col.data.boards.filter(b => b.items.length).slice(0, 4);
  $("#homeCols").innerHTML = boards.length ? `<div class="hcols"><div class="hcols-head"><h2>Suas coleções</h2><button class="ghost small" id="hcAll">${ico("folder")}Ver todas</button></div>
    <div class="hcol-grid">${boards.map(b => {
      const img = coverImg(b);
      return `<button class="hcol" data-b="${b.id}"><div class="hc-img" style="${img ? `background-image:url('${esc(img)}')` : `background:${b.color}`}">${img ? "" : esc(b.emoji || "★")}</div>
        <div class="hc-t"><b>${esc(b.emoji ? b.emoji + " " : "")}${esc(b.name)}</b><span>${b.items.length} ${b.items.length === 1 ? "item" : "itens"}</span></div></button>`;
    }).join("")}</div></div>` : "";
  $("#homeCols").insertAdjacentHTML("afterbegin", `<div class="hcols"><div class="hcols-head"><h2>Análise de mercado</h2><button class="ghost small" id="hrAll">${ico("rivals")}Ver todas as ${Rivals.list.length}</button></div>
    <div class="hr-row">${Rivals.list.filter(r => (r.tags || []).length).slice(0, 10).map(r => `<button class="hr-chip" data-rv="${esc(r.id)}">${Rivals.fav(r)}${esc(r.name)}</button>`).join("")}</div></div>`);
  $("#homeCols").querySelectorAll("[data-rv]").forEach(b => b.onclick = () => Rivals.open(b.dataset.rv, "site"));
  $("#hrAll").onclick = () => Rivals.open();
  $("#homeCols").insertAdjacentHTML("beforeend", `<div class="tips">
    <div class="tip">${ico("star")}<div><b>Guarde o que gostar.</b> Em qualquer plataforma, clique em <b>Salvar página</b> para levar para uma coleção.</div></div>
    <div class="tip">${ico("user")}<div><b>Entre uma vez.</b> Se você já está logado no Pinterest ou no Behance neste navegador, o login já vale aqui.</div></div>
    <div class="tip">${ico("globe")}<div><b>Idioma da busca.</b> Ao lado das abas, troque entre Auto, PT e EN se os resultados vierem fracos.</div></div></div>`);
  $("#homeCols").querySelectorAll("[data-b]").forEach(b => b.onclick = () => Col.open(b.dataset.b));
  const all = $("#hcAll"); if (all) all.onclick = () => Col.open();
}
// atalho: "/" vai para a busca
document.addEventListener("keydown", e => {
  if (e.key !== "/" || e.ctrlKey || e.metaKey || /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)) return;
  e.preventDefault(); $("#q").focus(); $("#q").select();
});

(async function init() {
  document.querySelectorAll("[data-ico]").forEach(el => { el.innerHTML = ico(el.dataset.ico); });
  await Col.load();
  state.types = await api.types();
  if (!state.types[state.type]) state.type = "design";
  renderTypes(); renderFilters(); updatePlaceholder();
  setMode("home");
  $("#q").focus();
  refreshAccStatus();
})();

$("#cvBack").onclick = () => Col.closeView();
document.addEventListener("keydown", e => {
  if (e.key !== "Escape" || !Col.viewing || state.mode !== "collections") return;
  if (document.querySelector(".modal:not([hidden]), .lb.on")) return;
  Col.closeView();
});

$("#mkFClose").onclick = () => { $("#mkFolder").hidden = true; };
$("#mkFolder").onclick = e => { if (e.target.id === "mkFolder") $("#mkFolder").hidden = true; };
$("#mkFName").onkeydown = e => { if (e.key === "Enter") $("#mkFSave").click(); };
