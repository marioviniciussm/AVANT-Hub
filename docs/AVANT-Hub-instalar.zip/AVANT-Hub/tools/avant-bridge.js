/* AVANTools <-> AVANT Hub: endereço com #, colar cores, "Salvar no hub" */
(function () {
  var W = window;

  // ---- navegadores um pouco mais antigos não têm Map.getOrInsert (o leitor de PDF usa)
  [Map, WeakMap].forEach(function (C) {
    if (!C.prototype.getOrInsert) C.prototype.getOrInsert = function (k, v) { if (!this.has(k)) this.set(k, v); return this.get(k); };
    if (!C.prototype.getOrInsertComputed) C.prototype.getOrInsertComputed = function (k, f) { if (!this.has(k)) this.set(k, f(k)); return this.get(k); };
  });

  // ---- endereço: com rota em # os parâmetros ficam depois do "?" dentro do hash
  W.__avtSearch = function () {
    var h = location.hash || "", i = h.indexOf("?");
    return location.search || (i >= 0 ? h.slice(i) : "");
  };

  // ---- links "#algo" (pular conteúdo etc.) não podem mexer na rota
  document.addEventListener("click", function (e) {
    var a = e.target && e.target.closest && e.target.closest('a[href^="#"]');
    if (!a) return;
    var h = a.getAttribute("href");
    if (h.charAt(1) === "/") return; // rota do Ember
    e.preventDefault();
    var el = h.length > 1 ? document.getElementById(h.slice(1)) : null;
    if (el) { try { el.scrollIntoView(); el.setAttribute("tabindex", "-1"); el.focus({ preventScroll: true }); } catch (x) {} }
  });

  // ---- cores
  function hex2(n) { n = Math.max(0, Math.min(255, Math.round(n))); return (n < 16 ? "0" : "") + n.toString(16); }
  function rgbHex(r, g, b) { return "#" + hex2(r) + hex2(g) + hex2(b); }
  function hslHex(h, s, l) {
    h = ((h % 360) + 360) % 360; s /= 100; l /= 100;
    var c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2, r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return rgbHex((r + m) * 255, (g + m) * 255, (b + m) * 255);
  }
  // aceita #rgb, #rrggbb, rgb(), hsl() e, se o texto for só uma lista, rrggbb sem #
  function parseColours(text) {
    text = String(text || ""); var out = [], m;
    var re = /#([0-9a-f]{6}|[0-9a-f]{3})(?![0-9a-z])|rgba?\(\s*(\d{1,3}(?:\.\d+)?)[\s,]+(\d{1,3}(?:\.\d+)?)[\s,]+(\d{1,3}(?:\.\d+)?)|hsla?\(\s*(\d{1,3}(?:\.\d+)?)(?:deg)?[\s,]+(\d{1,3}(?:\.\d+)?)%[\s,]+(\d{1,3}(?:\.\d+)?)%/gi;
    while ((m = re.exec(text))) {
      var v;
      if (m[1]) v = "#" + (m[1].length === 3 ? m[1].replace(/./g, function (c) { return c + c; }) : m[1]).toLowerCase();
      else if (m[2] !== undefined) v = rgbHex(+m[2], +m[3], +m[4]);
      else v = hslHex(+m[5], +m[6], +m[7]);
      out.push(v);
    }
    if (!out.length) {
      var toks = text.trim().split(/[\s,;]+/).filter(Boolean);
      if (toks.length && toks.every(function (t) { return /^[0-9a-f]{6}$/i.test(t); })) out = toks.map(function (t) { return "#" + t.toLowerCase(); });
    }
    return out.filter(function (c, i) { return out.indexOf(c) === i; });
  }

  // ---- ponte com o hub
  var inHub = (function () { try { return W.parent && W.parent !== W && W.parent.location.origin === location.origin; } catch (e) { return false; } })();
  var waiting = {};
  W.addEventListener("message", function (e) {
    if (e.origin !== location.origin || !e.data || e.data.avt !== "saved") return;
    var cb = waiting[e.data.ref]; if (cb) { delete waiting[e.data.ref]; cb(e.data); }
  });
  function toHub(msg, cb) {
    if (!inHub) { cb && cb({ ok: false, err: "Abra o AVANTools de dentro do AVANT Hub para salvar." }); return; }
    msg.avt = msg.avt || "save"; msg.ref = Date.now() + "-" + Math.random().toString(36).slice(2);
    if (cb) { waiting[msg.ref] = cb; setTimeout(function () { if (waiting[msg.ref]) { delete waiting[msg.ref]; cb({ ok: false, err: "O hub não respondeu." }); } }, 8000); }
    W.parent.postMessage(msg, location.origin);
  }
  function listSaved(cb) {
    try { chrome.storage.local.get("colecoes", function (r) {
      var out = [], d = r && r.colecoes; if (d && d.boards) d.boards.forEach(function (b) { (b.items || []).forEach(function (it) { if (it.fromTool) out.push({ board: b.name, boardId: b.id, item: it }); }); });
      out.sort(function (a, b) { return (b.item.savedAt || 0) - (a.item.savedAt || 0); }); cb(out); }); } catch (e) { cb([]); }
  }
  W.AvantBridge = {
    parseColours: parseColours, inHub: inHub, toHub: toHub, list: listSaved,
    onChange: function (fn) { try { chrome.storage.onChanged.addListener(function (c, a) { if (a === "local" && c.colecoes) fn(); }); } catch (e) {} },
    remove: function (uid, cb) { toHub({ avt: "del", uid: uid }, cb); },
  };


  // ---- lembra as últimas opções de cada ferramenta (só campos simples: seletores, deslizantes, caixas e cores)
  (function () {
    var KEY = "avt-opts:", SKIP = { salvos: 1, "password-genny": 1, "lote-imagens": 1, "contador-redes": 1, "utm-genny": 1, "texto-ferramentas": 1, "previa-post": 1, "pdf-to-xml": 1 };
    function tid() { var m = /#\/tools\/([^?\/]+)/.exec(location.hash || ""); return m ? m[1] : ""; }
    function fields() {
      var root = document.getElementById("main-content"); if (!root) return [];
      return Array.prototype.filter.call(root.querySelectorAll("select,input[type=range],input[type=checkbox],input[type=color]"), function (n) { return !n.closest(".avt-sv-pan") && !n.hidden; });
    }
    function key(n, i) { return i + "|" + (n.getAttribute("aria-label") || n.name || n.id || n.type); }
    function val(n) { return n.type === "checkbox" ? (n.checked ? "1" : "0") : n.value; }
    var timer, restoredFor = "", dirty = {};
    function read(id) { try { return JSON.parse(localStorage.getItem(KEY + id) || "{}"); } catch (e) { return {}; } }
    function restore() {
      var id = tid(); if (!id || SKIP[id] || restoredFor === id) return;
      var fs = fields(); if (!fs.length) return;
      restoredFor = id; var saved = read(id);
      fs.forEach(function (n, i) {
        var k = key(n, i); if (!(k in saved) || saved[k] === val(n)) return;
        if (n.type === "checkbox") n.checked = saved[k] === "1"; else n.value = saved[k];
        n.dispatchEvent(new Event("input", { bubbles: true })); n.dispatchEvent(new Event("change", { bubbles: true }));
      });
    }
    document.addEventListener("change", function (e) {
      var id = tid(); if (!id || SKIP[id] || restoredFor !== id || !e.isTrusted) return;
      var fs = fields(), i = fs.indexOf(e.target); if (i < 0) return;
      var saved = read(id); saved[key(e.target, i)] = val(e.target);
      try { localStorage.setItem(KEY + id, JSON.stringify(saved)); } catch (x) {}
    }, true);
    W.addEventListener("hashchange", function () { restoredFor = ""; });
    new MutationObserver(function () { clearTimeout(timer); timer = setTimeout(restore, 450); }).observe(document.documentElement, { childList: true, subtree: true });
  })();

  // ---- botão "Salvar no hub" nas ferramentas
  var css = ".avt-sv-btn{position:fixed;right:18px;bottom:18px;z-index:9000;display:flex;align-items:center;gap:8px;padding:10px 16px;border:0;border-radius:99px;background:var(--avt-sec,#f18f09);color:#1b1200;font-weight:600;font-size:14px;line-height:1;font-family:inherit;box-shadow:0 6px 20px rgba(0,0,0,.25);cursor:pointer}" +
    ".avt-sv-btn:hover{filter:brightness(1.05)}.avt-sv-btn[hidden],.avt-sv-pan[hidden]{display:none}" +
    ".avt-sv-pan{position:fixed;right:18px;bottom:68px;z-index:9001;width:min(380px,calc(100vw - 36px));max-height:min(70vh,560px);overflow:auto;background:var(--avt-panel,#fff);color:var(--avt-tx,#0f1830);border:1px solid var(--avt-line,#dde2ee);border-radius:14px;box-shadow:0 14px 44px rgba(0,0,0,.3);padding:14px;font-family:inherit}" +
    ".avt-sv-pan h4{margin:0 0 4px;font-size:15px}.avt-sv-pan p{margin:0 0 10px;font-size:12.5px;color:var(--avt-tx3,#7d8494)}" +
    ".avt-sv-it{border-top:1px solid var(--avt-line,#dde2ee);padding:10px 0;display:flex;flex-direction:column;gap:8px}" +
    ".avt-sv-it b{font-size:13.5px}.avt-sv-row{display:flex;gap:8px;align-items:center}.avt-sv-row input{flex:1;min-width:0;border:1px solid var(--avt-line,#dde2ee);border-radius:8px;padding:7px 9px;background:var(--avt-bg,#f1f4fb);color:inherit;font:inherit;font-size:13px}" +
    ".avt-sv-go{border:0;border-radius:8px;padding:8px 12px;background:var(--avt-pri,#003da5);color:var(--avt-on-pri,#fff);font-weight:600;font-size:13px;font-family:inherit;cursor:pointer;white-space:nowrap}.avt-sv-go:disabled{opacity:.6;cursor:default}" +
    ".avt-sv-sw{display:flex;border-radius:8px;overflow:hidden;height:34px;border:1px solid var(--avt-line,#dde2ee)}.avt-sv-sw i{flex:1}" +
    ".avt-sv-th{max-width:100%;max-height:110px;object-fit:contain;border-radius:8px;border:1px solid var(--avt-line,#dde2ee);background:#fff;align-self:flex-start}" +
    ".avt-sv-tx{font:12px/1.4 ui-monospace,monospace;background:var(--avt-bg,#f1f4fb);border-radius:8px;padding:8px;max-height:70px;overflow:hidden;white-space:pre-wrap;word-break:break-word}" +
    ".avt-sv-ok{color:#1a8f4a;font-size:12.5px;font-weight:600}";
  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  var btn, pan;
  function toolId() { var m = /#\/tools\/([^?\/]+)/.exec(location.hash || ""); return m ? m[1] : ""; }
  function toolTitle() { var h = document.querySelector("#main-content h1") || document.querySelector("h1"); return (h && h.textContent.trim()) || (document.title || "").split("|")[0].trim() || "Ferramenta"; }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function visible(n) { var r = n.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function inUi(n) { return n.closest && n.closest(".avt-sv-pan,.avt-sv-btn,nav,aside,[role=menu],header.dt-bar"); }

  function scan() {
    var root = document.getElementById("main-content") || document.body, res = { colours: [], images: [], texts: [] };
    // cores: estilos inline, seletores de cor e códigos escritos na tela
    var seen = {}, cols = [];
    function add(c) { if (!seen[c]) { seen[c] = 1; cols.push(c); } }
    root.querySelectorAll("[style],input[type=color]").forEach(function (n) {
      if (inUi(n) || !visible(n)) return;
      if (n.tagName === "INPUT") { parseColours(n.value).forEach(add); return; }
      var s = n.getAttribute("style") || ""; if (/background|--pg-colour|fill|color/i.test(s)) parseColours(s).forEach(add);
    });
    (root.innerText || "").split(/\s+/).forEach(function (t) { if (/^#[0-9a-f]{6}$/i.test(t)) add(t.toLowerCase()); });
    if (cols.length >= 2) res.colours = cols.slice(0, 24);
    // imagens e canvas
    root.querySelectorAll("canvas,img").forEach(function (n) {
      if (inUi(n) || !visible(n)) return; var r = n.getBoundingClientRect(); if (r.width < 80 || r.height < 80) return;
      if (n.tagName === "IMG" && !/^(blob:|data:)/.test(n.src)) return;
      if (res.images.length < 6) res.images.push(n);
    });
    // textos
    var sel = (W.getSelection && W.getSelection().toString()) || ""; if (sel.trim().length) res.texts.push({ label: "Texto selecionado", text: sel });
    root.querySelectorAll("textarea,input[type=text],pre,code").forEach(function (n) {
      if (inUi(n) || !visible(n)) return; var t = (n.value != null ? n.value : n.textContent) || ""; t = t.trim();
      if (t.length < 8 || res.texts.length >= 6) return; if (res.texts.some(function (x) { return x.text === t; })) return;
      res.texts.push({ label: n.tagName === "TEXTAREA" || n.tagName === "INPUT" ? "Texto digitado" : "Resultado", text: t });
    });
    return res;
  }
  function imageData(n) {
    var w = n.naturalWidth || n.width, h = n.naturalHeight || n.height, max = 1600, k = Math.min(1, max / Math.max(w, h));
    function draw(kk) { var c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w * kk)); c.height = Math.max(1, Math.round(h * kk)); var x = c.getContext("2d"); x.drawImage(n, 0, 0, c.width, c.height); return c; }
    var big = draw(k), small = draw(Math.min(1, 480 / Math.max(w, h)));
    var png = big.toDataURL("image/png"), full = png.length > 2.5e6 ? big.toDataURL("image/jpeg", 0.9) : png;
    return { full: full, thumb: small.toDataURL("image/jpeg", 0.8), w: big.width, h: big.height };
  }
  function build() {
    var s = scan(), id = toolId(), title = toolTitle(), tool = { id: id, title: title, hash: location.hash || "" };
    pan.innerHTML = ""; pan.appendChild(el("h4", "", "Salvar no AVANT Hub")); pan.appendChild(el("p", "", "Escolha o que quer guardar. O item vai para a aba <b>Coleções</b> do hub, no quadro <b>AVANTools</b>. Para achar depois: abra o hub, vá em Coleções e entre em AVANTools. Também aparece aqui, em Salvos."));
    function done(box, r) { var b = box.querySelector("button"); if (r && r.ok) { b.disabled = true; b.textContent = "Salvo"; var o = box.querySelector(".avt-sv-ok") || box.appendChild(el("div", "avt-sv-ok", "")); o.textContent = "Pronto! Está em Coleções › " + (r.board || "AVANTools") + ", no hub."; } else { b.disabled = false; b.textContent = "Salvar"; var e = box.querySelector(".avt-sv-ok") || box.appendChild(el("div", "avt-sv-ok", "")); e.style.color = "#c0392b"; e.textContent = (r && r.err) || "Não consegui salvar."; } }
    function item(titleText, bodyEl, getMsg, defName) {
      var box = el("div", "avt-sv-it"); box.appendChild(el("b", "", titleText)); if (bodyEl) box.appendChild(bodyEl);
      var row = el("div", "avt-sv-row"), inp = el("input"); inp.value = defName; inp.setAttribute("aria-label", "Nome"); var go = el("button", "avt-sv-go", "Salvar");
      go.onclick = function () { go.disabled = true; go.textContent = "Salvando…"; var m; try { m = getMsg(inp.value.trim() || defName); } catch (x) { done(box, { ok: false, err: "Não consegui ler isso da tela." }); return; } toHub({ avt: "save", item: m }, function (r) { done(box, r); }); };
      row.appendChild(inp); row.appendChild(go); box.appendChild(row); pan.appendChild(box);
    }
    if (s.colours.length) { var sw = el("div", "avt-sv-sw"); s.colours.forEach(function (c) { var i = el("i"); i.style.background = c; i.title = c; sw.appendChild(i); });
      item("Cores desta tela (" + s.colours.length + ")", sw, function (n) { return { kind: "palette", title: n, colors: s.colours, tool: tool }; }, "Paleta · " + title); }
    s.images.forEach(function (n, k) { var d; try { d = imageData(n); } catch (x) { return; } var im = el("img", "avt-sv-th"); im.src = d.thumb;
      item("Imagem" + (s.images.length > 1 ? " " + (k + 1) : "") + " (" + d.w + " × " + d.h + ")", im, function (nm) { return { kind: "image", title: nm, full: d.full, thumb: d.thumb, w: d.w, h: d.h, tool: tool }; }, title + " (imagem)"); });
    s.texts.forEach(function (t) { item(t.label, el("div", "avt-sv-tx", esc(t.text.slice(0, 220))), function (nm) { return { kind: "text", title: nm, text: t.text.slice(0, 200000), tool: tool }; }, t.text.replace(/\s+/g, " ").slice(0, 40)); });
    item("Esta ferramenta", el("p", "", "Guarda um atalho para abrir " + esc(title) + " de novo" + (/\?/.test(location.hash) ? ", com os mesmos ajustes." : ".")), function (nm) { return { kind: "tool", title: nm, tool: tool }; }, title);
  }
  function mount() {
    btn = el("button", "avt-sv-btn", "Salvar no hub"); btn.type = "button"; btn.title = "Guarda esta cor, imagem ou texto nas Coleções do hub (quadro AVANTools)"; btn.hidden = true; pan = el("div", "avt-sv-pan"); pan.hidden = true; btn.setAttribute("translate","no"); pan.setAttribute("translate","no");
    btn.onclick = function () { if (pan.hidden) { build(); pan.hidden = false; } else pan.hidden = true; };
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") pan.hidden = true; });
    document.addEventListener("mousedown", function (e) { if (!pan.hidden && !pan.contains(e.target) && !btn.contains(e.target)) pan.hidden = true; });
    document.body.appendChild(pan); document.body.appendChild(btn); sync();
  }
  function sync() { if (!btn) return; var id = toolId(); btn.hidden = !id || id === "salvos"; if (btn.hidden) pan.hidden = true; }
  W.addEventListener("hashchange", function () { sync(); if (pan) pan.hidden = true; });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount); else mount();
})();
