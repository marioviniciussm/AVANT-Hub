# AVANT Hub 7.21.5

**Hub › Kit da marca (seção nova)**

- O **Kit da marca** saiu das AVANTools e agora tem a própria seção, no topo do Hub, entre **AVANTools** e **Coleções**.
  - Abre sozinho, sem o menu das AVANTools, com mais espaço.
  - Também ganhou um cartão na tela **Início**.
- Tudo que tinha no Kit continua lá: cores, logo, símbolo (com e sem fundo) e fontes.

**AVANTools › Menu lateral**

- O Kit da marca não aparece mais no menu, na busca nem em "Cores e marca".
- O menu ficou só com **Início, Guardados e Fluxos prontos** no topo.

**Hub › Início**

- Os cartões das seções agora se ajustam melhor, sem sobrar um cartão sozinho na linha de baixo.
