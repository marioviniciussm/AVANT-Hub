var RefHubEngine = (() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __commonJS = (cb, mod) => function __require2() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // engine/text.js
  var require_text = __commonJS({
    "engine/text.js"(exports, module) {
      function norm(text) {
        if (!text) return " ";
        let t = String(text).normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase();
        t = t.replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
        return " " + t + " ";
      }
      function hasTerm(ntext, term) {
        const t = norm(term).trim();
        if (!t) return false;
        return ntext.includes(` ${t} `) || ntext.includes(` ${t}s `) || ntext.includes(` ${t}es `);
      }
      var STOPWORDS = new Set(norm(`
a o as os um uma uns umas de da do das dos d em no na nos nas num numa por pelo pela
pelos pelas para pra pro com sem e ou que como sobre entre ate apos ao aos se
seu sua seus suas meu minha this the of and or for with to in on at by an from
`).trim().split(" "));
      var PHRASES = {
        "energia por assinatura": { en: ["energy subscription", "subscription energy"], related: ["solar energy", "solar panels", "community solar", "clean energy"] },
        "energia solar": { en: ["solar energy", "solar power"], related: ["solar panels", "photovoltaic"] },
        "energia limpa": { en: ["clean energy"], related: ["renewable energy", "solar energy", "wind energy"] },
        "energia renovavel": { en: ["renewable energy"], related: ["solar energy", "wind turbine", "clean energy"] },
        "energia eolica": { en: ["wind energy", "wind power"], related: ["wind turbine"] },
        "energia eletrica": { en: ["electricity", "electric power"], related: ["power lines"] },
        "geracao distribuida": { en: ["distributed generation"], related: ["solar panels", "rooftop solar"] },
        "painel solar": { en: ["solar panel"], related: ["photovoltaic", "solar energy"] },
        "paineis solares": { en: ["solar panels"], related: ["photovoltaic", "solar energy"] },
        "conta de luz": { en: ["electricity bill", "energy bill"], related: ["savings", "power bill"] },
        "mercado livre de energia": { en: ["energy market"], related: ["electricity"] },
        "carro eletrico": { en: ["electric car", "electric vehicle"], related: ["ev charging"] },
        "redes sociais": { en: ["social media"], related: ["instagram"] },
        "midia social": { en: ["social media"], related: ["instagram"] },
        "identidade visual": { en: ["visual identity", "brand identity"], related: ["branding", "logo"] },
        "design grafico": { en: ["graphic design"], related: ["poster", "layout"] },
        "post para instagram": { en: ["instagram post"], related: ["social media post"] },
        "post de instagram": { en: ["instagram post"], related: ["social media post"] },
        "story do instagram": { en: ["instagram story"], related: ["vertical story"] },
        "landing page": { en: ["landing page"], related: ["website", "web design"] },
        "dark mode": { en: ["dark mode"], related: ["dark ui"] },
        "flat design": { en: ["flat design"], related: ["flat illustration"] },
        "motion graphics": { en: ["motion graphics"], related: ["animation"] },
        "fundo abstrato": { en: ["abstract background"], related: ["gradient", "texture"] },
        "casa sustentavel": { en: ["sustainable house", "green home"], related: ["solar roof"] },
        "pequena empresa": { en: ["small business"], related: ["shop", "entrepreneur"] },
        "economia de energia": { en: ["energy saving", "energy efficiency"], related: ["savings", "light bulb"] },
        // áudio
        "efeito sonoro": { en: ["sound effect"], related: ["sfx"] },
        "efeitos sonoros": { en: ["sound effects"], related: ["sfx"] },
        "musica de fundo": { en: ["background music"], related: ["ambient", "instrumental"] },
        "trilha sonora": { en: ["soundtrack"], related: ["background music", "score"] },
        "som ambiente": { en: ["ambience", "ambient sound"], related: ["atmosphere", "room tone"] },
        "som de transicao": { en: ["transition sound"], related: ["whoosh", "swoosh"] },
        "camera lenta": { en: ["slow motion"], related: [] },
        "time lapse": { en: ["time lapse", "timelapse"], related: [] },
        "por do sol": { en: ["sunset"], related: ["golden hour"] },
        "ceu azul": { en: ["blue sky"], related: ["sky"] },
        "energia solar fotovoltaica": { en: ["solar photovoltaic"], related: ["solar panels"] },
        "vista aerea": { en: ["aerial view", "drone"], related: ["aerial"] }
      };
      var WORDS = {
        energia: ["energy", "power"],
        assinatura: ["subscription"],
        solar: ["solar"],
        eletricidade: ["electricity"],
        luz: ["light"],
        sol: ["sun", "sunlight"],
        sustentabilidade: ["sustainability"],
        sustentavel: ["sustainable"],
        economia: ["savings", "economy"],
        economizar: ["save money", "savings"],
        dinheiro: ["money"],
        conta: ["bill"],
        fatura: ["invoice", "bill"],
        desconto: ["discount"],
        preco: ["price"],
        cliente: ["customer"],
        clientes: ["customers"],
        empresa: ["company", "business"],
        negocio: ["business"],
        escritorio: ["office"],
        casa: ["house", "home"],
        lar: ["home"],
        familia: ["family"],
        cidade: ["city"],
        campo: ["countryside", "field"],
        natureza: ["nature"],
        planeta: ["planet"],
        verde: ["green"],
        azul: ["blue"],
        amarelo: ["yellow"],
        laranja: ["orange"],
        vermelho: ["red"],
        preto: ["black"],
        branco: ["white"],
        roxo: ["purple"],
        rosa: ["pink"],
        dourado: ["gold"],
        colorido: ["colorful"],
        gradiente: ["gradient"],
        degrade: ["gradient"],
        pessoas: ["people"],
        pessoa: ["person"],
        mulher: ["woman"],
        homem: ["man"],
        crianca: ["child"],
        tecnologia: ["technology"],
        inovacao: ["innovation"],
        futuro: ["future"],
        futurista: ["futuristic"],
        moderno: ["modern"],
        moderna: ["modern"],
        minimalista: ["minimalist"],
        minimalismo: ["minimalism"],
        vintage: ["vintage"],
        retro: ["retro"],
        geometrico: ["geometric"],
        abstrato: ["abstract"],
        elegante: ["elegant"],
        criativo: ["creative"],
        corporativo: ["corporate"],
        profissional: ["professional"],
        divertido: ["fun", "playful"],
        escuro: ["dark"],
        claro: ["light"],
        textura: ["texture"],
        fundo: ["background"],
        cartaz: ["poster"],
        poster: ["poster"],
        panfleto: ["flyer"],
        folheto: ["flyer", "brochure"],
        banner: ["banner"],
        capa: ["cover"],
        revista: ["magazine"],
        livro: ["book"],
        jornal: ["newspaper"],
        logo: ["logo"],
        logotipo: ["logo"],
        marca: ["brand"],
        embalagem: ["packaging"],
        rotulo: ["label"],
        tipografia: ["typography"],
        fonte: ["font"],
        letreiro: ["lettering"],
        icone: ["icon"],
        icones: ["icons"],
        ilustracao: ["illustration"],
        ilustracoes: ["illustrations"],
        desenho: ["drawing"],
        aquarela: ["watercolor"],
        fotografia: ["photography"],
        foto: ["photo"],
        fotos: ["photos"],
        retrato: ["portrait"],
        paisagem: ["landscape"],
        video: ["video"],
        videos: ["videos"],
        animacao: ["animation"],
        vinheta: ["intro", "bumper"],
        anuncio: ["ad", "advertisement"],
        anuncios: ["ads"],
        campanha: ["campaign"],
        publicidade: ["advertising"],
        propaganda: ["advertising"],
        outdoor: ["billboard"],
        loja: ["store", "shop"],
        aplicativo: ["app", "mobile app"],
        site: ["website"],
        interface: ["interface"],
        painel: ["dashboard", "panel"],
        carrossel: ["carousel"],
        infografico: ["infographic"],
        grafico: ["chart", "graphic"],
        mapa: ["map"],
        predio: ["building"],
        telhado: ["rooftop", "roof"],
        fabrica: ["factory"],
        industria: ["industry"],
        agricultura: ["agriculture"],
        fazenda: ["farm"],
        vento: ["wind"],
        agua: ["water"],
        chuva: ["rain"],
        trovao: ["thunder"],
        verao: ["summer"],
        inverno: ["winter"],
        noite: ["night"],
        dia: ["day"],
        lampada: ["light bulb"],
        tomada: ["power outlet", "plug"],
        bateria: ["battery"],
        carregador: ["charger"],
        mockup: ["mockup"],
        template: ["template"],
        modelo: ["template", "model"],
        celular: ["smartphone", "phone"],
        computador: ["computer"],
        trabalho: ["work"],
        equipe: ["team"],
        reuniao: ["meeting"],
        evento: ["event"],
        festa: ["party"],
        natal: ["christmas"],
        comida: ["food"],
        cafe: ["coffee"],
        saude: ["health"],
        esporte: ["sport"],
        viagem: ["travel"],
        praia: ["beach"],
        mar: ["sea", "ocean"],
        floresta: ["forest"],
        montanha: ["mountain"],
        ceu: ["sky"],
        nuvem: ["cloud"],
        nuvens: ["clouds"],
        transito: ["traffic"],
        rua: ["street"],
        drone: ["drone"],
        // áudio
        musica: ["music"],
        som: ["sound"],
        sons: ["sounds"],
        efeito: ["effect"],
        clique: ["click"],
        aplauso: ["applause"],
        aplausos: ["applause"],
        transicao: ["transition"],
        notificacao: ["notification"],
        alerta: ["alert"],
        sino: ["bell"],
        passos: ["footsteps"],
        porta: ["door"],
        explosao: ["explosion"],
        batida: ["beat", "hit"],
        impacto: ["impact"],
        calmo: ["calm"],
        calma: ["calm"],
        animado: ["upbeat"],
        alegre: ["happy", "upbeat"],
        triste: ["sad"],
        epico: ["epic"],
        suspense: ["suspense"],
        piano: ["piano"],
        violao: ["acoustic guitar"],
        guitarra: ["guitar"],
        ambiente: ["ambient"],
        eletronica: ["electronic"],
        pop: ["pop"],
        rock: ["rock"],
        jazz: ["jazz"],
        lofi: ["lofi"],
        inspirador: ["inspiring"],
        inspiradora: ["inspiring"],
        vinil: ["vinyl"],
        risada: ["laugh"],
        voz: ["voice"],
        feliz: ["happy"],
        energetico: ["energetic"],
        motivacional: ["motivational"],
        relaxante: ["relaxing"],
        romantico: ["romantic"],
        tensao: ["tension"],
        misterio: ["mystery"],
        tecnologico: ["tech"],
        whoosh: ["whoosh"],
        swoosh: ["swoosh"],
        glitch: ["glitch"],
        riser: ["riser"],
        intro: ["intro"],
        abertura: ["opening", "intro"],
        madeira: ["wood"],
        metal: ["metal"],
        concreto: ["concrete"],
        cimento: ["concrete"],
        tijolo: ["brick"],
        pedra: ["stone"],
        tecido: ["fabric"],
        couro: ["leather"],
        grama: ["grass"],
        areia: ["sand"],
        marmore: ["marble"],
        vidro: ["glass"],
        plastico: ["plastic"],
        ferrugem: ["rust"],
        asfalto: ["asphalt"],
        piso: ["floor"],
        parede: ["wall"],
        telha: ["roof tiles"],
        terra: ["ground", "soil"],
        folha: ["leaf"],
        folhas: ["leaves"],
        neve: ["snow"],
        gelo: ["ice"],
        estudio: ["studio"],
        interior: ["interior"],
        cozinha: ["kitchen"],
        sala: ["living room"],
        quarto: ["bedroom"],
        carro: ["car"],
        arvore: ["tree"],
        planta: ["plant"],
        flor: ["flower"],
        flores: ["flowers"],
        animal: ["animal"],
        cachorro: ["dog"],
        gato: ["cat"],
        caneca: ["mug"],
        garrafa: ["bottle"],
        camiseta: ["t-shirt"],
        sacola: ["bag"],
        teclado: ["keyboard typing"],
        digitando: ["typing"],
        caixa: ["box", "cash register"]
      };
      var CATEGORIES = {
        design: {
          label: "Design gráfico",
          triggers: ["design", "design grafico", "graphic design", "arte grafica", "peca", "pecas"],
          modifiers: ["graphic design", "poster"],
          match: [
            "design",
            "graphic",
            "poster",
            "flyer",
            "layout",
            "typography",
            "vector",
            "illustration",
            "template",
            "banner",
            "mockup",
            "infographic",
            "brochure",
            "composition",
            "print"
          ],
          ov: "illustration,digitized_artwork",
          pixabay: "illustration",
          magnific: ["vector", "psd"]
        },
        social_media: {
          label: "Social media",
          triggers: [
            "social media",
            "redes sociais",
            "midia social",
            "instagram",
            "post",
            "posts",
            "feed",
            "stories",
            "story",
            "reels",
            "tiktok",
            "facebook",
            "linkedin",
            "carrossel"
          ],
          modifiers: ["social media post", "instagram post"],
          match: [
            "social media",
            "instagram",
            "post",
            "feed",
            "story",
            "stories",
            "facebook",
            "tiktok",
            "linkedin",
            "carousel",
            "template",
            "banner",
            "ad",
            "promotion",
            "advertising"
          ],
          ov: "illustration,digitized_artwork",
          pixabay: "illustration",
          magnific: ["psd", "vector"]
        },
        ilustracao: {
          label: "Ilustração e desenho",
          triggers: ["ilustracao", "ilustracoes", "illustration", "desenho", "desenhos", "vetor", "vector", "sketch", "rascunho"],
          modifiers: ["illustration", "drawing"],
          match: ["illustration", "vector", "drawing", "sketch", "cartoon", "flat", "isometric", "clipart", "art", "ink", "painting"],
          ov: "illustration",
          pixabay: "vector",
          magnific: ["vector"]
        },
        branding: {
          label: "Branding e logo",
          triggers: ["branding", "logo", "logotipo", "identidade visual", "marca"],
          modifiers: ["branding", "logo"],
          match: ["brand", "branding", "logo", "identity", "mockup", "stationery", "packaging", "emblem"],
          ov: "illustration,digitized_artwork",
          pixabay: "vector",
          magnific: ["vector", "psd"]
        },
        tipografia: {
          label: "Tipografia",
          triggers: ["tipografia", "typography", "lettering", "letreiro", "fonte", "fontes"],
          modifiers: ["typography", "lettering"],
          match: ["typography", "type", "lettering", "font", "typeface", "letters", "calligraphy", "poster"],
          ov: "illustration,digitized_artwork",
          pixabay: "illustration",
          magnific: ["vector", "psd"]
        },
        ui_ux: {
          label: "UI / UX",
          triggers: ["ui", "ux", "interface", "app", "aplicativo", "site", "website", "landing page", "dashboard"],
          modifiers: ["ui design", "app interface"],
          match: ["ui", "ux", "interface", "app", "website", "web", "dashboard", "screen", "mobile", "landing"],
          ov: "illustration,digitized_artwork",
          pixabay: "illustration",
          magnific: ["vector", "psd"]
        },
        publicidade: {
          label: "Publicidade",
          triggers: ["publicidade", "propaganda", "anuncio", "anuncios", "campanha", "ads", "outdoor"],
          modifiers: ["advertising", "ad campaign"],
          match: ["ad", "ads", "advertising", "advertisement", "campaign", "billboard", "promotion", "marketing", "poster"],
          ov: "",
          pixabay: "all",
          magnific: ["psd", "photo"]
        },
        editorial: {
          label: "Editorial",
          triggers: ["editorial", "revista", "jornal", "capa", "livro", "diagramacao"],
          modifiers: ["editorial design", "magazine layout"],
          match: ["editorial", "magazine", "cover", "book", "newspaper", "layout", "page", "spread"],
          ov: "illustration,digitized_artwork",
          pixabay: "all",
          magnific: ["psd", "vector"]
        },
        motion: {
          label: "Motion e GIF",
          triggers: ["motion", "motion graphics", "animacao", "animation", "vinheta", "gif", "gifs"],
          modifiers: ["motion graphics", "animation"],
          match: ["motion", "animation", "animated", "loop", "intro", "gif"],
          ov: "",
          pixabay: "all",
          magnific: ["vector"]
        },
        "3d": {
          label: "3D",
          triggers: ["3d", "render", "blender", "cinema 4d", "c4d"],
          modifiers: ["3d render"],
          match: ["3d", "render", "rendering", "blender", "isometric", "cgi"],
          ov: "illustration,digitized_artwork",
          pixabay: "illustration",
          magnific: ["psd", "vector"]
        },
        arte: {
          label: "Arte e museus",
          triggers: ["arte", "pintura", "museu", "quadro", "gravura", "art"],
          modifiers: ["art", "painting"],
          match: ["art", "painting", "print", "poster", "drawing", "engraving", "lithograph", "artwork"],
          ov: "digitized_artwork",
          pixabay: "illustration",
          magnific: ["vector"]
        }
      };
      var NSFW_TERMS = [
        "nsfw",
        "nude",
        "nudes",
        "nudity",
        "naked",
        "porn",
        "porno",
        "pornographic",
        "pornography",
        "xxx",
        "sex",
        "sexy",
        "sexual",
        "erotic",
        "erotica",
        "hentai",
        "fetish",
        "bdsm",
        "bondage",
        "lingerie",
        "topless",
        "bottomless",
        "boobs",
        "breasts",
        "nipple",
        "nipples",
        "genital",
        "genitals",
        "penis",
        "vagina",
        "onlyfans",
        "playboy",
        "stripper",
        "striptease",
        "camgirl",
        "escort",
        "orgy",
        "gore",
        "gory",
        "corpse",
        "corpses",
        "dead body",
        "beheading",
        "decapitated",
        "mutilated",
        "autopsy",
        "nu",
        "nua",
        "nus",
        "nuas",
        "nudez",
        "pelado",
        "pelada",
        "pelados",
        "peladas",
        "sexo",
        "sensual",
        "erotico",
        "pornografia",
        "pornografico",
        "seios",
        "seio",
        "mamilo",
        "mamilos",
        "calcinha",
        "fetiche",
        "safada",
        "safado",
        "putaria",
        "acompanhante",
        "cadaver",
        "cadaveres",
        "decapitado",
        "mutilado",
        "sangrento"
      ].map((t) => norm(t).trim());
      function isNsfwText(text) {
        const n = norm(text);
        return NSFW_TERMS.some((t) => n.includes(` ${t} `));
      }
      module.exports = { norm, hasTerm, STOPWORDS, PHRASES, WORDS, CATEGORIES, isNsfwText };
    }
  });

  // engine/query.js
  var require_query = __commonJS({
    "engine/query.js"(exports, module) {
      var { norm, STOPWORDS, PHRASES, WORDS } = require_text();
      function lookup(w) {
        const tries = [
          w,
          w.replace(/s$/, ""),
          w.replace(/a$/, "o"),
          w.replace(/as$/, "os"),
          w.replace(/as$/, "o"),
          w.replace(/oes$/, "ao"),
          w.replace(/aes$/, "ao"),
          w.replace(/is$/, "l"),
          w.replace(/es$/, "")
        ];
        for (const t of tries) if (WORDS[t]) return WORDS[t];
        return null;
      }
      function translateWords(text) {
        const out = [];
        for (const w of norm(text).trim().split(" ")) {
          if (!w || STOPWORDS.has(w)) continue;
          out.push((lookup(w) || [w])[0]);
        }
        return out.join(" ") || text;
      }
      function parseQuery(raw) {
        raw = (raw || "").trim();
        const quoted = [...raw.matchAll(/"([^"]+)"/g)].map((m) => m[1]);
        const tokens = norm(raw.replace(/"[^"]+"/g, " ")).trim().split(" ").filter(Boolean);
        const phraseKeys = Object.keys(PHRASES).sort((a, b) => b.split(" ").length - a.split(" ").length);
        const concepts = [];
        for (const q of quoted) {
          const qn = norm(q).trim();
          const e = PHRASES[qn];
          concepts.push({ label: q, pt: [qn], en: e ? e.en : [translateWords(qn)], related: e ? e.related : [], phrase: true });
        }
        let i = 0;
        while (i < tokens.length) {
          const hit = phraseKeys.find((k) => k.split(" ").every((x, j) => tokens[i + j] === x));
          if (hit) {
            const e = PHRASES[hit];
            concepts.push({ label: hit, pt: [hit], en: e.en, related: e.related, phrase: true });
            i += hit.split(" ").length;
            continue;
          }
          const w = tokens[i++];
          if (STOPWORDS.has(w) || w.length < 2 && !/\d/.test(w)) continue;
          const en = lookup(w);
          concepts.push({ label: w, pt: [w], en: en || [w], related: [], phrase: false });
        }
        const enCore = concepts.map((c) => c.en[0]).join(" ").trim();
        const ptCore = concepts.map((c) => c.pt[0]).join(" ").trim();
        return {
          raw,
          concepts,
          enCore,
          ptCore,
          related: [...new Set(concepts.flatMap((c) => c.related.slice(0, 2)))],
          fullPhrase: ptCore.split(" ").length >= 2 ? ptCore : ""
        };
      }
      function buildVariants(pq, extra = [], mod = "") {
        const variants = [];
        const add = (q, w, kind) => {
          q = q.replace(/\s+/g, " ").trim();
          if (q && !variants.some((x) => x.q === q)) variants.push({ q, w, kind });
        };
        const ex = extra.join(" ");
        if (pq.enCore) {
          if (ex) add(`${pq.enCore} ${ex}`, 1, "strict");
          else if (mod) add(`${pq.enCore} ${mod}`, 1, "strict");
          add(pq.enCore, 0.9, "core");
          for (const r of pq.related.slice(0, 2)) add(r, 0.55, "related");
          if (ex && mod) add(`${pq.enCore} ${mod}`, 0.85, "strict");
          if (pq.ptCore !== pq.enCore) add(pq.ptCore, 0.75, "pt");
        } else if (ex || mod) {
          add(ex || mod, 0.8, "core");
        }
        return variants;
      }
      module.exports = { parseQuery, buildVariants, translateWords };
    }
  });

  // engine/licenses.js
  var require_licenses = __commonJS({
    "engine/licenses.js"(exports, module) {
      var L = {
        cc0: { label: "CC0 (domínio público)", commercial: true, modify: true, attribution: false },
        pdm: { label: "Domínio público", commercial: true, modify: true, attribution: false },
        by: { label: "CC BY (dar crédito)", commercial: true, modify: true, attribution: true },
        "by-sa": { label: "CC BY-SA (crédito + mesma licença)", commercial: true, modify: true, attribution: true },
        "by-nd": { label: "CC BY-ND (sem editar)", commercial: true, modify: false, attribution: true },
        "by-nc": { label: "CC BY-NC (não comercial)", commercial: false, modify: true, attribution: true },
        "by-nc-sa": { label: "CC BY-NC-SA (não comercial)", commercial: false, modify: true, attribution: true },
        "by-nc-nd": { label: "CC BY-NC-ND (não comercial)", commercial: false, modify: false, attribution: true },
        "sampling+": { label: "Sampling+", commercial: true, modify: true, attribution: true },
        pexels: { label: "Licença Pexels (uso livre)", commercial: true, modify: true, attribution: false },
        pixabay: { label: "Licença Pixabay (uso livre)", commercial: true, modify: true, attribution: false },
        unsplash: { label: "Licença Unsplash (uso livre)", commercial: true, modify: true, attribution: false },
        coverr: { label: "Licença Coverr (uso livre)", commercial: true, modify: true, attribution: false },
        nasa: { label: "NASA (domínio público)", commercial: true, modify: true, attribution: false },
        ytcc: { label: "YouTube CC BY", commercial: true, modify: true, attribution: true },
        magnific_free: { label: "Freepik/Magnific grátis (crédito)", commercial: true, modify: true, attribution: true },
        magnific_premium: { label: "Freepik/Magnific premium", commercial: false, modify: false, attribution: false },
        iconify: { label: "Licença aberta do pacote de ícones", commercial: true, modify: true, attribution: false },
        rights: { label: "Direitos do autor (só inspiração)", commercial: false, modify: false, attribution: true },
        giphy: { label: "GIPHY (só inspiração)", commercial: false, modify: false, attribution: true },
        unknown: { label: "Licença não informada", commercial: false, modify: false, attribution: true }
      };
      function lic(code, url = "") {
        const base = L[code] || L.unknown;
        return { code: L[code] ? code : "unknown", url, ...base };
      }
      function fromText(s, url) {
        const t = String(s || "").toLowerCase();
        const u = url || (t.startsWith("http") ? s : "");
        if (!t) return lic("unknown", u);
        if (/publicdomain\/zero|\bcc0\b|creative commons 0/.test(t)) return lic("cc0", u);
        if (/publicdomain|public domain|\bpdm\b|\bpd\b/.test(t)) return lic("pdm", u);
        if (/sampling/.test(t)) return lic("sampling+", u);
        const nc = /by-nc|noncommercial|non-commercial|\bnc\b/.test(t);
        const nd = /-nd\b|by-nd|noderiv|no deriv|\bnd\b/.test(t);
        const sa = /-sa\b|by-sa|sharealike|share alike|\bsa\b/.test(t);
        const by = /\bby\b|attribution|creativecommons|cc /.test(t) || nc || nd || sa;
        if (!by) return lic("unknown", u);
        if (nc && nd) return lic("by-nc-nd", u);
        if (nc && sa) return lic("by-nc-sa", u);
        if (nc) return lic("by-nc", u);
        if (nd) return lic("by-nd", u);
        if (sa) return lic("by-sa", u);
        return lic("by", u);
      }
      function passes(license, mode) {
        if (!mode || mode === "any") return true;
        if (mode === "pd") return license.commercial && license.modify && !license.attribution;
        if (mode === "commercial") return license.commercial && license.modify;
        return true;
      }
      module.exports = { lic, fromText, passes };
    }
  });

  // engine/sources.js
  var require_sources = __commonJS({
    "engine/sources.js"(exports, module) {
      var { lic, fromText } = require_licenses();
      var { norm } = require_text();
      var UA = "RefHub/6.0 (app desktop de referencias; uso interno)";
      var TIMEOUT = 1e4;
      var PER = 20;
      async function getJSON(url, headers = {}) {
        const r = await fetch(url, {
          headers: { "User-Agent": UA, Accept: "application/json", ...headers },
          signal: AbortSignal.timeout(TIMEOUT)
        });
        if (!r.ok) {
          const e = new Error(`HTTP ${r.status}`);
          e.status = r.status;
          throw e;
        }
        return r.json();
      }
      function getJSONBigHeaders(url) {
        if (typeof process === "undefined" || !process.versions || !process.versions.node || typeof window !== "undefined") return getJSON(url);
        const https = __require("https");
        return new Promise((resolve, reject) => {
          const req = https.get(url, { headers: { "User-Agent": UA, Accept: "application/json" }, maxHeaderSize: 256 * 1024, timeout: TIMEOUT }, (res) => {
            if (res.statusCode >= 300) {
              res.resume();
              const e = new Error(`HTTP ${res.statusCode}`);
              e.status = res.statusCode;
              return reject(e);
            }
            let b = "";
            res.setEncoding("utf8");
            res.on("data", (c) => b += c);
            res.on("end", () => {
              try {
                resolve(JSON.parse(b));
              } catch (e) {
                reject(e);
              }
            });
          });
          req.on("timeout", () => req.destroy(Object.assign(new Error("timeout"), { name: "TimeoutError" })));
          req.on("error", reject);
        });
      }
      var wmQueue = Promise.resolve();
      function wikimediaGet(url) {
        const run = async () => {
          for (let i = 0; i < 2; i++) {
            try {
              return await getJSON(url, { "Api-User-Agent": UA });
            } catch (e) {
              if (e.status !== 429 || i) throw e;
              await new Promise((r) => setTimeout(r, 1500));
            }
          }
        };
        const p = wmQueue.then(run, run);
        wmQueue = p.catch(() => {
        });
        return p;
      }
      var qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== void 0 && v !== null && v !== "")).toString();
      var strip = (s) => String(s || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
      var COLOR = {
        pexels: { vermelho: "red", laranja: "orange", amarelo: "yellow", verde: "green", azul: "blue", roxo: "violet", rosa: "pink", preto: "black", branco: "white", pb: "gray" },
        unsplash: { vermelho: "red", laranja: "orange", amarelo: "yellow", verde: "green", azul: "blue", roxo: "purple", rosa: "magenta", preto: "black", branco: "white", pb: "black_and_white" },
        pixabay: { vermelho: "red", laranja: "orange", amarelo: "yellow", verde: "green", azul: "blue", roxo: "lilac", rosa: "pink", preto: "black", branco: "white", pb: "grayscale" }
      };
      var ORIENT = {
        openverse: { horizontal: "wide", vertical: "tall", quadrado: "square" },
        pexels: { horizontal: "landscape", vertical: "portrait", quadrado: "square" },
        unsplash: { horizontal: "landscape", vertical: "portrait", quadrado: "squarish" },
        pixabay: { horizontal: "horizontal", vertical: "vertical" },
        magnific: { horizontal: "landscape", vertical: "portrait", quadrado: "square" }
      };
      function ovLicense(r) {
        const l = (r.license || "").toLowerCase();
        if (l === "cc0") return lic("cc0", r.license_url);
        if (l === "pdm") return lic("pdm", r.license_url);
        return fromText(`cc ${l}`, r.license_url);
      }
      function ovLicenseParams(o) {
        if (o.license === "pd") return { license: "cc0,pdm" };
        if (o.license === "commercial") return { license_type: "commercial,modification" };
        return {};
      }
      var ovToken = { value: "", until: 0, id: "" };
      async function openverseHeaders(o) {
        const id = o.key("OPENVERSE_CLIENT_ID"), secret = o.key("OPENVERSE_CLIENT_SECRET");
        if (!id || !secret) return {};
        if (!(ovToken.value && ovToken.id === id && Date.now() < ovToken.until)) {
          const r = await fetch("https://api.openverse.org/v1/auth_tokens/token/", {
            method: "POST",
            headers: { "User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded" },
            body: qs({ grant_type: "client_credentials", client_id: id, client_secret: secret }),
            signal: AbortSignal.timeout(TIMEOUT)
          });
          if (!r.ok) return {};
          const d = await r.json();
          ovToken = { value: d.access_token, until: Date.now() + ((d.expires_in || 3600) - 120) * 1e3, id };
        }
        return { Authorization: "Bearer " + ovToken.value };
      }
      function smartThumb(url, fallback) {
        try {
          const u = String(url || "");
          let m = u.match(/^(https:\/\/upload\.wikimedia\.org\/wikipedia\/commons)\/(\w\/\w\w)\/([^/]+)$/);
          if (m) return `${m[1]}/thumb/${m[2]}/${m[3]}/480px-${m[3]}${/\.svg$/i.test(m[3]) ? ".png" : ""}`;
          m = u.match(/^(https:\/\/(?:live|farm\d+)\.staticflickr\.com\/.+\/\d+_[0-9a-f]+)(?:_[a-z])?\.jpg$/);
          if (m && !/_o\.jpg$/.test(u)) return m[1] + "_n.jpg";
        } catch {
        }
        return fallback || url;
      }
      async function openverseImages(q, o, category) {
        const p = {
          q,
          page: o.page,
          page_size: PER,
          mature: o.nsfw ? "false" : "true",
          aspect_ratio: ORIENT.openverse[o.orient],
          category,
          ...ovLicenseParams(o),
          extension: o.extension,
          size: { baixa: "small", media: "medium", alta: "large" }[o.res]
        };
        const d = await getJSON("https://api.openverse.org/v1/images/?" + qs(p), await openverseHeaders(o));
        return (d.results || []).map((r) => ({
          id: "ov:" + r.id,
          kind: "image",
          title: r.title || "",
          text: `${r.title || ""} ${(r.tags || []).map((t) => t.name).join(" ")}`,
          thumb: smartThumb(r.url, r.thumbnail || r.url),
          thumb2: r.thumbnail,
          full: r.url,
          page: r.foreign_landing_url || r.url,
          author: r.creator || "",
          license: ovLicense(r),
          w: r.width,
          h: r.height,
          mature: !!r.mature
        }));
      }
      async function openverseAudio(q, o, kind) {
        const filt = kind === "sfx" ? { source: "freesound" } : { category: "music" };
        const p = { q, page: o.page, page_size: PER, mature: o.nsfw ? "false" : "true", ...filt, ...ovLicenseParams(o) };
        const d = await getJSON("https://api.openverse.org/v1/audio/?" + qs(p), await openverseHeaders(o));
        return (d.results || []).map((r) => ({
          id: "ova:" + r.id,
          kind: "audio",
          title: r.title || "",
          text: `${r.title || ""} ${(r.tags || []).map((t) => t.name).join(" ")} ${(r.genres || []).join(" ")}`,
          thumb: r.thumbnail || "",
          audio: r.url,
          page: r.foreign_landing_url || r.url,
          author: r.creator || "",
          license: ovLicense(r),
          duration: r.duration ? r.duration / 1e3 : null,
          mature: !!r.mature
        }));
      }
      async function wikimedia(q, o, kind) {
        const filt = { image: "filetype:bitmap|drawing", video: "filetype:video", audio: "filetype:audio", model: "filetype:3d", gif: "filemime:image/gif" }[kind];
        const p = {
          action: "query",
          format: "json",
          origin: "*",
          generator: "search",
          gsrsearch: `${q} ${filt}`,
          gsrnamespace: 6,
          gsrlimit: PER,
          gsroffset: (o.page - 1) * PER,
          prop: "imageinfo",
          iiprop: "url|mime|size|extmetadata",
          iiurlwidth: kind === "audio" ? void 0 : 640,
          iiextmetadatafilter: "ImageDescription|Artist|LicenseShortName|LicenseUrl|Categories|ObjectName"
        };
        const d = await wikimediaGet("https://commons.wikimedia.org/w/api.php?" + qs(p));
        const pages = Object.values((d.query || {}).pages || {}).sort((a, b) => (a.index || 999) - (b.index || 999));
        const out = [];
        for (const pg of pages) {
          const ii = (pg.imageinfo || [{}])[0];
          const mime = ii.mime || "";
          if (kind === "image" && !/^image\/(jpeg|png|webp|gif|svg)/.test(mime)) continue;
          if (kind === "gif" && mime !== "image/gif") continue;
          if (kind === "video" && !mime.startsWith("video/")) continue;
          if (kind === "audio" && !(mime.startsWith("audio/") || mime === "application/ogg" && !ii.width)) continue;
          const m = (k) => strip(((ii.extmetadata || {})[k] || {}).value);
          const title = (pg.title || "").replace(/^File:/, "").replace(/\.[a-z0-9]{2,5}$/i, "").replace(/_/g, " ");
          out.push({
            id: "wm:" + pg.pageid,
            kind: kind === "model" ? "image" : kind,
            title,
            meta: kind === "model" ? "Modelo 3D (STL)" : void 0,
            text: `${title} ${m("ObjectName")} ${m("ImageDescription").slice(0, 400)} ${m("Categories").replace(/\|/g, " ")}`,
            thumb: kind === "audio" ? "" : ii.thumburl || ii.url,
            full: kind === "model" ? ii.responsiveUrls?.["2"] || ii.thumburl : ii.url,
            download: kind === "model" ? ii.url : void 0,
            video: kind === "video" ? ii.url : void 0,
            audio: kind === "audio" ? ii.url : void 0,
            duration: ii.duration || null,
            page: ii.descriptionurl || "",
            author: m("Artist").slice(0, 80),
            license: fromText(m("LicenseShortName"), m("LicenseUrl")),
            w: ii.thumbwidth || ii.width,
            h: ii.thumbheight || ii.height,
            origW: ii.width,
            origH: ii.height,
            mature: false
          });
        }
        return out;
      }
      async function pexelsPhotos(q, o) {
        const d = await getJSON(
          "https://api.pexels.com/v1/search?" + qs({ query: q, per_page: PER, page: o.page, orientation: ORIENT.pexels[o.orient], color: COLOR.pexels[o.color], size: { baixa: "small", media: "medium", alta: "large" }[o.res] }),
          { Authorization: o.key("PEXELS_KEY") }
        );
        return (d.photos || []).map((r) => {
          const slug = (r.url || "").replace(/\/$/, "").split("/").pop().replace(/-\d+$/, "").replace(/-/g, " ");
          return {
            id: "px:" + r.id,
            kind: "image",
            title: r.alt || slug,
            text: `${r.alt || ""} ${slug}`,
            thumb: r.src?.medium,
            full: r.src?.large2x || r.src?.original,
            page: r.url,
            author: r.photographer || "",
            license: lic("pexels", "https://www.pexels.com/license/"),
            w: r.width,
            h: r.height
          };
        });
      }
      async function pexelsVideos(q, o) {
        const d = await getJSON(
          "https://api.pexels.com/videos/search?" + qs({ query: q, per_page: PER, page: o.page, orientation: ORIENT.pexels[o.orient], size: { baixa: "small", media: "medium", alta: "large" }[o.res] }),
          { Authorization: o.key("PEXELS_KEY") }
        );
        return (d.videos || []).map((r) => {
          const files = (r.video_files || []).filter((f) => (f.file_type || "").endsWith("mp4")).sort((a, b) => Math.abs((a.width || 0) - 1280) - Math.abs((b.width || 0) - 1280));
          const slug = (r.url || "").replace(/\/$/, "").split("/").pop().replace(/-?\d+$/, "").replace(/-/g, " ");
          return files.length && {
            id: "pxv:" + r.id,
            kind: "video",
            title: slug,
            text: slug,
            thumb: r.image,
            full: r.image,
            video: files[0].link,
            page: r.url,
            author: r.user?.name || "",
            license: lic("pexels", "https://www.pexels.com/license/"),
            w: r.width,
            h: r.height,
            duration: r.duration,
            download: (r.video_files || []).filter((f) => (f.file_type || "").endsWith("mp4")).sort((a, b) => (b.width || 0) - (a.width || 0))[0]?.link
          };
        }).filter(Boolean);
      }
      async function pixabayImages(q, o, imageType) {
        const d = await getJSON("https://pixabay.com/api/?" + qs({
          key: o.key("PIXABAY_KEY"),
          q: q.slice(0, 100),
          per_page: PER,
          page: o.page,
          safesearch: o.nsfw ? "true" : "false",
          image_type: imageType || "all",
          orientation: ORIENT.pixabay[o.orient],
          colors: COLOR.pixabay[o.color],
          min_width: { media: 1e3, alta: 2500 }[o.res]
        }));
        return (d.hits || []).map((r) => ({
          id: "pb:" + r.id,
          kind: "image",
          title: r.tags || "",
          text: r.tags || "",
          thumb: r.webformatURL,
          full: r.largeImageURL || r.webformatURL,
          page: r.pageURL,
          author: r.user || "",
          license: lic("pixabay", "https://pixabay.com/service/license-summary/"),
          w: r.imageWidth,
          h: r.imageHeight
        }));
      }
      async function pixabayVideos(q, o) {
        const d = await getJSON("https://pixabay.com/api/videos/?" + qs({
          key: o.key("PIXABAY_KEY"),
          q: q.slice(0, 100),
          per_page: PER,
          page: o.page,
          safesearch: o.nsfw ? "true" : "false",
          min_width: { media: 1280, alta: 1920 }[o.res]
        }));
        return (d.hits || []).map((r) => {
          const f = r.videos?.medium || r.videos?.small || r.videos?.large || {};
          return f.url && {
            id: "pbv:" + r.id,
            kind: "video",
            title: r.tags || "",
            text: r.tags || "",
            thumb: f.thumbnail,
            full: f.thumbnail,
            video: f.url,
            page: r.pageURL,
            author: r.user || "",
            license: lic("pixabay", "https://pixabay.com/service/license-summary/"),
            w: f.width,
            h: f.height,
            duration: r.duration,
            origW: (r.videos?.large || r.videos?.medium || {}).width,
            origH: (r.videos?.large || r.videos?.medium || {}).height
          };
        }).filter(Boolean);
      }
      async function unsplash(q, o) {
        const d = await getJSON("https://api.unsplash.com/search/photos?" + qs({
          query: q,
          per_page: PER,
          page: o.page,
          content_filter: o.nsfw ? "high" : "low",
          orientation: ORIENT.unsplash[o.orient],
          color: COLOR.unsplash[o.color]
        }), { Authorization: "Client-ID " + o.key("UNSPLASH_KEY"), "Accept-Version": "v1" });
        return (d.results || []).map((r) => ({
          id: "us:" + r.id,
          kind: "image",
          title: r.alt_description || r.description || "",
          text: `${r.alt_description || ""} ${r.description || ""} ${(r.tags || []).map((t) => t.title).join(" ")}`,
          thumb: r.urls?.small,
          full: r.urls?.regular,
          page: r.links?.html,
          author: r.user?.name || "",
          license: lic("unsplash", "https://unsplash.com/license"),
          w: r.width,
          h: r.height
        }));
      }
      async function nasa(q, o, mediaType) {
        const d = await getJSON("https://images-api.nasa.gov/search?" + qs({ q, media_type: mediaType, page: o.page, page_size: PER }));
        return ((d.collection || {}).items || []).map((it) => {
          const m = (it.data || [{}])[0];
          const prev = ((it.links || []).find((l) => l.rel === "preview") || {}).href || "";
          const kind = { image: "image", video: "video", audio: "audio" }[mediaType];
          return {
            id: "nasa:" + m.nasa_id,
            kind,
            title: m.title || "",
            text: `${m.title || ""} ${(m.keywords || []).join(" ")} ${(m.description || "").slice(0, 300)}`,
            thumb: prev,
            full: mediaType === "image" ? prev.replace("~thumb", "~medium") : prev,
            resolve: mediaType === "image" ? void 0 : { type: "nasa", href: it.href, media: mediaType },
            page: `https://images.nasa.gov/details/${encodeURIComponent(m.nasa_id)}`,
            author: m.center ? `NASA ${m.center}` : "NASA",
            license: lic("nasa", "https://www.nasa.gov/nasa-brand-center/images-and-media/")
          };
        });
      }
      async function archive(q, o, mediatype, scope = "") {
        let filt = "(licenseurl:*creativecommons* OR licenseurl:*publicdomain*)";
        if (scope === "music") filt += " AND collection:(netlabels OR audio_music OR jamendo-albums)";
        if (scope === "sfx") filt += ' AND (subject:(sfx OR "sound effects" OR "sound effect") OR title:(sfx OR "sound effect" OR "sound effects"))';
        if (o.license === "commercial") filt += " AND NOT licenseurl:*nc* AND NOT licenseurl:*nd*";
        if (o.license === "pd") filt = "(licenseurl:*publicdomain*)";
        const query = `(${q}) AND mediatype:(${mediatype}) AND ${filt}`;
        const url = "https://archive.org/advancedsearch.php?" + qs({ q: query, rows: PER, page: o.page, output: "json" }) + ["identifier", "title", "licenseurl", "creator", "subject", "description"].map((f) => `&fl[]=${f}`).join("");
        const d = await getJSON(url);
        return ((d.response || {}).docs || []).map((r) => {
          const subj = Array.isArray(r.subject) ? r.subject.join(" ") : r.subject || "";
          const desc = strip(Array.isArray(r.description) ? r.description.join(" ") : r.description).slice(0, 300);
          const kind = mediatype === "audio" ? "audio" : "video";
          return {
            id: "ia:" + r.identifier,
            kind,
            title: Array.isArray(r.title) ? r.title[0] : r.title || r.identifier,
            text: `${r.title || ""} ${subj} ${desc}`,
            thumb: `https://archive.org/services/img/${r.identifier}`,
            embed: `https://archive.org/embed/${r.identifier}`,
            resolve: { type: "archive", id: r.identifier, media: kind },
            page: `https://archive.org/details/${r.identifier}`,
            author: Array.isArray(r.creator) ? r.creator[0] : r.creator || "",
            license: fromText(r.licenseurl, r.licenseurl)
          };
        });
      }
      async function freesound(q, o) {
        const filters = [];
        if (o.license === "pd") filters.push('license:"Creative Commons 0"');
        else if (o.license === "commercial") filters.push('license:("Creative Commons 0" OR "Attribution")');
        if (o.duration === "curto") filters.push("duration:[0 TO 10]");
        if (o.duration === "medio") filters.push("duration:[10 TO 60]");
        if (o.duration === "longo") filters.push("duration:[60 TO *]");
        const p = {
          query: q,
          token: o.key("FREESOUND_KEY"),
          page: o.page,
          page_size: PER,
          fields: "id,name,tags,description,previews,license,username,duration,url,images",
          filter: filters.join(" ") || void 0
        };
        let d;
        try {
          d = await getJSON("https://freesound.org/apiv2/search/?" + qs(p));
        } catch (e) {
          if (e.status !== 404) throw e;
          d = await getJSON("https://freesound.org/apiv2/search/text/?" + qs(p));
        }
        return (d.results || []).map((r) => ({
          id: "fs:" + r.id,
          kind: "audio",
          title: r.name || "",
          text: `${r.name || ""} ${(r.tags || []).join(" ")} ${(r.description || "").slice(0, 200)}`,
          thumb: r.images?.waveform_m || "",
          waveform: r.images?.waveform_m || "",
          audio: r.previews?.["preview-hq-mp3"] || r.previews?.["preview-lq-mp3"],
          page: r.url,
          author: r.username || "",
          license: fromText(r.license, r.license),
          duration: r.duration
        }));
      }
      async function jamendo(q, o) {
        const d = await getJSON("https://api.jamendo.com/v3.0/tracks/?" + qs({
          client_id: o.key("JAMENDO_CLIENT_ID"),
          format: "json",
          limit: PER,
          offset: (o.page - 1) * PER,
          search: q,
          fuzzytags: o.mood || void 0,
          include: "musicinfo licenses",
          audioformat: "mp32",
          imagesize: 200,
          order: "relevance"
        }));
        return (d.results || []).map((r) => {
          const tags = r.musicinfo?.tags ? Object.values(r.musicinfo.tags).flat().join(" ") : "";
          return {
            id: "jm:" + r.id,
            kind: "audio",
            title: r.name || "",
            text: `${r.name || ""} ${r.artist_name || ""} ${tags}`,
            thumb: r.image || r.album_image || "",
            audio: r.audio,
            download: r.audiodownload_allowed ? r.audiodownload : void 0,
            page: r.shareurl,
            author: r.artist_name || "",
            license: fromText(r.license_ccurl, r.license_ccurl),
            duration: r.duration
          };
        });
      }
      var ytTokens = /* @__PURE__ */ new Map();
      async function youtube(q, o) {
        const p = {
          part: "snippet",
          type: "video",
          maxResults: PER,
          q,
          videoLicense: "creativeCommon",
          safeSearch: o.nsfw ? "strict" : "none",
          key: o.key("YOUTUBE_KEY")
        };
        if (o.page > 1) {
          const t = ytTokens.get(`${q}|${o.nsfw}|${o.page}`);
          if (!t) return [];
          p.pageToken = t;
        }
        const d = await getJSON("https://www.googleapis.com/youtube/v3/search?" + qs(p));
        if (d.nextPageToken) ytTokens.set(`${q}|${o.nsfw}|${o.page + 1}`, d.nextPageToken);
        return (d.items || []).filter((r) => r.id?.videoId).map((r) => {
          const sn = r.snippet || {};
          const th = sn.thumbnails || {};
          return {
            id: "yt:" + r.id.videoId,
            kind: "video",
            title: strip(sn.title),
            text: `${strip(sn.title)} ${sn.description || ""}`,
            thumb: (th.high || th.medium || th.default || {}).url,
            full: (th.high || th.medium || {}).url,
            external: `https://www.youtube.com/watch?v=${r.id.videoId}`,
            page: `https://www.youtube.com/watch?v=${r.id.videoId}`,
            author: sn.channelTitle || "",
            license: lic("ytcc", "https://support.google.com/youtube/answer/2797468"),
            w: 480,
            h: 360
          };
        });
      }
      function ytSecs(t) {
        const a = String(t || "").split(":").map(Number);
        return a.some(isNaN) ? void 0 : a.reduce((x, y) => x * 60 + y, 0);
      }
      async function youtubeWeb(q, o, audio) {
        if (o.page > 1) return [];
        const r = await fetch("https://www.youtube.com/results?" + qs({ search_query: audio ? q + " música" : q, hl: "pt-BR", gl: "BR" }), {
          credentials: "omit",
          signal: AbortSignal.timeout(TIMEOUT),
          headers: { "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.5" }
        });
        if (!r.ok) throw new Error("HTTP " + r.status);
        const html = await r.text();
        const m = /var ytInitialData\s*=\s*(\{.+?\});\s*<\/script>/s.exec(html);
        if (!m) throw new Error("YouTube mudou o formato da página");
        const out = [];
        const walk = (n) => {
          if (!n || typeof n !== "object" || out.length >= PER) return;
          if (n.videoRenderer && n.videoRenderer.videoId) {
            const v = n.videoRenderer, id = v.videoId, title = (v.title?.runs || []).map((x) => x.text).join("") || "";
            const th = v.thumbnail?.thumbnails || [], big = th[th.length - 1]?.url || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
            out.push({
              id: "ytw:" + id,
              kind: audio ? "audio" : "video",
              title: strip(title),
              text: strip(title),
              thumb: big,
              full: big,
              external: `https://www.youtube.com/watch?v=${id}`,
              page: `https://www.youtube.com/watch?v=${id}`,
              author: (v.ownerText?.runs || []).map((x) => x.text).join("") || "",
              duration: ytSecs(v.lengthText?.simpleText),
              license: lic("rights", "https://www.youtube.com/t/terms"),
              reference: true,
              w: 480,
              h: 270
            });
            return;
          }
          for (const k in n) walk(n[k]);
        };
        walk(JSON.parse(m[1]));
        return out;
      }
      var daToken = { value: "", until: 0, id: "" };
      async function deviantartToken(o) {
        const id = o.key("DEVIANTART_CLIENT_ID");
        if (daToken.value && daToken.id === id && Date.now() < daToken.until) return daToken.value;
        const d = await getJSON("https://www.deviantart.com/oauth2/token?" + qs({
          grant_type: "client_credentials",
          client_id: id,
          client_secret: o.key("DEVIANTART_CLIENT_SECRET")
        }));
        daToken = { value: d.access_token, until: Date.now() + ((d.expires_in || 3600) - 120) * 1e3, id };
        return daToken.value;
      }
      async function deviantart(tag, o) {
        const token = await deviantartToken(o);
        const d = await getJSON("https://www.deviantart.com/api/v1/oauth2/browse/tags?" + qs({
          tag: tag.toLowerCase().replace(/[^a-z0-9]/g, ""),
          limit: 24,
          offset: (o.page - 1) * 24,
          mature_content: o.nsfw ? "false" : "true",
          access_token: token
        }));
        return (d.results || []).filter((r) => r.content || r.preview).map((r) => {
          const thumb = (r.thumbs || []).slice().sort((a, b) => Math.abs(a.width - 400) - Math.abs(b.width - 400))[0];
          const big = r.content || r.preview;
          return {
            id: "da:" + r.deviationid,
            kind: "image",
            title: r.title || "",
            text: `${r.title || ""} ${tag} ${r.category || ""}`,
            thumb: (thumb || big).src,
            full: big.src,
            page: r.url,
            author: r.author?.username || "",
            license: lic("rights"),
            w: big.width,
            h: big.height,
            mature: !!r.is_mature
          };
        });
      }
      async function magnific(q, o) {
        const types = o.magnificTypes || ["vector", "psd"];
        let url = "https://api.magnific.com/v1/resources?" + qs({ term: q, page: o.page, limit: PER, order: "relevance" });
        for (const t of types) url += `&filters[content_type][${t}]=1`;
        if (ORIENT.magnific[o.orient]) url += `&filters[orientation][${ORIENT.magnific[o.orient]}]=1`;
        const d = await getJSON(url, { "x-magnific-api-key": o.key("MAGNIFIC_KEY"), "Accept-Language": "en-US" });
        return (d.data || []).map((r) => {
          const src = r.image?.source || {};
          const [w, h] = String(src.size || "").split("x").map(Number);
          const premium = (r.licenses || []).some((l) => l.type === "premium");
          return {
            id: "mg:" + r.id,
            kind: "image",
            title: r.title || "",
            text: `${r.title || ""} ${r.image?.type || ""}`,
            thumb: src.url,
            full: src.url,
            page: r.url,
            author: r.author?.name || "",
            license: lic(premium ? "magnific_premium" : "magnific_free", (r.licenses || [])[0]?.url),
            w: w || null,
            h: h || null
          };
        });
      }
      async function giphy(q, o) {
        const d = await getJSON("https://api.giphy.com/v1/gifs/search?" + qs({
          api_key: o.key("GIPHY_KEY"),
          q,
          limit: PER,
          offset: (o.page - 1) * PER,
          rating: o.nsfw ? "g" : "r",
          lang: "en"
        }));
        return (d.data || []).map((r) => {
          const fw = r.images?.fixed_width || {};
          const or = r.images?.original || {};
          return {
            id: "gf:" + r.id,
            kind: "gif",
            title: r.title || "",
            text: `${r.title || ""} ${r.slug || ""}`.replace(/-/g, " "),
            thumb: fw.webp || fw.url,
            full: or.webp || or.url,
            video: or.mp4,
            page: r.url,
            author: r.username || "",
            license: lic("giphy"),
            w: Number(fw.width),
            h: Number(fw.height),
            mature: r.rating && !["g", "pg"].includes(r.rating)
          };
        });
      }
      async function iconify(q, o) {
        const style = {
          linha: { prefixes: "tabler,lucide,iconoir,ph,mingcute,solar,hugeicons,carbon" },
          preenchido: { prefixes: "mdi,fa6-solid,bxs,ic,material-symbols,ri" },
          colorido: { palette: "true" },
          emoji: { prefixes: "fluent-emoji-flat,noto,twemoji,openmoji" }
        }[o.iconStyle] || {};
        if (o.iconSet) style.prefixes = o.iconSet;
        const d = await getJSON("https://api.iconify.design/search?" + qs({ query: q, limit: 64, start: (o.page - 1) * 64, ...style }));
        const cols = d.collections || {};
        return (d.icons || []).map((full) => {
          const [prefix, name] = full.split(":");
          const col = cols[prefix] || {};
          const lt = col.license?.title || "";
          return {
            id: "ic:" + full,
            kind: "icon",
            title: `${name.replace(/-/g, " ")} · ${col.name || prefix}`,
            text: `${name.replace(/-/g, " ")} ${col.name || ""} ${col.category || ""}`,
            thumb: `https://api.iconify.design/${prefix}/${name}.svg?height=96${o.iconColor ? "&color=" + encodeURIComponent(o.iconColor) : ""}`,
            full: `https://api.iconify.design/${prefix}/${name}.svg?height=512${o.iconColor ? "&color=" + encodeURIComponent(o.iconColor) : ""}`,
            page: `https://icon-sets.iconify.design/${prefix}/?icon-filter=${encodeURIComponent(name)}`,
            author: col.author?.name || "",
            license: /cc by/i.test(lt) ? fromText(lt, col.license?.url) : { ...lic("iconify", col.license?.url), label: lt || "Licença aberta" },
            w: 1,
            h: 1
          };
        });
      }
      async function vam(q, o) {
        const d = await getJSON("https://api.vam.ac.uk/v2/objects/search?" + qs({ q, images_exist: 1, page: o.page, page_size: PER }));
        return (d.records || []).filter((r) => r._images?._iiif_image_base_url).map((r) => ({
          id: "va:" + r.systemNumber,
          kind: "image",
          title: r._primaryTitle || r.objectType || "",
          text: `${r._primaryTitle || ""} ${r.objectType || ""} ${r._primaryMaker?.name || ""}`,
          thumb: r._images._iiif_image_base_url + "full/!400,400/0/default.jpg",
          full: r._images._iiif_image_base_url + "full/!1600,1600/0/default.jpg",
          page: `https://collections.vam.ac.uk/item/${r.systemNumber}/`,
          author: [r._primaryMaker?.name, r._primaryDate].filter(Boolean).join(", "),
          license: lic("rights")
        }));
      }
      async function aic(q, o) {
        const d = await getJSON("https://api.artic.edu/api/v1/artworks/search?" + qs({
          q,
          limit: PER,
          page: o.page,
          fields: "id,title,image_id,artist_title,is_public_domain,thumbnail,classification_title,style_title,term_titles"
        }), { "AIC-User-Agent": UA });
        return (d.data || []).filter((r) => r.image_id).map((r) => ({
          id: "aic:" + r.id,
          kind: "image",
          title: r.title || "",
          text: `${r.title || ""} ${r.classification_title || ""} ${r.style_title || ""} ${(r.term_titles || []).join(" ")}`,
          thumb: `https://www.artic.edu/iiif/2/${r.image_id}/full/400,/0/default.jpg`,
          full: `https://www.artic.edu/iiif/2/${r.image_id}/full/1686,/0/default.jpg`,
          page: `https://www.artic.edu/artworks/${r.id}`,
          author: r.artist_title || "",
          license: r.is_public_domain ? lic("cc0", "https://www.artic.edu/open-access/open-access-images") : lic("rights"),
          w: r.thumbnail?.width,
          h: r.thumbnail?.height
        }));
      }
      async function cleveland(q, o) {
        const d = await getJSON("https://openaccess-api.clevelandart.org/api/artworks/?" + qs({ q, has_image: 1, limit: PER, skip: (o.page - 1) * PER }));
        return (d.data || []).filter((r) => r.images?.web?.url).map((r) => ({
          id: "cma:" + r.id,
          kind: "image",
          title: r.title || "",
          text: `${r.title || ""} ${r.type || ""} ${r.technique || ""}`,
          thumb: r.images.web.url,
          full: (r.images.print || r.images.web).url,
          page: r.url,
          author: (r.creators || [])[0]?.description || "",
          license: r.share_license_status === "CC0" ? lic("cc0", "https://www.clevelandart.org/open-access") : lic("rights"),
          w: Number(r.images.web.width),
          h: Number(r.images.web.height)
        }));
      }
      async function met(q, o) {
        const s = await getJSON("https://collectionapi.metmuseum.org/public/collection/v1.1/search?" + qs({ q, hasImages: "true", limit: 12, offset: (o.page - 1) * 12 }));
        const ids = (s.objectIDs || []).slice(0, 12);
        const objs = await Promise.all(ids.map((id) => getJSON(`https://collectionapi.metmuseum.org/public/collection/v1/objects/${id}`).catch(() => null)));
        return objs.filter((r) => r && r.primaryImageSmall).map((r) => ({
          id: "met:" + r.objectID,
          kind: "image",
          title: r.title || "",
          text: `${r.title || ""} ${r.objectName || ""} ${r.classification || ""} ${(r.tags || []).map((t) => t.term).join(" ")}`,
          thumb: r.primaryImageSmall,
          full: r.primaryImage || r.primaryImageSmall,
          page: r.objectURL,
          author: r.artistDisplayName || "",
          license: r.isPublicDomain ? lic("cc0", "https://www.metmuseum.org/hubs/open-access") : lic("rights")
        }));
      }
      async function ccmixter(q, o) {
        const p = { f: "json", search: q, limit: PER, offset: (o.page - 1) * PER, tags: o.mood || void 0 };
        if (o.license === "pd") p.lic = "cc0";
        else if (o.license === "commercial") p.lic = "by";
        const d = await getJSONBigHeaders("https://ccmixter.org/api/query?" + qs(p));
        return (Array.isArray(d) ? d : []).map((r) => {
          const files = r.files || [];
          const mp3 = files.find((f) => /mp3/i.test(f.file_format_info?.["default-ext"] || f.file_name || "")) || files[0] || {};
          return {
            id: "ccm:" + r.upload_id,
            kind: "audio",
            title: r.upload_name || "",
            text: `${r.upload_name || ""} ${(r.upload_extra?.usertags || "").replace(/[,_]/g, " ")}`,
            thumb: "",
            audio: mp3.download_url,
            page: r.file_page_url || `https://ccmixter.org/files/${r.user_name}/${r.upload_id}`,
            author: r.user_real_name || r.user_name || "",
            license: fromText(r.license_name || r.license_url, r.license_url),
            duration: mp3.file_format_info?.ps ? parseDur(mp3.file_format_info.ps) : null,
            mature: !!r.upload_extra?.nsfw
          };
        }).filter((i) => i.audio);
      }
      var parseDur = (s) => {
        const p = String(s).split(":").map(Number);
        return p.length === 2 ? p[0] * 60 + p[1] : p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : null;
      };
      var vmToken = { value: "", id: "" };
      async function vimeo(q, o) {
        const id = o.key("VIMEO_CLIENT_ID"), secret = o.key("VIMEO_CLIENT_SECRET");
        if (vmToken.id !== id || !vmToken.value) {
          const r = await fetch("https://api.vimeo.com/oauth/authorize/client", {
            method: "POST",
            signal: AbortSignal.timeout(TIMEOUT),
            headers: {
              "User-Agent": UA,
              Authorization: "Basic " + btoa(`${id}:${secret}`),
              "Content-Type": "application/json",
              Accept: "application/vnd.vimeo.*+json;version=3.4"
            },
            body: JSON.stringify({ grant_type: "client_credentials", scope: "public" })
          });
          if (!r.ok) {
            const e = new Error(`HTTP ${r.status}`);
            e.status = r.status;
            throw e;
          }
          vmToken = { value: (await r.json()).access_token, id };
        }
        const filter = o.license === "pd" ? "cc0" : o.license === "commercial" ? "cc-by" : "CC";
        const d = await getJSON("https://api.vimeo.com/videos?" + qs({
          query: q,
          filter,
          per_page: PER,
          page: o.page,
          fields: "uri,name,description,link,duration,width,height,pictures.sizes,license,user.name,tags.name,content_rating"
        }), { Authorization: "Bearer " + vmToken.value, Accept: "application/vnd.vimeo.*+json;version=3.4" });
        return (d.data || []).map((r) => {
          const sizes = r.pictures?.sizes || [];
          const pic = sizes.find((x) => x.width >= 640) || sizes[sizes.length - 1] || {};
          const unsafe = (r.content_rating || []).some((c) => !["safe", "unrated"].includes(c));
          return {
            id: "vm:" + r.uri,
            kind: "video",
            title: r.name || "",
            text: `${r.name || ""} ${(r.tags || []).map((t) => t.name).join(" ")} ${(r.description || "").slice(0, 200)}`,
            thumb: pic.link,
            full: pic.link,
            external: r.link,
            page: r.link,
            author: r.user?.name || "",
            license: fromText(`cc ${r.license || ""}`),
            w: r.width,
            h: r.height,
            duration: r.duration,
            mature: unsafe
          };
        });
      }
      async function coverr(q, o) {
        const d = await getJSON("https://api.coverr.co/videos?" + qs({ query: q, page: o.page - 1, page_size: PER, urls: "true", api_key: o.key("COVERR_KEY") }));
        const hits = d.hits || d.videos || d.data || [];
        return hits.map((r) => {
          const u = r.urls || {};
          return {
            id: "cv:" + (r.id || r.slug),
            kind: "video",
            title: r.title || "",
            text: `${r.title || ""} ${(r.tags || []).join(" ")} ${r.description || ""}`,
            thumb: r.thumbnail || r.poster,
            full: r.poster || r.thumbnail,
            video: u.mp4_preview || u.mp4 || u.mp4_download,
            download: u.mp4_download || u.mp4,
            page: r.slug ? `https://coverr.co/videos/${r.slug}` : "https://coverr.co",
            author: "Coverr",
            license: lic("coverr", "https://coverr.co/license"),
            w: r.max_width,
            h: r.max_height,
            duration: r.duration
          };
        }).filter((i) => i.thumb);
      }
      async function sketchfab(q, o) {
        const p = { type: "models", q, count: 24, cursor: (o.page - 1) * 24 || void 0 };
        if (o.license === "pd") p.license = "cc0";
        if (o.downloadable !== false) p.downloadable = "true";
        const d = await getJSON("https://api.sketchfab.com/v3/search?" + qs(p));
        return (d.results || []).map((r) => {
          const imgs = (r.thumbnails?.images || []).slice().sort((a, b) => a.width - b.width);
          const th = imgs.find((i) => i.width >= 640) || imgs[imgs.length - 1] || {};
          const big = imgs[imgs.length - 1] || th;
          return {
            id: "sf:" + r.uid,
            kind: "model",
            title: r.name || "",
            text: `${r.name || ""} ${(r.tags || []).map((t) => t.name).join(" ")} ${(r.categories || []).map((c) => c.name).join(" ")}`,
            thumb: th.url,
            full: big.url,
            external: r.embedUrl ? r.embedUrl + "?autostart=1" : r.viewerUrl,
            page: r.viewerUrl,
            author: r.user?.displayName || "",
            license: fromText(r.license?.label || "", ""),
            w: big.width,
            h: big.height,
            mature: !!r.isAgeRestricted,
            meta: r.isDownloadable ? "Download grátis" : ""
          };
        });
      }
      var phCache = {};
      async function polyhaven(q, o, t) {
        if (!phCache[t] || Date.now() - phCache[t].at > 36e5) phCache[t] = { at: Date.now(), v: await getJSON(`https://api.polyhaven.com/assets?t=${t}`) };
        const words = norm(q).trim().split(" ").filter((w) => w.length > 2);
        const all = Object.entries(phCache[t].v).map(([id, a]) => {
          const hay = norm(`${a.name} ${(a.tags || []).join(" ")} ${(a.categories || []).join(" ")} ${a.category || ""}`);
          return { id, a, hit: words.filter((w) => hay.includes(" " + w) || hay.includes(w + " ")).length };
        }).filter((x) => !words.length || x.hit).sort((x, y) => y.hit - x.hit || (y.a.download_count || 0) - (x.a.download_count || 0));
        return all.slice((o.page - 1) * PER, o.page * PER).map(({ id, a }) => ({
          id: "ph:" + id,
          kind: "image",
          title: a.name,
          text: `${a.name} ${(a.tags || []).join(" ")} ${(a.categories || []).join(" ")}`,
          thumb: (a.thumbnail_url || "").replace("width=256&height=256", "width=512&height=512"),
          full: (a.thumbnail_url || "").replace("width=256&height=256", "width=1024&height=1024"),
          page: `https://polyhaven.com/a/${id}`,
          author: Object.keys(a.authors || {}).join(", "),
          license: lic("cc0", "https://polyhaven.com/license"),
          w: 1,
          h: t === "hdris" ? 0.5 : 1,
          origW: (a.max_resolution || [])[0],
          origH: (a.max_resolution || [])[1],
          meta: { hdris: "HDRI", textures: "Textura", models: "Modelo 3D" }[t]
        }));
      }
      async function ambientcg(q, o) {
        const d = await getJSON("https://ambientcg.com/api/v2/full_json?" + qs({ q, limit: PER, offset: (o.page - 1) * PER, include: "imageData,displayData,tagData" }));
        return (d.foundAssets || []).map((a) => ({
          id: "acg:" + a.assetId,
          kind: "image",
          title: a.displayName || a.assetId,
          text: `${a.displayName || ""} ${(a.tags || []).join(" ")} ${a.displayCategory || ""}`,
          thumb: a.previewImage?.["512-PNG"] || a.previewImage?.["256-PNG"],
          full: a.previewImage?.["1024-PNG"] || a.previewImage?.["512-PNG"],
          page: a.shortLink || `https://ambientcg.com/view?id=${a.assetId}`,
          author: "ambientCG",
          license: lic("cc0", "https://docs.ambientcg.com/license/"),
          w: 1,
          h: 1,
          meta: a.dataTypeName || a.dataType
        })).filter((i) => i.thumb);
      }
      async function wellcome(q, o) {
        const d = await getJSON("https://api.wellcomecollection.org/catalogue/v2/images?" + qs({ query: q, pageSize: PER, page: o.page }));
        return (d.results || []).map((r) => {
          const base = (r.thumbnail?.url || "").replace(/info\.json$/, "");
          const l = r.thumbnail?.license || r.locations?.[0]?.license || {};
          return {
            id: "wc:" + r.id,
            kind: "image",
            title: r.source?.title || "",
            text: `${r.source?.title || ""}`,
            thumb: base + "full/!400,400/0/default.jpg",
            full: base + "full/!1600,1600/0/default.jpg",
            page: `https://wellcomecollection.org/works/${r.source?.id}/images?id=${r.id}`,
            author: "Wellcome Collection",
            license: l.id === "pdm" ? lic("pdm", l.url) : fromText(l.label || l.id || "", l.url),
            w: r.aspectRatio ? 1e3 * r.aspectRatio : null,
            h: r.aspectRatio ? 1e3 : null
          };
        }).filter((i) => i.thumb.startsWith("https"));
      }
      async function smk(q, o) {
        const d = await getJSON("https://api.smk.dk/api/v1/art/search/?" + qs({ keys: q, offset: (o.page - 1) * PER, rows: PER, lang: "en" }) + "&filters=%5Bhas_image:true%5D");
        return (d.items || []).filter((r) => r.image_thumbnail).map((r) => {
          const t = (r.titles || []).find((x) => /engelsk|english/i.test(x.language || "")) || (r.titles || [])[0] || {};
          return {
            id: "smk:" + r.object_number,
            kind: "image",
            title: t.title || "",
            text: `${(r.titles || []).map((x) => x.title).join(" ")} ${(r.object_names || []).map((x) => x.name).join(" ")} ${(r.techniques || []).join(" ")}`,
            thumb: r.image_thumbnail.replace("!1024,", "!480,"),
            full: r.image_thumbnail,
            download: r.image_native,
            page: r.frontend_url,
            author: r.production?.[0]?.creator || "",
            license: r.public_domain ? lic("pdm", r.rights) : lic("rights"),
            w: r.image_width,
            h: r.image_height
          };
        });
      }
      var SOURCES = [
        // ---- Fontes que servem vários tipos ----
        {
          id: "magnific",
          name: "Freepik / Magnific",
          types: ["design", "mockup", "ilustracao", "3d", "foto"],
          keys: ["MAGNIFIC_KEY"],
          maxVariants: 1,
          run: (q, o) => magnific(q, { ...o, magnificTypes: { design: ["psd", "vector"], mockup: ["psd"], ilustracao: ["vector"], foto: ["photo"], "3d": ["psd", "vector"] }[o.type] })
        },
        {
          id: "pixabay_art",
          name: "Pixabay",
          types: ["design", "ilustracao", "3d", "foto", "mockup"],
          keys: ["PIXABAY_KEY"],
          maxVariants: 2,
          run: (q, o) => pixabayImages(q, o, { design: "vector", ilustracao: "illustration", "3d": "illustration", foto: "photo", mockup: "photo" }[o.type])
        },
        { id: "pexels", name: "Pexels", types: ["foto", "mockup"], keys: ["PEXELS_KEY"], maxVariants: 2, run: pexelsPhotos },
        { id: "unsplash", name: "Unsplash", types: ["foto", "mockup", "3d"], keys: ["UNSPLASH_KEY"], maxVariants: 1, run: unsplash },
        {
          id: "openverse",
          name: "Openverse",
          types: ["foto", "ilustracao", "design", "mockup", "3d", "arte", "gif"],
          keys: [],
          maxVariants: 2,
          shortFirst: true,
          run: (q, o) => openverseImages(
            q,
            { ...o, extension: o.type === "gif" ? "gif" : void 0 },
            { foto: "photograph", mockup: "photograph", ilustracao: "illustration", design: "illustration,digitized_artwork", "3d": "illustration", arte: "digitized_artwork", gif: void 0 }[o.type]
          )
        },
        {
          id: "wikimedia",
          name: "Wikimedia Commons",
          types: ["foto", "mockup", "gif"],
          keys: [],
          maxVariants: 1,
          pt: true,
          run: (q, o) => wikimedia(q, o, o.type === "gif" ? "gif" : "image")
        },
        { id: "wellcome", name: "Wellcome Collection", types: ["design", "ilustracao", "arte"], keys: [], maxVariants: 1, kinds: ["core", "related"], run: wellcome },
        { id: "smk", name: "SMK (Dinamarca)", types: ["ilustracao", "arte"], keys: [], maxVariants: 1, kinds: ["core", "related"], run: smk },
        {
          id: "deviantart",
          name: "DeviantArt",
          types: ["ilustracao", "3d"],
          keys: ["DEVIANTART_CLIENT_ID", "DEVIANTART_CLIENT_SECRET"],
          maxVariants: 3,
          tagMode: true,
          run: (q, o) => deviantart(q, o)
        },
        // ---- 3D (native = já é 3D, não precisa acrescentar "3d" na busca) ----
        {
          id: "sketchfab",
          name: "Sketchfab",
          types: ["3d"],
          keys: [],
          maxVariants: 2,
          native: true,
          run: (q, o) => !o.kind3d || o.kind3d === "modelos" ? sketchfab(q, o) : []
        },
        {
          id: "polyhaven",
          name: "Poly Haven",
          types: ["3d"],
          keys: [],
          maxVariants: 1,
          native: true,
          kinds: ["core"],
          run: async (q, o) => {
            const t = { modelos: ["models"], texturas: ["textures"], hdri: ["hdris"] }[o.kind3d] || (o.kind3d === "renders" ? [] : ["models", "textures", "hdris"]);
            return (await Promise.all(t.map((x) => polyhaven(q, o, x)))).flat();
          }
        },
        {
          id: "ambientcg",
          name: "ambientCG",
          types: ["3d"],
          keys: [],
          maxVariants: 1,
          native: true,
          kinds: ["core"],
          run: (q, o) => !o.kind3d || o.kind3d === "texturas" ? ambientcg(q, o) : []
        },
        {
          id: "wikimedia_3d",
          name: "Wikimedia (modelos STL)",
          types: ["3d"],
          keys: [],
          maxVariants: 1,
          native: true,
          kinds: ["core"],
          run: (q, o) => !o.kind3d || o.kind3d === "modelos" ? wikimedia(q, o, "model") : []
        },
        // ---- Fotos ----
        { id: "nasa_photo", name: "NASA", types: ["foto"], keys: [], maxVariants: 1, run: (q, o) => nasa(q, o, "image") },
        // ---- Vídeos ----
        { id: "pexels_video", name: "Pexels", types: ["video"], keys: ["PEXELS_KEY"], maxVariants: 2, run: pexelsVideos },
        { id: "pixabay_video", name: "Pixabay", types: ["video"], keys: ["PIXABAY_KEY"], maxVariants: 2, run: pixabayVideos },
        { id: "wikimedia_video", name: "Wikimedia Commons", types: ["video"], keys: [], maxVariants: 1, pt: true, run: (q, o) => wikimedia(q, o, "video") },
        { id: "nasa_video", name: "NASA", types: ["video"], keys: [], maxVariants: 1, run: (q, o) => nasa(q, o, "video") },
        { id: "archive_video", name: "Internet Archive", types: ["video"], keys: [], maxVariants: 1, run: (q, o) => archive(q, o, "movies") },
        { id: "youtube", name: "YouTube (Creative Commons)", types: ["video"], keys: ["YOUTUBE_KEY"], maxVariants: 1, run: youtube },
        { id: "youtube_web", name: "YouTube", types: ["video"], keys: [], maxVariants: 1, run: (q, o) => youtubeWeb(q, o, false) },
        { id: "youtube_music", name: "YouTube", types: ["musica"], keys: [], maxVariants: 1, run: (q, o) => youtubeWeb(q, o, true) },
        { id: "vimeo", name: "Vimeo (Creative Commons)", types: ["video"], keys: ["VIMEO_CLIENT_ID", "VIMEO_CLIENT_SECRET"], maxVariants: 1, run: vimeo },
        { id: "coverr", name: "Coverr", types: ["video"], keys: ["COVERR_KEY"], maxVariants: 1, run: coverr },
        // ---- Músicas ----
        { id: "jamendo", name: "Jamendo", types: ["musica"], keys: ["JAMENDO_CLIENT_ID"], maxVariants: 2, run: jamendo },
        { id: "openverse_music", name: "Openverse", types: ["musica"], keys: [], maxVariants: 1, run: (q, o) => openverseAudio(q, o, "music") },
        { id: "archive_audio", name: "Internet Archive", types: ["musica"], keys: [], maxVariants: 1, run: (q, o) => archive(q, o, "audio", "music") },
        { id: "ccmixter", name: "ccMixter", types: ["musica"], keys: [], maxVariants: 2, run: ccmixter },
        { id: "wikimedia_music", name: "Wikimedia Commons", types: ["musica"], keys: [], maxVariants: 1, run: (q, o) => wikimedia(q + " music", o, "audio") },
        // ---- Efeitos sonoros ----
        { id: "freesound", name: "Freesound", types: ["sfx"], keys: ["FREESOUND_KEY"], maxVariants: 2, run: freesound },
        { id: "openverse_sfx", name: "Openverse (Freesound)", types: ["sfx"], keys: [], maxVariants: 1, run: (q, o) => openverseAudio(q, o, "sfx") },
        {
          id: "wikimedia_sfx",
          name: "Wikimedia Commons",
          types: ["sfx"],
          keys: [],
          maxVariants: 1,
          run: async (q, o) => (await wikimedia(q + " sound", o, "audio")).filter((i) => !i.duration || i.duration <= 120)
        },
        { id: "archive_sfx", name: "Internet Archive", types: ["sfx"], keys: [], maxVariants: 1, run: (q, o) => archive(q, o, "audio", "sfx") },
        // ---- Ícones e GIFs ----
        { id: "iconify", name: "Iconify", types: ["icone"], keys: [], maxVariants: 2, run: iconify },
        { id: "giphy", name: "GIPHY", types: ["gif"], keys: ["GIPHY_KEY"], maxVariants: 2, run: giphy },
        // ---- Arte e museus (consulta curta: exigem todas as palavras) ----
        { id: "aic", name: "Art Institute of Chicago", types: ["arte"], kinds: ["core", "related"], keys: [], maxVariants: 2, run: aic },
        { id: "met", name: "The Met", types: ["arte"], kinds: ["core", "related"], keys: [], maxVariants: 1, run: met },
        { id: "cleveland", name: "Cleveland Museum of Art", types: ["arte"], kinds: ["core", "related"], keys: [], maxVariants: 2, run: cleveland },
        { id: "vam", name: "V&A Museum", types: ["arte", "design"], kinds: ["core", "related"], keys: [], maxVariants: 2, run: vam }
      ];
      var KEYS = [
        { key: "PEXELS_KEY", name: "Pexels", help: "https://www.pexels.com/api/", note: "Fotos e vídeos. Grátis, sai na hora." },
        { key: "PIXABAY_KEY", name: "Pixabay", help: "https://pixabay.com/api/docs/", note: "Fotos, vetores, ilustrações e vídeos. Grátis." },
        { key: "FREESOUND_KEY", name: "Freesound", help: "https://freesound.org/apiv2/apply/", note: "Efeitos sonoros. Grátis (60 buscas/min)." },
        { key: "JAMENDO_CLIENT_ID", name: "Jamendo", help: "https://devportal.jamendo.com/", note: "Músicas Creative Commons. Grátis." },
        { key: "UNSPLASH_KEY", name: "Unsplash", help: "https://unsplash.com/oauth/applications", note: "Fotos. Grátis (50 buscas/hora no modo demo)." },
        { key: "YOUTUBE_KEY", name: "YouTube", help: "https://console.cloud.google.com/apis/library/youtube.googleapis.com", note: "Só vídeos Creative Commons. Grátis (~100 buscas/dia)." },
        { key: "GIPHY_KEY", name: "GIPHY", help: "https://developers.giphy.com/dashboard/", note: "GIFs para inspiração. Chave beta grátis (100 buscas/hora)." },
        { key: "DEVIANTART_CLIENT_ID", name: "DeviantArt (client_id)", help: "https://www.deviantart.com/developers/", note: "Ilustração e desenho. Grátis." },
        { key: "DEVIANTART_CLIENT_SECRET", name: "DeviantArt (client_secret)", help: "https://www.deviantart.com/developers/", note: "Vem junto com o client_id." },
        { key: "MAGNIFIC_KEY", name: "Freepik / Magnific", help: "https://www.magnific.com/api", note: "Templates PSD e vetores de social media. Chave em 1 clique; uso por créditos." },
        { key: "VIMEO_CLIENT_ID", name: "Vimeo (client_id)", help: "https://developer.vimeo.com/apps/new", note: "Vídeos Creative Commons. App grátis." },
        { key: "VIMEO_CLIENT_SECRET", name: "Vimeo (client_secret)", help: "https://developer.vimeo.com/apps", note: "Vem junto com o client_id." },
        { key: "COVERR_KEY", name: "Coverr", help: "https://coverr.co/developers", note: "Vídeos livres. Chave grátis em modo demo (50 buscas/hora)." },
        { key: "OPENVERSE_CLIENT_ID", name: "Openverse (client_id)", help: "https://api.openverse.org/v1/#tag/auth", note: "Opcional. Sem chave: 200 buscas/dia. Registro grátis." },
        { key: "OPENVERSE_CLIENT_SECRET", name: "Openverse (client_secret)", help: "https://api.openverse.org/v1/#tag/auth", note: "Vem junto com o client_id." }
      ];
      async function resolveMedia(r) {
        if (r.type === "nasa") {
          const files = await getJSON(r.href);
          const list = (Array.isArray(files) ? files : []).map((u) => u.replace(/^http:/, "https:"));
          const prefs = r.media === "video" ? ["~mobile.mp4", "~medium.mp4", "~small.mp4", "~orig.mp4", ".mp4"] : ["~128k.mp3", ".mp3", ".m4a", ".wav"];
          for (const p of prefs) {
            const f = list.find((u) => u.endsWith(p));
            if (f) return { [r.media === "video" ? "video" : "audio"]: f };
          }
          return {};
        }
        if (r.type === "archive") {
          const d = await getJSON(`https://archive.org/metadata/${encodeURIComponent(r.id)}`);
          const files = d.files || [];
          const pick = r.media === "audio" ? files.find((f) => /mp3/i.test(f.format || "")) || files.find((f) => /\.(mp3|ogg)$/i.test(f.name)) : files.find((f) => /h\.264|mpeg4/i.test(f.format || "")) || files.find((f) => /\.mp4$/i.test(f.name));
          if (!pick) return {};
          const url = `https://archive.org/download/${encodeURIComponent(r.id)}/${pick.name.split("/").map(encodeURIComponent).join("/")}`;
          return { [r.media]: url };
        }
        return {};
      }
      module.exports = { SOURCES, KEYS, resolveMedia, getJSON };
    }
  });

  // engine/types.js
  var require_types = __commonJS({
    "engine/types.js"(exports, module) {
      var opt = (v, l, fx) => [v, l, fx];
      var LICENSE = {
        id: "licenca",
        label: "Licença",
        default: "commercial",
        galleryOnly: true,
        options: [
          opt("commercial", "Uso comercial (pode editar)"),
          opt("pd", "Domínio público / sem crédito"),
          opt("any", "Qualquer licença aberta")
        ]
      };
      var ORIENT = {
        id: "orient",
        label: "Formato",
        options: [
          opt("", "Qualquer"),
          opt("horizontal", "Horizontal", { orient: "horizontal" }),
          opt("vertical", "Vertical", { orient: "vertical" }),
          opt("quadrado", "Quadrado", { orient: "quadrado" })
        ]
      };
      var RES = {
        id: "res",
        label: "Resolução",
        galleryOnly: true,
        options: [
          opt("", "Qualquer"),
          opt("baixa", "Baixa", { set: { res: "baixa" } }),
          opt("media", "Média", { set: { res: "media" } }),
          opt("alta", "Alta", { set: { res: "alta" } })
        ]
      };
      var AUDIO_DUR = {
        id: "duracao",
        label: "Duração",
        galleryOnly: true,
        options: [
          opt("", "Qualquer"),
          opt("curto", "Até 10 s", { set: { duration: "curto" } }),
          opt("medio", "10 s a 1 min", { set: { duration: "medio" } }),
          opt("longo", "Mais de 1 min", { set: { duration: "longo" } })
        ]
      };
      var t = (en, pt, orient) => ({ terms: [en], pt: [pt], ...orient ? { orient } : {} });
      var opts = (list) => [opt("", "Qualquer"), ...list.map(([v, l, en, pt, o]) => opt(v, l, t(en, pt, o)))];
      var COR_TERMO = { id: "cor_t", label: "Cor", options: opts([
        ["azul", "Azul", "blue", "azul"],
        ["laranja", "Laranja", "orange", "laranja"],
        ["verde", "Verde", "green", "verde"],
        ["amarelo", "Amarelo", "yellow", "amarelo"],
        ["vermelho", "Vermelho", "red", "vermelho"],
        ["roxo", "Roxo", "purple", "roxo"],
        ["rosa", "Rosa", "pink", "rosa"],
        ["preto", "Preto / escuro", "black dark", "preto"],
        ["branco", "Branco / claro", "white clean", "branco"],
        ["pastel", "Tons pastel", "pastel", "pastel"],
        ["neon", "Neon / vibrante", "neon vibrant", "neon"],
        ["pb", "Preto e branco", "black and white", "preto e branco"]
      ]) };
      var SEGMENTO = { id: "segmento", label: "Segmento", options: opts([
        ["energia", "Energia / sustentabilidade", "renewable energy", "energia renovável"],
        ["solar", "Energia solar", "solar energy", "energia solar"],
        ["tecnologia", "Tecnologia", "technology", "tecnologia"],
        ["financeiro", "Financeiro", "finance", "financeiro"],
        ["saude", "Saúde", "health", "saúde"],
        ["educacao", "Educação", "education", "educação"],
        ["varejo", "Varejo / moda", "retail fashion", "moda"],
        ["gastronomia", "Gastronomia", "food", "gastronomia"],
        ["imobiliario", "Imobiliário", "real estate", "imobiliária"],
        ["automotivo", "Automotivo", "automotive", "automotivo"],
        ["beleza", "Beleza", "beauty", "beleza"],
        ["esporte", "Esporte / fitness", "fitness", "fitness"],
        ["corporativo", "Corporativo / B2B", "corporate", "corporativo"]
      ]) };
      var TYPES = {
        design: {
          label: "Design",
          icon: "◧",
          kind: "visual",
          defaultView: "pinterest",
          modifier: { terms: ["graphic design"], pt: ["design gráfico"] },
          filters: [
            { id: "uso", label: "Uso", core: true, options: [
              opt("", "Todos"),
              opt("social", "Social media", t("social media", "social media")),
              opt("impresso", "Impresso", t("print design", "impresso")),
              opt("digital", "Digital / web", t("web design", "web design")),
              opt("apresentacao", "Apresentação", t("presentation design", "apresentação")),
              opt("branding", "Branding", t("branding", "identidade visual")),
              opt("embalagem", "Embalagem", t("packaging design", "embalagem"))
            ] },
            { id: "peca", label: "Peça", core: true, options: [
              opt("", "Qualquer"),
              opt("feed", "Social · post feed", t("instagram post", "post instagram", "quadrado")),
              opt("stories", "Social · stories / reels", t("instagram story", "stories instagram", "vertical")),
              opt("carrossel", "Social · carrossel", t("instagram carousel", "carrossel instagram")),
              opt("thumb", "Social · thumbnail YouTube", t("youtube thumbnail", "thumbnail youtube", "horizontal")),
              opt("capa", "Social · capa / banner de perfil", t("social media cover", "capa redes sociais", "horizontal")),
              opt("cartaz", "Impresso · cartaz", t("poster", "cartaz", "vertical")),
              opt("flyer", "Impresso · flyer / panfleto", t("flyer", "panfleto")),
              opt("folder", "Impresso · folder", t("brochure", "folder")),
              opt("cartao", "Impresso · cartão de visita", t("business card", "cartão de visita")),
              opt("convite", "Impresso · convite", t("invitation", "convite")),
              opt("cardapio", "Impresso · cardápio", t("menu design", "cardápio")),
              opt("outdoor", "Impresso · outdoor / lona", t("billboard", "outdoor", "horizontal")),
              opt("banner", "Digital · banner web", t("web banner", "banner", "horizontal")),
              opt("email", "Digital · e-mail marketing", t("email marketing", "email marketing")),
              opt("landing", "Digital · landing page", t("landing page", "landing page")),
              opt("anuncio", "Digital · anúncio", t("ad creative", "anúncio")),
              opt("logo", "Logo", t("logo design", "logo")),
              opt("slide", "Apresentação · slide", t("presentation slide", "slide apresentação", "horizontal")),
              opt("infografico", "Infográfico", t("infographic", "infográfico")),
              opt("rotulo", "Rótulo / embalagem", t("label design", "rótulo"))
            ] },
            { id: "estilo", label: "Estilo", options: [
              opt("", "Qualquer"),
              opt("minimalista", "Minimalista", t("minimalist", "minimalista")),
              opt("moderno", "Moderno", t("modern", "moderno")),
              opt("corporativo", "Corporativo", t("corporate", "corporativo")),
              opt("colorido", "Colorido", t("colorful", "colorido")),
              opt("flat", "Flat", t("flat", "flat")),
              opt("3d", "3D", t("3d", "3d")),
              opt("tipografico", "Tipográfico", t("typography", "tipografia")),
              opt("foto", "Com foto", t("photo", "foto")),
              opt("retro", "Retrô", t("retro", "retrô")),
              opt("premium", "Premium / elegante", t("luxury elegant", "elegante")),
              opt("divertido", "Divertido", t("playful fun", "divertido")),
              opt("gradiente", "Gradiente", t("gradient", "gradiente")),
              opt("brutalista", "Brutalista / bold", t("bold brutalist", "bold"))
            ] },
            SEGMENTO,
            COR_TERMO,
            { id: "elementos", label: "Elementos", options: opts([
              ["pessoas", "Com pessoas", "people", "pessoas"],
              ["produto", "Foto de produto", "product", "produto"],
              ["icones", "Com ícones", "icons", "ícones"],
              ["ilustra", "Com ilustração", "illustration", "ilustração"],
              ["texto", "Só tipografia", "typography only", "tipografia"],
              ["grafico", "Com gráficos / dados", "data chart", "gráfico"]
            ]) },
            RES
          ],
          platforms: ["pinterest", "behance", "instagram", "dribbble", "freepik", "canva", "google", "bing", "yandex"]
        },
        social: {
          label: "Social media",
          icon: "",
          kind: "visual",
          defaultView: "pinterest",
          modifier: { terms: ["social media post"], pt: ["post redes sociais"] },
          filters: [
            { id: "rede", label: "Rede", options: opts([
              ["instagram", "Instagram", "instagram", "instagram"],
              ["facebook", "Facebook", "facebook post", "facebook"],
              ["linkedin", "LinkedIn", "linkedin post", "linkedin"],
              ["tiktok", "TikTok", "tiktok", "tiktok"],
              ["youtube", "YouTube", "youtube", "youtube"],
              ["x", "X / Twitter", "twitter post", "twitter"],
              ["whatsapp", "WhatsApp", "whatsapp", "whatsapp"]
            ]) },
            { id: "formato", label: "Formato", core: true, options: opts([
              ["feed", "Post de feed", "post", "post", "quadrado"],
              ["carrossel", "Carrossel", "carousel", "carrossel"],
              ["stories", "Stories", "story", "stories", "vertical"],
              ["reels", "Reels / vídeo curto", "reels cover", "reels", "vertical"],
              ["capa", "Capa / banner", "cover banner", "capa", "horizontal"],
              ["destaque", "Ícone de destaque", "highlight cover", "capa destaque"],
              ["anuncio", "Anúncio", "ad creative", "anúncio"],
              ["thumb", "Thumbnail", "thumbnail", "thumbnail", "horizontal"]
            ]) },
            { id: "objetivo", label: "Objetivo", options: opts([
              ["promo", "Promoção / oferta", "sale promotion", "promoção"],
              ["lancamento", "Lançamento", "product launch", "lançamento"],
              ["institucional", "Institucional", "brand awareness", "institucional"],
              ["educativo", "Educativo / dica", "educational tips", "dicas"],
              ["data", "Data comemorativa", "holiday", "data comemorativa"],
              ["depoimento", "Depoimento", "testimonial", "depoimento"],
              ["vaga", "Vaga / RH", "hiring", "vaga"],
              ["evento", "Evento / webinar", "event webinar", "evento"],
              ["antesdepois", "Antes e depois", "before after", "antes e depois"],
              ["meme", "Meme / trend", "meme trend", "meme"]
            ]) },
            SEGMENTO,
            { id: "estilo", label: "Estilo", options: opts([
              ["minimalista", "Minimalista", "minimalist", "minimalista"],
              ["moderno", "Moderno", "modern", "moderno"],
              ["corporativo", "Corporativo", "corporate", "corporativo"],
              ["colorido", "Colorido", "colorful", "colorido"],
              ["foto", "Com foto", "photo", "foto"],
              ["tipografico", "Tipográfico", "typography", "tipografia"],
              ["3d", "3D", "3d", "3d"],
              ["ilustrado", "Ilustrado", "illustrated", "ilustrado"]
            ]) },
            COR_TERMO
          ],
          platforms: ["pinterest", "instagram", "behance", "canva", "freepik_social", "tiktok", "dribbble", "google", "bing", "yandex"]
        },
        anuncios: {
          label: "Anúncios",
          icon: "",
          kind: "visual",
          defaultView: "meta_ads",
          // os filtros daqui viram parâmetros das bibliotecas de anúncios (não entram como palavra na busca)
          filters: [
            { id: "ad_status", label: "Status", default: "active", options: [
              opt("active", "Ativos agora", { set: { adStatus: "active" } }),
              opt("all", "Todos", { set: { adStatus: "all" } }),
              opt("inactive", "Encerrados", { set: { adStatus: "inactive" } })
            ] },
            { id: "ad_media", label: "Mídia", options: [
              opt("", "Qualquer"),
              opt("image", "Imagem", { set: { adMedia: "image" } }),
              opt("video", "Vídeo", { set: { adMedia: "video" } }),
              opt("meme", "Imagem com texto", { set: { adMedia: "meme" } })
            ] },
            { id: "ad_onde", label: "Onde roda", options: [
              opt("", "Todas"),
              opt("instagram", "Instagram", { set: { adPlace: "instagram" } }),
              opt("facebook", "Facebook", { set: { adPlace: "facebook" } }),
              opt("messenger", "Messenger", { set: { adPlace: "messenger" } }),
              opt("audience_network", "Audience Network", { set: { adPlace: "audience_network" } })
            ] },
            { id: "ad_busca", label: "Busca", default: "exata", options: [
              opt("exata", "Frase exata", { set: { adExact: true } }),
              opt("palavras", "Qualquer palavra", { set: { adExact: false } })
            ] },
            { id: "ad_pais", label: "País", default: "BR", options: [
              opt("BR", "Brasil", { set: { adCountry: "BR" } }),
              opt("ALL", "Todos os países", { set: { adCountry: "ALL" } })
            ] }
          ],
          platforms: ["meta_ads", "linkedin_ads", "tiktok_ads", "google_ads"]
        },
        mockup: {
          label: "Mockups",
          icon: "▤",
          kind: "visual",
          defaultView: "freepik",
          must: { terms: ["mockup"], pt: ["mockup"] },
          filters: [
            { id: "objeto", label: "Objeto", options: [
              opt("", "Qualquer"),
              opt("celular", "Celular", t("phone", "celular")),
              opt("notebook", "Notebook / monitor", t("laptop screen", "notebook")),
              opt("tablet", "Tablet", t("tablet", "tablet")),
              opt("cartaz", "Cartaz / quadro", t("poster frame", "cartaz")),
              opt("cartao", "Cartão de visita", t("business card", "cartão de visita")),
              opt("flyer", "Flyer / folder", t("flyer", "flyer")),
              opt("revista", "Livro / revista", t("magazine book", "revista")),
              opt("caixa", "Embalagem / caixa", t("box packaging", "embalagem")),
              opt("sacola", "Sacola", t("shopping bag", "sacola")),
              opt("camiseta", "Camiseta / roupa", t("t-shirt", "camiseta")),
              opt("caneca", "Caneca", t("mug", "caneca")),
              opt("garrafa", "Garrafa / lata", t("bottle can", "garrafa")),
              opt("outdoor", "Outdoor / fachada", t("billboard", "outdoor")),
              opt("placa", "Placa / sinalização", t("signage", "placa")),
              opt("papelaria", "Papelaria", t("stationery", "papelaria")),
              opt("social", "Post de rede social", t("instagram post", "post instagram"))
            ] },
            { id: "cena", label: "Cena", options: [
              opt("", "Qualquer"),
              opt("isolado", "Isolado", t("isolated", "isolado")),
              opt("cena", "Em uso / ambiente", t("lifestyle scene", "ambiente")),
              opt("mao", "Na mão", t("in hand", "na mão")),
              opt("mesa", "Sobre a mesa", t("on desk", "mesa"))
            ] },
            { id: "angulo", label: "Ângulo", options: opts([
              ["frontal", "Frontal", "front view", "frontal"],
              ["perspectiva", "Perspectiva", "perspective", "perspectiva"],
              ["cima", "De cima (flat lay)", "top view flat lay", "vista de cima"],
              ["lado", "Lateral", "side view", "lateral"]
            ]) },
            { id: "estilo_m", label: "Estilo", options: opts([
              ["realista", "Realista / foto", "realistic", "realista"],
              ["minimal", "Minimal / clean", "minimal clean", "minimalista"],
              ["3d", "3D", "3d render", "3d"],
              ["escuro", "Fundo escuro", "dark background", "fundo escuro"]
            ]) },
            RES
          ],
          platforms: ["freepik", "behance", "pinterest", "mockupworld", "unblast", "bing", "yandex"]
        },
        ilustracao: {
          label: "Ilustração",
          icon: "✎",
          kind: "visual",
          defaultView: "pinterest",
          modifier: { terms: ["illustration"], pt: ["ilustração"] },
          filters: [
            { id: "estilo", label: "Estilo", options: [
              opt("", "Qualquer"),
              opt("flat", "Flat", t("flat illustration", "ilustração flat")),
              opt("isometrica", "Isométrica", t("isometric", "isométrica")),
              opt("3d", "3D", t("3d illustration", "ilustração 3d")),
              opt("mao", "Feita à mão", t("hand drawn", "desenho à mão")),
              opt("aquarela", "Aquarela", t("watercolor", "aquarela")),
              opt("linha", "Line art", t("line art", "line art")),
              opt("personagem", "Personagem", t("character", "personagem")),
              opt("gravura", "Gravura antiga", t("engraving", "gravura")),
              opt("vetor", "Vetor", t("vector", "vetor")),
              opt("doodle", "Doodle", t("doodle", "doodle")),
              opt("anime", "Anime / mangá", t("anime", "anime")),
              opt("pixel", "Pixel art", t("pixel art", "pixel art"))
            ] },
            { id: "tema", label: "Tema", options: opts([
              ["pessoas", "Pessoas", "people", "pessoas"],
              ["negocios", "Negócios", "business", "negócios"],
              ["energia", "Energia / sustentável", "renewable energy", "energia"],
              ["tecnologia", "Tecnologia", "technology", "tecnologia"],
              ["natureza", "Natureza", "nature", "natureza"],
              ["cidade", "Cidade", "city", "cidade"],
              ["casa", "Casa / família", "home family", "família"],
              ["dinheiro", "Dinheiro / economia", "money saving", "economia"]
            ]) },
            { id: "paleta", label: "Paleta", options: opts([
              ["pastel", "Pastel", "pastel", "pastel"],
              ["vibrante", "Vibrante", "vibrant colorful", "colorida"],
              ["mono", "Monocromática", "monochrome", "monocromática"],
              ["pb", "Preto e branco", "black and white", "preto e branco"]
            ]) },
            ORIENT,
            RES
          ],
          platforms: ["pinterest", "behance", "freepik", "dribbble", "artstation", "iconscout_ill", "deviantart_site", "bing", "yandex"]
        },
        "3d": {
          label: "3D",
          icon: "⬡",
          kind: "visual",
          defaultView: "sketchfab_site",
          must: { terms: ["3d"], pt: ["3d"] },
          filters: [
            { id: "tipo3d", label: "Tipo", options: [
              opt("", "Tudo"),
              opt("modelos", "Modelos", { set: { kind3d: "modelos" }, ...t("model", "modelo") }),
              opt("texturas", "Texturas / materiais", { set: { kind3d: "texturas" }, ...t("texture", "textura") }),
              opt("hdri", "HDRI", { set: { kind3d: "hdri" }, ...t("hdri", "hdri") }),
              opt("renders", "Renders / ilustração 3D", { set: { kind3d: "renders" }, ...t("render", "render") })
            ] },
            { id: "estilo3d", label: "Estilo", options: [
              opt("", "Qualquer"),
              opt("cartoon", "Cartoon / clay", t("cartoon", "cartoon")),
              opt("realista", "Realista", t("realistic", "realista")),
              opt("isometrico", "Isométrico", t("isometric", "isométrico")),
              opt("lowpoly", "Low poly", t("low poly", "low poly")),
              opt("glass", "Vidro / glassmorphism", t("glass", "vidro")),
              opt("metal", "Metálico", t("metallic", "metálico"))
            ] },
            { id: "uso3d", label: "Uso", options: opts([
              ["icone", "Ícone 3D", "3d icon", "ícone 3d"],
              ["personagem", "Personagem", "character", "personagem"],
              ["cena", "Cena / ambiente", "scene", "cena"],
              ["objeto", "Objeto / produto", "object", "objeto"],
              ["arquitetura", "Arquitetura", "architecture", "arquitetura"],
              ["veiculo", "Veículo", "vehicle", "veículo"]
            ]) },
            { id: "licenca3d", label: "Licença", galleryOnly: true, options: [opt("", "Qualquer"), opt("cc0", "Só CC0 (livre total)", { set: { license: "pd" } })] },
            RES
          ],
          platforms: ["sketchfab_site", "polyhaven_site", "ambientcg_site", "iconscout_3d", "freepik", "behance", "artstation", "cgtrader", "thingiverse"]
        },
        foto: {
          label: "Fotos",
          icon: "◉",
          kind: "visual",
          defaultView: "pexels_site",
          filters: [
            ORIENT,
            { id: "cor", label: "Cor", options: [
              opt("", "Qualquer"),
              ...[
                ["vermelho", "Vermelho", "red"],
                ["laranja", "Laranja", "orange"],
                ["amarelo", "Amarelo", "yellow"],
                ["verde", "Verde", "green"],
                ["azul", "Azul", "blue"],
                ["roxo", "Roxo", "purple"],
                ["rosa", "Rosa", "pink"],
                ["preto", "Preto", "black"],
                ["branco", "Branco", "white"],
                ["pb", "Preto e branco", "black and white"]
              ].map(([v, l, en]) => opt(v, l, { set: { color: v }, terms: [en], pt: [l.toLowerCase()] }))
            ] },
            { id: "pessoas", label: "Pessoas", options: opts([
              ["sem", "Sem pessoas", "no people", "sem pessoas"],
              ["uma", "Uma pessoa", "one person", "pessoa"],
              ["grupo", "Grupo / equipe", "group team", "equipe"],
              ["familia", "Família", "family", "família"],
              ["maos", "Só mãos", "hands", "mãos"]
            ]) },
            { id: "ambiente", label: "Ambiente", options: opts([
              ["estudio", "Estúdio / fundo liso", "studio background", "fundo estúdio"],
              ["escritorio", "Escritório", "office", "escritório"],
              ["casa", "Casa", "home interior", "casa"],
              ["cidade", "Cidade", "city urban", "cidade"],
              ["natureza", "Natureza", "nature", "natureza"],
              ["industria", "Indústria / obra", "industrial", "indústria"],
              ["telhado", "Telhado / painéis", "rooftop solar panels", "telhado"]
            ]) },
            { id: "angulo", label: "Ângulo", options: opts([
              ["aerea", "Aérea / drone", "aerial drone", "aérea"],
              ["close", "Close / macro", "close up", "close"],
              ["cima", "De cima", "top view", "vista de cima"],
              ["retrato", "Retrato", "portrait", "retrato"]
            ]) },
            { id: "luz", label: "Luz", options: opts([
              ["dia", "Dia / luz natural", "daylight", "luz natural"],
              ["por", "Pôr do sol", "sunset", "pôr do sol"],
              ["noite", "Noite", "night", "noite"],
              ["escuro", "Low key / escuro", "dark moody", "escuro"],
              ["claro", "High key / claro", "bright airy", "claro"]
            ]) },
            RES,
            LICENSE
          ],
          platforms: ["pexels_site", "unsplash_site", "pixabay_site", "freepik", "google", "bing", "yandex"]
        },
        video: {
          label: "Vídeos",
          icon: "▶",
          kind: "visual",
          gallery: true,
          defaultView: "gallery",
          filters: [
            ORIENT,
            { id: "duracao", label: "Duração", galleryOnly: true, options: [
              opt("", "Qualquer"),
              opt("curto", "Até 15 s", { set: { vduration: "curto" } }),
              opt("medio", "15 s a 1 min", { set: { vduration: "medio" } }),
              opt("longo", "Mais de 1 min", { set: { vduration: "longo" } })
            ] },
            { id: "res", label: "Resolução", galleryOnly: true, options: [
              opt("", "Qualquer"),
              opt("baixa", "Até 720p", { set: { res: "baixa" } }),
              opt("media", "HD / Full HD", { set: { res: "media" } }),
              opt("alta", "Full HD+ / 4K", { set: { res: "alta" } })
            ] },
            { id: "cena", label: "Tipo de cena", options: opts([
              ["aerea", "Aérea / drone", "aerial drone", "drone"],
              ["slow", "Câmera lenta", "slow motion", "câmera lenta"],
              ["timelapse", "Time-lapse", "timelapse", "timelapse"],
              ["pessoas", "Pessoas", "people", "pessoas"],
              ["natureza", "Natureza", "nature", "natureza"],
              ["cidade", "Cidade", "city", "cidade"],
              ["fundo", "Fundo abstrato / loop", "abstract background loop", "fundo abstrato"],
              ["tela", "Tela verde", "green screen", "tela verde"]
            ]) },
            LICENSE
          ],
          platforms: ["pexels_videos", "pixabay_videos", "mixkit_video", "coverr_site", "freepik_video", "vimeo_site"]
        },
        musica: {
          label: "Músicas",
          icon: "♫",
          kind: "audio",
          gallery: true,
          defaultView: "gallery",
          filters: [
            { id: "clima", label: "Clima", options: [
              opt("", "Qualquer"),
              ...[
                ["animado", "Animado", "upbeat"],
                ["calmo", "Calmo", "calm"],
                ["corporativo", "Corporativo", "corporate"],
                ["inspirador", "Inspirador", "inspiring"],
                ["epico", "Épico", "epic"],
                ["lofi", "Lo-fi", "lofi"],
                ["eletronica", "Eletrônica", "electronic"],
                ["acustico", "Acústico", "acoustic"],
                ["triste", "Triste", "sad"]
              ].map(([v, l, tt]) => opt(v, l, { terms: [tt], set: { mood: tt } }))
            ] },
            { id: "genero", label: "Gênero", options: opts([
              ["pop", "Pop", "pop", "pop"],
              ["rock", "Rock", "rock", "rock"],
              ["hiphop", "Hip hop", "hip hop", "hip hop"],
              ["jazz", "Jazz", "jazz", "jazz"],
              ["classica", "Clássica", "classical", "clássica"],
              ["ambiente", "Ambiente", "ambient", "ambiente"],
              ["cinematica", "Cinematográfica", "cinematic", "cinematográfica"],
              ["funk", "Funk / brasileira", "brazilian", "brasileira"]
            ]) },
            { id: "instrumento", label: "Instrumento", options: opts([
              ["piano", "Piano", "piano", "piano"],
              ["violao", "Violão", "acoustic guitar", "violão"],
              ["sintetizador", "Sintetizador", "synth", "sintetizador"],
              ["cordas", "Cordas", "strings", "cordas"],
              ["percussao", "Percussão", "drums percussion", "percussão"]
            ]) },
            AUDIO_DUR,
            LICENSE
          ],
          platforms: ["pixabay_music", "fma", "ccmixter_site"]
        },
        sfx: {
          label: "Efeitos sonoros",
          icon: "◌",
          kind: "audio",
          gallery: true,
          defaultView: "gallery",
          filters: [
            { id: "categoria", label: "Categoria", options: opts([
              ["ui", "Interface / clique", "ui click", "clique"],
              ["whoosh", "Transição / whoosh", "whoosh transition", "transição"],
              ["impacto", "Impacto", "impact hit", "impacto"],
              ["notificacao", "Notificação", "notification", "notificação"],
              ["natureza", "Natureza", "nature ambience", "natureza"],
              ["cidade", "Cidade / trânsito", "city traffic", "cidade"],
              ["publico", "Aplausos / público", "applause crowd", "aplausos"],
              ["cartoon", "Cartoon", "cartoon", "cartoon"],
              ["eletrico", "Elétrico / energia", "electric zap", "elétrico"],
              ["dinheiro", "Dinheiro / caixa", "cash register coins", "dinheiro"]
            ]) },
            AUDIO_DUR,
            LICENSE
          ],
          platforms: ["pixabay_sfx", "freesound_site", "mixkit_sfx", "zapsplat"]
        },
        icone: {
          label: "Ícones",
          icon: "✦",
          kind: "icon",
          defaultView: "flaticon",
          filters: [
            { id: "estilo", label: "Estilo", options: [
              opt("", "Qualquer"),
              opt("linha", "Linha", { set: { iconStyle: "linha" }, ...t("outline", "outline") }),
              opt("preenchido", "Preenchido", { set: { iconStyle: "preenchido" }, ...t("filled", "filled") }),
              opt("colorido", "Colorido", { set: { iconStyle: "colorido" }, ...t("color", "color") }),
              opt("emoji", "Emoji", { set: { iconStyle: "emoji" }, ...t("emoji", "emoji") }),
              opt("3d", "3D", t("3d", "3d")),
              opt("animado", "Animado", t("animated", "animated")),
              opt("handdrawn", "Desenhado à mão", t("hand drawn", "hand drawn"))
            ] },
            { id: "tema_i", label: "Tema", options: opts([
              ["energia", "Energia", "energy", "energy"],
              ["negocios", "Negócios", "business", "business"],
              ["redes", "Redes sociais", "social media", "social media"],
              ["interface", "Interface / app", "user interface", "interface"],
              ["setas", "Setas", "arrow", "arrow"],
              ["dinheiro", "Dinheiro", "money", "money"]
            ]) },
            { id: "pacote", label: "Pacote", galleryOnly: true, options: [
              opt("", "Todos"),
              opt("mdi", "Material Design", { set: { iconSet: "mdi" } }),
              opt("tabler", "Tabler", { set: { iconSet: "tabler" } }),
              opt("lucide", "Lucide", { set: { iconSet: "lucide" } }),
              opt("ph", "Phosphor", { set: { iconSet: "ph" } }),
              opt("fa", "Font Awesome", { set: { iconSet: "fa6-solid,fa6-regular,fa6-brands" } }),
              opt("fluent", "Fluent (Microsoft)", { set: { iconSet: "fluent" } }),
              opt("solar", "Solar", { set: { iconSet: "solar" } }),
              opt("marcas", "Marcas e redes sociais", { set: { iconSet: "simple-icons,logos,mdi" } })
            ] },
            { id: "licenca_icone", label: "Licença", galleryOnly: true, options: [opt("", "Qualquer"), opt("semcredito", "Sem precisar de crédito", { set: { license: "pd" } })] },
            { id: "cor_icone", label: "Cor", kind: "color", galleryOnly: true, default: "#1d1d1f" }
          ],
          platforms: ["flaticon", "iconify_site", "freepik_icon", "iconscout_icon", "nounproject", "icons8"]
        },
        gif: {
          label: "GIFs e motion",
          icon: "◎",
          kind: "visual",
          defaultView: "giphy_site",
          filters: [{ id: "tipo_g", label: "Tipo", options: opts([
            ["reacao", "Reação", "reaction", "reação"],
            ["sticker", "Sticker", "sticker", "sticker"],
            ["loop", "Fundo / loop", "background loop", "loop"],
            ["transicao", "Transição", "transition", "transição"],
            ["texto", "Texto animado", "animated text", "texto animado"],
            ["icone", "Ícone animado", "animated icon", "ícone animado"]
          ]) }],
          platforms: ["giphy_site", "lottiefiles", "iconscout_lottie", "pinterest"]
        },
        arte: {
          label: "Arte e museus",
          icon: "▣",
          kind: "visual",
          defaultView: "artsandculture",
          filters: [
            { id: "periodo", label: "Período", options: opts([
              ["renascimento", "Renascimento", "renaissance", "renascimento"],
              ["barroco", "Barroco", "baroque", "barroco"],
              ["impressionismo", "Impressionismo", "impressionism", "impressionismo"],
              ["artnouveau", "Art nouveau", "art nouveau", "art nouveau"],
              ["moderno", "Arte moderna", "modern art", "arte moderna"],
              ["ukiyoe", "Ukiyo-e (japonesa)", "ukiyo-e", "ukiyo-e"]
            ]) },
            { id: "tecnica", label: "Técnica", options: opts([
              ["oleo", "Pintura a óleo", "oil painting", "pintura a óleo"],
              ["aquarela", "Aquarela", "watercolor", "aquarela"],
              ["gravura", "Gravura", "engraving print", "gravura"],
              ["foto", "Fotografia antiga", "vintage photograph", "fotografia antiga"],
              ["poster", "Cartaz antigo", "vintage poster", "cartaz antigo"],
              ["escultura", "Escultura", "sculpture", "escultura"]
            ]) },
            { id: "licenca_arte", label: "Licença", galleryOnly: true, options: [opt("", "Qualquer"), opt("pd", "Só domínio público", { set: { license: "pd" } })] },
            RES
          ],
          platforms: ["artsandculture", "europeana", "rijks", "pinterest", "bing", "yandex"]
        }
      };
      var slug = (q) => q.toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      var e = encodeURIComponent;
      var freepik = (type) => (q) => `https://br.freepik.com/search?format=search&query=${e(q)}${type ? "&type=" + type : ""}`;
      var qp = (o, sep = "?") => {
        const s = Object.entries(o).filter(([, v]) => v).map(([k, v]) => `${k}=${e(v)}`).join("&");
        return s ? sep + s : "";
      };
      var PX_OR = { horizontal: "landscape", vertical: "portrait", quadrado: "square" };
      var US_OR = { horizontal: "landscape", vertical: "portrait", quadrado: "squarish" };
      var PB_OR = { horizontal: "horizontal", vertical: "vertical" };
      var YX_OR = { horizontal: "horizontal", vertical: "vertical", quadrado: "square" };
      var PX_COLOR = { vermelho: "red", laranja: "orange", amarelo: "yellow", verde: "green", azul: "blue", roxo: "violet", rosa: "pink", preto: "black", branco: "white", pb: "gray" };
      var US_COLOR = { vermelho: "red", laranja: "orange", amarelo: "yellow", verde: "green", azul: "blue", roxo: "purple", rosa: "magenta", preto: "black", branco: "white", pb: "black_and_white" };
      var PB_COLOR = { vermelho: "red", laranja: "orange", amarelo: "yellow", verde: "green", azul: "blue", roxo: "lilac", rosa: "pink", preto: "black", branco: "white", pb: "grayscale" };
      var YX_COLOR = { vermelho: "red", laranja: "orange", amarelo: "yellow", verde: "green", azul: "blue", roxo: "violet", rosa: "pink", preto: "black", branco: "white", pb: "gray" };
      var BING_COLOR = { vermelho: "RED", laranja: "ORANGE", amarelo: "YELLOW", verde: "GREEN", azul: "BLUE", roxo: "PURPLE", rosa: "PINK", preto: "BLACK", branco: "WHITE" };
      var googleTbs = (o) => {
        const t2 = [];
        const ar = { horizontal: "w", vertical: "t", quadrado: "s" }[o.orient];
        if (ar) t2.push("iar:" + ar);
        if (o.color === "pb") t2.push("ic:gray");
        else if (o.color && YX_COLOR[o.color]) t2.push("ic:specific,isc:" + YX_COLOR[o.color]);
        return t2.length ? "&tbs=" + e(t2.join(",")) : "";
      };
      var PLATFORMS = {
        behance: { name: "Behance", lang: "pt", url: (q) => `https://www.behance.net/search/projects?search=${e(q)}` },
        pinterest: { name: "Pinterest", lang: "pt", url: (q) => `https://br.pinterest.com/search/pins/?q=${e(q)}` },
        instagram: { bare: true, name: "Instagram", lang: "pt", url: (q) => `https://www.instagram.com/explore/search/keyword/?q=${e(q)}` },
        dribbble: { name: "Dribbble", lang: "en", url: (q) => `https://dribbble.com/search/${e(q)}` },
        freepik: { name: "Freepik", lang: "pt", url: freepik("") },
        freepik_video: { name: "Freepik vídeos", lang: "pt", url: freepik("video") },
        freepik_icon: { name: "Freepik ícones", lang: "pt", url: freepik("icon") },
        freepik_social: { name: "Freepik", lang: "pt", url: (q) => `https://br.freepik.com/search?format=search&query=${e(q)}&type=psd` },
        meta_ads: { native: true, name: "Meta (Facebook e Instagram)", lang: "pt", url: (q, s, o) => {
          const x = o.set || {}, exact = x.adExact !== false;
          return `https://www.facebook.com/ads/library/?active_status=${x.adStatus || "active"}&ad_type=all&country=${x.adCountry || "BR"}&media_type=${x.adMedia || "all"}` + (x.adPlace ? `&publisher_platforms[0]=${x.adPlace}` : "") + `&q=${e(exact ? `"${q}"` : q)}&search_type=${exact ? "keyword_exact_phrase" : "keyword_unordered"}`;
        } },
        linkedin_ads: { native: true, name: "LinkedIn", lang: "pt", url: (q, s, o) => `https://www.linkedin.com/ad-library/search?keyword=${e(q)}${(o.set || {}).adCountry === "ALL" ? "" : "&countries=BR"}` },
        tiktok_ads: { native: true, name: "TikTok (mais vistos)", lang: "pt", url: (q, s, o) => `https://ads.tiktok.com/business/creativecenter/inspiration/topads/pc/pt?period=30&region=${(o.set || {}).adCountry === "ALL" ? "" : "BR"}&keyword=${e(q)}` },
        google_ads: { native: true, name: "Google (Central de Transparência)", lang: "pt", url: (q, s, o) => `https://adstransparency.google.com/?region=${(o.set || {}).adCountry === "ALL" ? "anywhere" : "BR"}` },
        bing: { name: "Bing Imagens", lang: "pt", url: (q, s, o) => {
          const f = [];
          const ar = { horizontal: "wide", vertical: "tall", quadrado: "square" }[o.orient];
          if (ar) f.push("+filterui:aspect-" + ar);
          if (o.color === "pb") f.push("+filterui:color2-bw");
          else if (o.color && BING_COLOR[o.color]) f.push("+filterui:color2-FGcls_" + BING_COLOR[o.color]);
          return `https://www.bing.com/images/search?q=${e(q)}&safeSearch=${s ? "strict" : "off"}&setlang=pt-br${f.length ? "&qft=" + e(f.join("")) : ""}`;
        } },
        // Instagram e TikTok acham pouco com frases longas: recebem só o assunto
        tiktok: { bare: true, name: "TikTok", lang: "pt", url: (q) => `https://www.tiktok.com/search?q=${e(q)}` },
        canva: { name: "Canva", lang: "pt", url: (q) => `https://www.canva.com/templates/?query=${e(q)}` },
        yandex: { serp: true, name: "Yandex", lang: "pt", url: (q, s, o) => `https://yandex.com/images/search?text=${e(q)}${s ? "&family=yes" : ""}` + qp({ iorient: YX_OR[o.orient], icolor: YX_COLOR[o.color] }, "&") },
        google: { serp: true, name: "Google Imagens", lang: "pt", url: (q, s, o) => `https://www.google.com/search?udm=2&q=${e(q)}${s ? "&safe=active" : ""}` + googleTbs(o) },
        mockupworld: { native: true, name: "Mockup World", lang: "en", url: (q) => `https://www.mockupworld.co/?s=${e(q)}` },
        unblast: { native: true, name: "Unblast", lang: "en", url: (q) => `https://unblast.com/?s=${e(q)}` },
        artstation: { name: "ArtStation", lang: "en", url: (q) => `https://www.artstation.com/search?sort_by=relevance&query=${e(q)}` },
        deviantart_site: { name: "DeviantArt", lang: "en", url: (q) => `https://www.deviantart.com/search?q=${e(q)}` },
        iconscout_ill: { name: "IconScout", lang: "en", url: (q) => `https://iconscout.com/illustrations/${slug(q)}` },
        iconscout_3d: { native: true, name: "IconScout 3D", lang: "en", url: (q) => `https://iconscout.com/3d-illustrations/${slug(q)}` },
        iconscout_icon: { name: "IconScout", lang: "en", url: (q) => `https://iconscout.com/icons/${slug(q)}` },
        iconscout_lottie: { name: "IconScout Lottie", lang: "en", url: (q) => `https://iconscout.com/lottie-animations/${slug(q)}` },
        sketchfab_site: { native: true, name: "Sketchfab", lang: "en", url: (q) => `https://sketchfab.com/search?q=${e(q)}&type=models&features=downloadable` },
        polyhaven_site: { native: true, name: "Poly Haven", lang: "en", url: (q) => `https://polyhaven.com/all?s=${e(q)}` },
        ambientcg_site: { native: true, name: "ambientCG", lang: "en", url: (q) => `https://ambientcg.com/list?q=${e(q)}` },
        cgtrader: { native: true, name: "CGTrader (grátis)", lang: "en", url: (q) => `https://www.cgtrader.com/free-3d-models?keywords=${e(q)}` },
        thingiverse: { native: true, name: "Thingiverse", lang: "en", url: (q) => `https://www.thingiverse.com/search?q=${e(q)}` },
        pexels_site: { name: "Pexels", lang: "pt", url: (q, s, o) => `https://www.pexels.com/pt-br/procurar/${e(q)}/` + qp({ orientation: PX_OR[o.orient], color: PX_COLOR[o.color] }) },
        unsplash_site: { name: "Unsplash", lang: "en", url: (q, s, o) => `https://unsplash.com/s/photos/${e(q)}` + qp({ orientation: US_OR[o.orient], color: US_COLOR[o.color] }) },
        pixabay_site: { name: "Pixabay", lang: "pt", url: (q, s, o) => `https://pixabay.com/pt/images/search/${e(q)}/` + qp({ orientation: PB_OR[o.orient], colors: PB_COLOR[o.color] }) },
        pexels_videos: { name: "Pexels vídeos", lang: "pt", url: (q, s, o) => `https://www.pexels.com/pt-br/procurar/videos/${e(q)}/` + qp({ orientation: PX_OR[o.orient] }) },
        pixabay_videos: { name: "Pixabay vídeos", lang: "pt", url: (q, s, o) => `https://pixabay.com/pt/videos/search/${e(q)}/` + qp({ orientation: PB_OR[o.orient] }) },
        mixkit_video: { name: "Mixkit", lang: "en", url: (q) => `https://mixkit.co/free-stock-video/${slug(q)}/` },
        coverr_site: { name: "Coverr", lang: "en", url: (q) => `https://coverr.co/stock-video-footage/${slug(q)}` },
        youtube_site: { name: "YouTube", lang: "pt", url: (q) => `https://www.youtube.com/results?search_query=${e(q)}` },
        vimeo_site: { name: "Vimeo (CC)", lang: "en", url: (q) => `https://vimeo.com/search?q=${e(q)}&license=by` },
        pixabay_music: { name: "Pixabay músicas", lang: "en", url: (q) => `https://pixabay.com/music/search/${e(q)}/` },
        fma: { name: "Free Music Archive", lang: "en", url: (q) => `https://freemusicarchive.org/search?quicksearch=${e(q)}` },
        ccmixter_site: { name: "ccMixter", lang: "en", url: (q) => `https://dig.ccmixter.org/search?searchp=${e(q)}` },
        youtube_audio: { name: "YouTube (músicas livres)", lang: "en", url: (q) => `https://www.youtube.com/results?search_query=${e(q + " no copyright music")}` },
        pixabay_sfx: { name: "Pixabay efeitos", lang: "en", url: (q) => `https://pixabay.com/sound-effects/search/${e(q)}/` },
        freesound_site: { name: "Freesound", lang: "en", url: (q) => `https://freesound.org/search/?q=${e(q)}` },
        mixkit_sfx: { name: "Mixkit efeitos", lang: "en", url: (q) => `https://mixkit.co/free-sound-effects/${slug(q)}/` },
        zapsplat: { name: "Zapsplat", lang: "en", url: (q) => `https://www.zapsplat.com/?s=${e(q)}` },
        flaticon: { name: "Flaticon", lang: "en", url: (q) => `https://www.flaticon.com/search?word=${e(q)}` },
        nounproject: { name: "Noun Project", lang: "en", url: (q) => `https://thenounproject.com/search/icons/?q=${e(q)}` },
        icons8: { name: "Icons8", lang: "en", url: (q) => `https://icons8.com/icons/set/${slug(q)}` },
        iconify_site: { name: "Iconify", lang: "en", url: (q) => `https://icon-sets.iconify.design/?query=${e(q)}` },
        giphy_site: { name: "GIPHY", lang: "en", url: (q) => `https://giphy.com/search/${slug(q)}` },
        lottiefiles: { name: "LottieFiles", lang: "en", url: (q) => `https://lottiefiles.com/search?q=${e(q)}&category=animations` },
        artsandculture: { name: "Google Arts & Culture", lang: "en", url: (q) => `https://artsandculture.google.com/search?q=${e(q)}` },
        europeana: { name: "Europeana", lang: "pt", url: (q) => `https://www.europeana.eu/pt/search?query=${e(q)}` },
        rijks: { name: "Rijksmuseum", lang: "en", url: (q) => `https://www.rijksmuseum.nl/en/search?query=${e(q)}` }
      };
      function applyFilters(typeId, chosen = {}) {
        const T = TYPES[typeId];
        const out = { terms: [], pt: [], orient: "", set: {} };
        for (const f of T.filters) {
          if (f.kind === "color") {
            if (chosen[f.id]) out.set.iconColor = chosen[f.id];
            continue;
          }
          const val = chosen[f.id] ?? f.default ?? "";
          if (f.id === "licenca") {
            out.set.license = val || "commercial";
            continue;
          }
          const o = f.options.find((x) => x[0] === val);
          const fx = o && o[2];
          if (!fx) continue;
          for (const x of fx.terms || []) if (!out.terms.includes(x)) out.terms.push(x);
          for (const x of fx.pt || []) if (!out.pt.includes(x)) out.pt.push(x);
          if (fx.orient && !out.orient) out.orient = fx.orient;
          if (f.core && (fx.terms || []).length) out.core = true;
          if (fx.set) Object.assign(out.set, fx.set);
        }
        return out;
      }
      module.exports = { TYPES, PLATFORMS, applyFilters };
    }
  });

  // engine/search.js
  var require_search = __commonJS({
    "engine/search.js"(exports, module) {
      var { norm, hasTerm, isNsfwText } = require_text();
      var { parseQuery, buildVariants } = require_query();
      var { SOURCES } = require_sources();
      var { passes } = require_licenses();
      var { TYPES, PLATFORMS, applyFilters } = require_types();
      var CACHE_TTL = 15 * 60 * 1e3;
      var cache = /* @__PURE__ */ new Map();
      async function cached(src, q, o) {
        const key = [src.id, q, o.page, o.nsfw, o.orient, o.license, o.color, o.mood, o.iconStyle, o.iconSet, o.iconColor].join("|");
        const hit = cache.get(key);
        if (hit && Date.now() - hit.t < CACHE_TTL) return hit.v;
        const v = await src.run(q, o);
        cache.set(key, { t: Date.now(), v });
        if (cache.size > 600) [...cache.keys()].slice(0, 150).forEach((k) => cache.delete(k));
        return v;
      }
      async function pool(tasks, limit) {
        const out = new Array(tasks.length);
        let i = 0;
        await Promise.all(Array.from({ length: Math.min(limit, tasks.length) }, async () => {
          while (i < tasks.length) {
            const k = i++;
            try {
              out[k] = { ok: true, v: await tasks[k]() };
            } catch (e) {
              out[k] = { ok: false, e };
            }
          }
        }));
        return out;
      }
      function scoreItem(it, pq, extra) {
        const t = norm(`${it.text || ""} ${it.title || ""}`);
        const ttl = norm(it.title || "");
        let score = 0, matched = 0;
        for (const c of pq.concepts) {
          const terms = [...c.pt, ...c.en];
          const w = c.phrase ? 8 : 4;
          if (terms.some((x) => hasTerm(ttl, x))) {
            score += w * 1.5;
            matched += 1;
          } else if (terms.some((x) => hasTerm(t, x))) {
            score += w;
            matched += 1;
          } else if (c.related.some((x) => hasTerm(t, x))) {
            score += 1.5;
            matched += 0.5;
          }
        }
        if (pq.fullPhrase && hasTerm(t, pq.fullPhrase)) score += 6;
        if (pq.enCore.split(" ").length >= 2 && hasTerm(t, pq.enCore)) score += 6;
        const coverage = pq.concepts.length ? matched / pq.concepts.length : 1;
        score *= 0.4 + 0.6 * coverage;
        let extraHits = 0;
        for (const x of extra) if (hasTerm(t, x) || x.split(" ").some((w) => w.length > 3 && hasTerm(t, w))) {
          score += 3;
          extraHits++;
        }
        score += 4 * it._vw + (it._vhits - 1) + 2 * (1 - Math.min(it._pos, 20) / 20);
        return { score, coverage, extraHits };
      }
      function orientOk(it, orient) {
        if (!orient || !it.w || !it.h || it.kind === "icon") return true;
        const r = it.w / Math.max(1, it.h);
        if (orient === "horizontal") return r >= 1.1;
        if (orient === "vertical") return r <= 0.9;
        if (orient === "quadrado") return r >= 0.85 && r <= 1.18;
        return true;
      }
      function durationOk(it, o) {
        if (it.duration == null) return true;
        const d = it.duration;
        if (o.duration === "curto" && d > 10) return false;
        if (o.duration === "medio" && (d <= 10 || d > 60)) return false;
        if (o.duration === "longo" && d <= 60) return false;
        if (o.vduration === "curto" && d > 15) return false;
        if (o.vduration === "medio" && (d <= 15 || d > 60)) return false;
        if (o.vduration === "longo" && d <= 60) return false;
        return true;
      }
      function resOk(it, res) {
        if (!res || it.kind === "icon" || it.kind === "audio") return true;
        const w = it.origW || (it.w > 50 ? it.w : 0), h = it.origH || (it.h > 50 ? it.h : 0);
        if (!w || !h) return true;
        const side = Math.max(w, h);
        const [lo, hi] = it.kind === "video" ? [1280, 1920] : [1e3, 2500];
        if (res === "baixa") return side < lo;
        if (res === "media") return side >= lo && side < hi;
        if (res === "alta") return side >= hi;
        return true;
      }
      function sourcesFor(type, getKey) {
        return SOURCES.filter((s) => s.types.includes(type)).map((s) => ({ s, ready: s.keys.every((k) => getKey(k)) }));
      }
      function publicTypes(getKey) {
        return Object.fromEntries(Object.entries(TYPES).map(([id, t]) => [id, {
          label: t.label,
          icon: t.icon,
          kind: t.kind,
          gallery: !!t.gallery,
          defaultView: t.defaultView,
          filters: t.filters.filter((f) => t.gallery || !f.galleryOnly).map((f) => ({ id: f.id, label: f.label, kind: f.kind, default: f.default, options: (f.options || []).map((o) => [o[0], o[1]]) })),
          platforms: t.platforms.map((p) => PLATFORMS[p].name),
          sources: t.gallery ? sourcesFor(id, getKey).map(({ s, ready }) => ({ id: s.id, name: s.name, ready, keys: s.keys })) : []
        }]));
      }
      function platformLinks(p) {
        const type = TYPES[p.type] ? p.type : "design";
        const t = TYPES[type];
        const fx = applyFilters(type, p.filters || {});
        const pq = parseQuery(p.q);
        const nsfw = p.nsfw !== false;
        const raw = (p.q || "").replace(/"/g, "").trim();
        const join = (subject, extra, mod, must) => {
          const parts = [subject, ...!fx.core && mod ? [mod] : [], ...extra];
          const q = parts.join(" ").trim();
          return must && !norm(q).includes(norm(must).trim()) ? `${q} ${must}`.trim() : q;
        };
        const ptQ = join(raw, fx.pt, t.modifier?.pt[0], t.must?.pt[0]);
        const enQ = join(pq.enCore || raw, fx.terms, t.modifier?.terms[0], t.must?.terms[0]);
        const ptQn = join(raw, fx.pt, t.modifier?.pt[0], "");
        const enQn = join(pq.enCore || raw, fx.terms, t.modifier?.terms[0], "");
        const lang = p.lang === "pt" || p.lang === "en" ? p.lang : "auto";
        return t.platforms.map((id) => {
          const pl = PLATFORMS[id];
          const usePt = (lang === "auto" ? pl.lang : lang) === "pt";
          const q = pl.bare ? usePt ? raw : pq.enCore || raw : pl.native ? usePt ? ptQn : enQn : usePt ? ptQ : enQ;
          return { id, name: pl.name, url: q ? pl.url(q, nsfw, { orient: fx.orient, color: fx.set.color, set: fx.set }) : "", query: q, serp: !!pl.serp };
        });
      }
      async function search(p, getKey) {
        const t0 = Date.now();
        const type = TYPES[p.type] ? p.type : "design";
        const T = TYPES[type];
        const nsfw = p.nsfw !== false;
        const fx = applyFilters(type, p.filters || {});
        const pq = parseQuery(p.q);
        const lang = p.lang === "pt" || p.lang === "en" ? p.lang : "auto";
        let variants;
        if (lang === "pt") {
          const pqPt = { ...pq, enCore: pq.ptCore, related: [] };
          variants = buildVariants(pqPt, fx.pt, T.modifier ? T.modifier.pt[0] : "");
        } else {
          variants = buildVariants(pq, fx.terms, T.modifier ? T.modifier.terms[0] : "");
          if (lang === "en") variants = variants.filter((v) => v.kind !== "pt");
        }
        const must = T.must ? lang === "pt" ? T.must.pt[0] : T.must.terms[0] : "";
        const parsed = {
          concepts: pq.concepts.map((c) => ({ label: c.label, en: c.en.slice(0, 2) })),
          extra: lang === "pt" ? fx.pt : fx.terms,
          variants: variants.map((v) => v.q),
          lang,
          must
        };
        const base = { parsed, errors: [], hidden: 0, items: [], platforms: platformLinks(p) };
        if (nsfw && isNsfwText(p.q)) return { ...base, blocked: true, took: 0 };
        if (!variants.length) return { ...base, took: 0 };
        const isMediaType = ["foto", "video", "musica", "sfx"].includes(type);
        const o = {
          type,
          page: Math.max(1, p.page | 0 || 1),
          nsfw,
          orient: fx.orient,
          key: getKey,
          license: isMediaType ? "commercial" : "any",
          ...fx.set
        };
        const off = new Set(p.off || []);
        const srcs = sourcesFor(type, getKey).filter((x) => x.ready && !off.has(x.s.id)).map((x) => x.s);
        const jobs = [];
        for (const s of srcs) {
          let vs = variants.filter((v) => s.pt || v.kind !== "pt");
          if (s.kinds) vs = s.kinds.flatMap((k) => vs.filter((v) => v.kind === k));
          if (s.shortFirst) {
            const core = vs.find((v) => v.kind === "core");
            if (core) vs = [vs[0], core, ...vs.filter((v) => v !== vs[0] && v !== core)];
          }
          if (s.tagMode) {
            vs = [
              ...pq.concepts.map((c) => ({ q: c.en[0].replace(/\s+/g, ""), w: 0.9 })),
              ...pq.related.slice(0, 1).map((r) => ({ q: r.replace(/\s+/g, ""), w: 0.55 })),
              ...fx.terms.slice(0, 1).map((x) => ({ q: x.replace(/\s+/g, ""), w: 0.5 }))
            ].filter((x, i, a) => x.q && a.findIndex((y) => y.q === x.q) === i);
          }
          for (const v of vs.slice(0, s.maxVariants || 2)) {
            const q = must && !s.native && !norm(v.q).includes(` ${norm(must).trim()} `) ? `${v.q} ${must}` : v.q;
            jobs.push({ s, v: { ...v, q } });
          }
        }
        const res = await pool(jobs.map((j) => () => cached(j.s, j.v.q, o)), 10);
        const merged = /* @__PURE__ */ new Map();
        const errors = /* @__PURE__ */ new Set();
        res.forEach((r, k) => {
          const { s, v } = jobs[k];
          if (!r.ok) {
            const e = r.e;
            errors.add(`${s.name}: ${e.status === 429 ? "limite de uso atingido" : e.status === 401 || e.status === 403 ? "chave recusada" : e.status ? "HTTP " + e.status : e.name === "TimeoutError" ? "demorou demais" : "sem conexão"}`);
            return;
          }
          (r.v || []).forEach((it, pos) => {
            if (!it || !(it.thumb || it.audio || it.resolve)) return;
            const m = merged.get(it.id);
            if (m) {
              m._vhits++;
              m._vw = Math.max(m._vw, v.w);
              m._pos = Math.min(m._pos, pos);
            } else merged.set(it.id, { ...it, source: s.id, sourceName: s.name, _vhits: 1, _vw: v.w, _pos: pos });
          });
        });
        const items = [], weak = [], titles = /* @__PURE__ */ new Set();
        let hidden = 0;
        for (const it of merged.values()) {
          const tk = it.source + "|" + norm(it.title).trim();
          if (it.title && titles.has(tk)) continue;
          titles.add(tk);
          if (nsfw && (it.mature || isNsfwText(`${it.title} ${it.text}`))) {
            hidden++;
            continue;
          }
          if (!orientOk(it, o.orient) || !durationOk(it, o) || !resOk(it, o.res)) continue;
          if (it.license && !it.reference && !passes(it.license, o.license)) continue;
          const { score, coverage, extraHits } = scoreItem(it, pq, fx.terms);
          it.score = Math.round(score * 100) / 100;
          if (pq.concepts.length && coverage === 0) {
            if (it._vw >= 0.9 && (extraHits || !fx.terms.length)) {
              it.score = Math.round(score * 30) / 100;
              weak.push(it);
            }
            continue;
          }
          items.push(it);
        }
        items.sort((a, b) => b.score - a.score);
        if (items.length < 24) items.push(...weak.sort((a, b) => b.score - a.score).slice(0, Math.min(12, 24 - items.length)));
        return {
          ...base,
          items: diversify(items).map(({ _vhits, _vw, _pos, ...rest }) => rest),
          errors: [...errors].sort(),
          hidden,
          sourcesUsed: [...new Set(srcs.map((s) => s.name))],
          took: (Date.now() - t0) / 1e3
        };
      }
      function diversify(items, win = 3) {
        const out = [], pool2 = items.slice();
        while (pool2.length) {
          const recent = out.slice(-win).map((x) => x.source);
          let pick = 0;
          if (recent.length === win && new Set(recent).size === 1) {
            const j = pool2.slice(0, 15).findIndex((x) => x.source !== recent[0]);
            if (j > 0) pick = j;
          }
          out.push(pool2.splice(pick, 1)[0]);
        }
        return out;
      }
      module.exports = { search, sourcesFor, platformLinks, publicTypes };
    }
  });

  // ext/engine-entry.js
  var require_engine_entry = __commonJS({
    "ext/engine-entry.js"(exports, module) {
      var { search, sourcesFor, platformLinks, publicTypes } = require_search();
      var { TYPES } = require_types();
      var { KEYS, SOURCES, resolveMedia } = require_sources();
      module.exports = { search, sourcesFor, platformLinks, publicTypes, TYPES, KEYS, SOURCES, resolveMedia };
    }
  });
  return require_engine_entry();
})();
